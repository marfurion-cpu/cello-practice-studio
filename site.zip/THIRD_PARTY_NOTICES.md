# Third-party notices / 第三方许可说明

This is a non-commercial cello practice demonstration. Code, scores, engraving, and dependencies have separate rights; no single repository-wide license overrides the notices below. No claim of professional music verification or worldwide copyright clearance is made.

## Rachmaninoff Vocalise / 练声曲

Composer: Sergei Rachmaninoff. Cello score preparation: YOKOYAMA Shin-Itchiro (横山真一郎).
Original: https://shin-itchiro.seesaa.net/article/220718833.html
Author usage rules: https://shin-itchiro.seesaa.net/article/199910402.html
The original PDF declares Creative Commons Attribution 3.0 Unported: https://creativecommons.org/licenses/by/3.0/
The original PDF is retained without changes. MusicXML files derive from Audiveris optical music recognition and local correction: cue notes, grace notes, slurs, repeat endings, articulation/dynamic recognition, and text markings. Current r6 and earlier revisions remain labelled. Some expression and dynamics are not fully verified or implemented in playback. Attribution and CC BY 3.0 apply to the supplied transcription of this score; underlying composition rights can differ by jurisdiction.

## Bach Suite No. 5 / 第五组曲现行练习版

The current fullscore/data/suite5 files derive from DCMLab/bach_solo: https://github.com/DCMLab/bach_solo . They are provided under Creative Commons Attribution–NonCommercial–ShareAlike 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/
The complete attribution, citation and change description are in fullscore/data/suite5/ATTRIBUTION.txt and must accompany reuse. This includes adapted MusicXML, derived JSON metadata and editable-sources.zip. Noncommercial and share-alike requirements apply. No commercial permission is granted by this repository.

## Other Bach source editions

The archived PDMX uploader records describe Suites 1–3, 6 and the older suite5-reader edition as CC0, and Suite 4 as public domain. These are upstream uploader declarations, not independent verification of every edition or territory. Retain embedded source attribution, source-audit.json and README files; do not describe all editions as independently cleared or replace their provenance with a blanket MIT license. Practice plans and display transcriptions contain local transformations and are not professional fingering editions.

## Software and musical glyphs

OpenSheetMusicDisplay and bundled runtime dependencies retain their license notices in fullscore/vendor/browser-bundle/licenses/ and opensheetmusicdisplay.min.js.LICENSE.txt. OSMD is BSD-3-Clause; VexFlow MIT; JSZip may be used under its MIT option. Other dependency notices are retained individually.
Gonville musical glyphs are by Simon Tatham. The upstream LICENCE permits unrestricted redistribution of output font files and separately licenses the source; the unmodified licence is included as fullscore/vendor/browser-bundle/licenses/Gonville-LICENCE.txt. Source: https://github.com/vexflow/vexflow-fonts-gonville/blob/main/LICENCE .

## Sound

Playback is browser-generated synthesis, not a third-party cello recording or sample library. It is not a substitute for a professional performance.
