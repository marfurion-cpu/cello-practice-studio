// Strictly an ordered score-reading component. No clock, scheduler or auto-next.
import {makePolyWav} from './polyphonic-audio.mjs';
export const cueLength=0.28;
export function manualStepper(model){
 if(model?.schema!=='score-manual-only-v1'||!Array.isArray(model.modes)||!model.modes.length)throw Error('未找到手动读谱范围');
 const modes=new Map(model.modes.map(m=>{
  if(!m.id||m.hasAutomaticPlayback!==false||m.nextSection!==null||m.timing!=='written-order-only'||!m.steps?.length)throw Error('不可把未定时的谱当作自动演奏轨');
  for(const [i,s] of m.steps.entries()){
   if(!Number.isInteger(s.measure)||s.index!==i+1||!Array.isArray(s.images)||!s.images.length||!s.heads?.length||['beat','onset','duration','time','start'].some(k=>k in s))throw Error('手动谱头顺序无效');
   for(const h of s.heads)if(!h.id||h.midi!==null&&(!Number.isInteger(h.midi)||h.midi<0||h.midi>127)||['beat','onset','duration','time','start'].some(k=>k in h))throw Error('手动谱头不可携带演奏时间');
  }
  return [m.id,m];
 }));
 if(modes.size!==model.modes.length)throw Error('重复读谱范围');
 let mode=model.modes[0],i=0;
 const snapshot=()=>({mode,step:mode.steps[i],i,canBackward:i>0,canForward:i<mode.steps.length-1});
 return {
  snapshot,choose(id){if(!modes.has(id))throw Error('未知读谱范围');mode=modes.get(id);i=0;return snapshot();},
  step(delta){if(delta!==1&&delta!==-1)throw Error('只能人工逐步推进');i=Math.min(mode.steps.length-1,Math.max(0,i+delta));return snapshot();},
  reset(){i=0;return snapshot();},
  cue(){
   const pitches=[...new Set(mode.steps[i].heads.filter(h=>h.midi!==null).map(h=>h.midi))];
   return pitches.length?makePolyWav({events:pitches.map(midi=>({midi,time:0,duration:cueLength})),duration:cueLength}):null;
  }
 };
}
