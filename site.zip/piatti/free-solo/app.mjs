import {manualStepper} from './stepper.mjs';
const two=document.createElement.bind(document), ns='http://www.w3.org/2000/svg';
const $=id=>document.getElementById(id), audio=$('media');
let url=null,generation=0,paintCount=0,displayScope=null;
const model=await fetch('./manual.json').then(r=>{if(!r.ok)throw Error('未能载入手动读谱素材');return r.json();});
const stepper=manualStepper(model);
for(const m of model.modes)$('mode').add(new Option(m.title,m.id));
const piece=new URLSearchParams(location.search).get('piece');
if(['5','11'].includes(piece)){
 const mode=model.modes.find(m=>m.title.includes('第'+piece+'首')||m.title.includes('第 '+piece+' 首'));
 if(mode){stepper.choose(mode.id);$('mode').value=mode.id;}
}

function stop(){generation++;audio.pause();audio.removeAttribute('src');if(url)URL.revokeObjectURL(url);url=null;}
function paint(){
 const {mode,step,i,canBackward,canForward}=stepper.snapshot(), modelKey=step.images.join('|'), token=++paintCount;
 $('title').textContent=mode.title;$('basis').textContent=mode.label;
 $('pitch').textContent=step.heads.filter(h=>h.midi!==null).map(h=>h.pitch).join(' + ')||'休止';
 $('pitch').dataset.midi=step.heads.filter(h=>h.midi!==null).map(h=>h.midi).join(',');
 $('detail').textContent=step.label;
 $('source').textContent=mode.sourceSelection;
 $('position').textContent=`第 ${step.measure} 小节 · ${i+1}/${mode.steps.length} 步${canForward?'':' · 本段到此'}`;
 $('position').dataset.step=String(i+1);$('position').dataset.measure=String(step.measure);
 $('prev').disabled=!canBackward;$('next').disabled=!canForward;$('cue').disabled=step.heads.every(h=>h.midi===null);
 const box=$('score');
 if(modelKey!==displayScope){
  displayScope=modelKey;
  box.replaceChildren(...step.images.map(file=>{
   const w=two('span'), img=two('img'), svg=document.createElementNS(ns,'svg');w.className='sheet';
   svg.setAttribute('aria-hidden','true');img.src=file;img.alt='Simrock 7496 原谱，第 '+step.measure+' 小节';w.append(img,svg);return w;
  }));
 }
 for(const [j,span] of [...box.children].entries()){
  const [img,svg]=span.children;svg.replaceChildren();
  const marker=()=>{
   if(token!==paintCount||!img.naturalWidth||j>0)return;
   svg.setAttribute('viewBox',`0 0 ${img.naturalWidth} ${img.naturalHeight}`);
   for(const h of step.heads){
    const [x,y]=h.center||[];
    if(!Number.isFinite(x)||!Number.isFinite(y)||x<0||x>=img.naturalWidth||y<0||y>=img.naturalHeight)continue;
    const dot=document.createElementNS(ns,'circle');dot.setAttribute('cx',x);dot.setAttribute('cy',y);
    dot.setAttribute('r',h.kind==='small'?13:20);dot.dataset.sourceHead=h.id;svg.append(dot);
   }
  };
  img.onload=marker;if(img.complete)marker();
 }
}
function navigate(fn){stop();fn();paint();$('status').textContent='未播放 · 当前是手动读谱';}
$('mode').onchange=()=>navigate(()=>stepper.choose($('mode').value));
$('next').onclick=()=>navigate(()=>stepper.step(1));$('prev').onclick=()=>navigate(()=>stepper.step(-1));$('reset').onclick=()=>navigate(()=>stepper.reset());
$('cue').onclick=async()=>{
 stop();const token=generation;const bytes=stepper.cue();if(!bytes)return;
 url=URL.createObjectURL(new Blob([bytes],{type:'audio/wav'}));audio.src=url;
 try{await audio.play();if(token===generation)$('status').textContent='电子写音提示；提示音长短不是谱面时值。';}
 catch(e){if(token===generation)$('status').textContent='提示音未播放，可继续手动读谱。';}
};
audio.onended=()=>{if(audio.src)$('status').textContent='本步提示音结束；不会自动换音。';};
paint();
