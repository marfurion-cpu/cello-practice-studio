(function(){
'use strict';
const raw=window.NO12, bars=raw.ledger.measures, $=id=>document.getElementById(id);
const labels={ordinary:'普通书写音','written-harmonic-reference':'泛音标记 · 仅书写音','touch-withheld':'菱形触点 · 不发声','harmonic-scope-withheld':'泛音段 · 响音未核','notation-only':'休止／延音 · 不重发'};
const kinds={ordinary:'普通音','marked-written-harmonic':'泛音标记（圆头）','touch-symbol':'菱形触点','rest':'休止'};
let m=0,s=0,lastMeasure=-1,renderer=null,shownMeasure=0,ctx=null,live=[],generation=0;
function current(){return bars[m].steps[s]}
function timed(){return bars[m].automaticTimedPreviouslyVerified?'有独立自动练习证据':'此小节仅逐音读谱，不启用连续播放'}
function say(t){$('status').textContent=t}
function stop(){
 generation++;
 for(const node of live){try{node.stop()}catch{}}
 live=[];
}
function frequency(midi){return 440*2**((midi-69)/12)}
function schedule(ac, notes, end=.24){
 if(!notes.length)return [];
 const start=ac.currentTime+.015,mix=ac.createGain();
 mix.gain.value=1/Math.max(1,notes.length);mix.connect(ac.destination);
 const made=notes.map(midi=>{
  const osc=ac.createOscillator(),shape=ac.createGain();osc.type='sine';
  osc.frequency.value=frequency(midi);shape.gain.setValueAtTime(0,start);
  shape.gain.linearRampToValueAtTime(.23,start+.012);shape.gain.setValueAtTime(.23,start+.164);
  shape.gain.linearRampToValueAtTime(0,start+end);
  osc.connect(shape).connect(mix);osc.start(start);osc.stop(start+end+.006);
  osc.onended=()=>{osc.disconnect();shape.disconnect()};
  return osc;
 });
 made[made.length-1].addEventListener?.('ended',()=>mix.disconnect(),{once:true});
 return made;
}
async function hear(allowReference=false){
 const step=current();
 stop();const stamp=generation;
 if(!step.auditionMidi.length){say(labels[step.mode]+'。未播放。');return}
 if(step.mode==='written-harmonic-reference'&&!allowReference){say('不播放实际泛音。可另按「听书写音」。');return}
 try{
  const Audio=window.AudioContext||window.webkitAudioContext;
  if(!Audio)throw Error('无可用浏览器音频');
  ctx??=new Audio();await ctx.resume();
  if(stamp!==generation||ctx.state!=='running')return;
  live=schedule(ctx,step.auditionMidi);
  say(step.mode==='written-harmonic-reference'?'发出等律书写音，非实际泛音。':'试听本步，未启动连续播放。');
 }catch{say('浏览器没有启动声音；仍可继续逐音读谱。')}
}
function seekSvg(bar,step){
 if(!renderer)return;
 let cursor;
 try{
  if(shownMeasure!==bar.measure){renderer.setOptions({drawFromMeasureNumber:bar.measure,drawUpToMeasureNumber:bar.measure});renderer.render();shownMeasure=bar.measure;}
  if(!$('staff').querySelector('svg'))throw Error('No SVG');
  cursor=renderer.cursor;
  const itr=()=>cursor.Iterator;
  cursor.hide();cursor.reset();
  let ix=0;
  while(!itr().EndReached&&itr().CurrentMeasureIndex<bar.measure-1){cursor.next();if(++ix>3500)throw Error('Limit')}
  if(itr().EndReached||itr().CurrentMeasureIndex!==bar.measure-1)throw Error('Measure',bar.measure);
  const local=str=>{const s=str.split('/').map(Number);return s[0]/(s[1]??1)};
  const first=itr().CurrentSourceTimestamp.RealValue;
  if(bar.steps[0].position!=='0')throw Error('Unanchored measure');
  const goal=first+local(step.position)/4;
  while(!itr().EndReached&&itr().CurrentMeasureIndex===bar.measure-1&&itr().CurrentSourceTimestamp.RealValue<goal-1e-8){cursor.next();if(++ix>3500)throw Error('Limit')}
  if(itr().EndReached||itr().CurrentMeasureIndex!==bar.measure-1||Math.abs(itr().CurrentSourceTimestamp.RealValue-goal)>1e-8)throw Error('No exact coordinate');
  cursor.show();
  $('render').textContent='书写五线谱 · 标线只定位同一书写位置，不选择弓法';
 }catch{
  cursor?.hide();
  $('render').textContent=$('staff').querySelector('svg')?'五线谱可看；这个音组不显示未核实的标线。':'此处排谱不可用，请核对印本；下方音组仍可读。';
 }
}
function paint(){
 const bar=bars[m],step=current();
 $('measure').value=bar.measure;
 $('scope').textContent='印本第 '+bar.printedPage+' 页 · '+timed()+(bar.boundaries.length?' · 原谱有反复／结尾记号':'');
 $('facsimile').href='./original-pp30-33.pdf#page='+(bar.printedPage-29);
 $('prev').disabled=m===0&&s===0;$('next').disabled=m===bars.length-1&&s===bar.steps.length-1;
 $('group-status').textContent='第 '+bar.measure+' 小节 · 第 '+step.step+'/'+bar.steps.length+' 步：'+labels[step.mode];
 if(lastMeasure!==m){
  $('steps').replaceChildren(...bar.steps.map((x,k)=>{
   const b=document.createElement('button');b.type='button';
   b.textContent=x.step+' '+x.heads.map(h=>h.printed??'休').join('＋');
   b.addEventListener('click',()=>{set(m,k);hear()});return b;
  }));lastMeasure=m;
 }
 Array.from($('steps').children).forEach((b,k)=>b.setAttribute('aria-current',String(s===k)));
 $('heads').replaceChildren(...step.heads.map(h=>{
  const li=document.createElement('li');
  li.textContent='声部 '+h.voice+' · '+(h.printed??'休止')+' · '+kinds[h.kind]+(h.ties.includes('stop')?' · 延音末端，不重起':'');return li;
 }));
 $('hear').disabled=!step.auditionMidi.length;$('hear').textContent=step.mode==='written-harmonic-reference'?'听书写音（非实际泛音）':'试听本步';
 $('hear').onclick=()=>hear(true);
 seekSvg(bar,step);
}
function set(bar,step){stop();m=bar;s=step;say('');paint()}
function shift(delta){
 if(delta>0){if(s+1<bars[m].steps.length)set(m,s+1);else if(m+1<bars.length)set(m+1,0);}
 else if(s>0)set(m,s-1);else if(m>0)set(m-1,bars[m-1].steps.length-1);
}
function jump(){const ix=Number($('measure').value);if(Number.isInteger(ix)&&ix>=1&&ix<=109)set(ix-1,0);else say('请输入 1 到 109 的小节号。')}
$('prev').onclick=()=>shift(-1);$('next').onclick=()=>shift(1);$('jump').onclick=jump;
$('measure').onkeydown=e=>{if(e.key==='Enter')jump()};
window.addEventListener('pagehide',()=>{stop();if(ctx)ctx.suspend().catch(()=>{})});
paint();
(async()=>{
 try{
  const OSMD=window.opensheetmusicdisplay.OpenSheetMusicDisplay;
  const local=new OSMD($('staff'),{backend:'svg',drawingParameters:'compacttight',followCursor:false,pageFormat:'Endless',autoResize:false,drawTitle:false,drawComposer:false,drawCredits:false,drawMeasureNumbers:true,autoBeam:true,newSystemFromXML:false,newPageFromXML:false,drawFromMeasureNumber:1,drawUpToMeasureNumber:1});
  await local.load(raw.xml);renderer=local;seekSvg(bars[m],current());
 }catch{$('render').textContent='浏览器未完成五线谱渲染，请核对原印本。音组索引仍可用。'}
})();
})();
