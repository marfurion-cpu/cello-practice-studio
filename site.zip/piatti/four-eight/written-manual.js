/* Standalone, read-only DOM adapter. No audio, rhythm, fetches or shared-onset inference. */
(function(g){
'use strict';
function controller(pack,key){
 if(pack?.schema!=='cello-written-manual/1')throw Error('Unsupported manual schema');
 let p, m=0, v=0, i=0, pkey;
 function current(){
  const measure=p.measures[m], voice=measure.voices[v];
  return {key:pkey,piece:p,measure,voice,group:voice.groups[i],position:i,prevMeasure:m>0,nextMeasure:m<p.measures.length-1};
 }
 function selectPiece(k){
  const candidate=pack.pieces[k];
  if(candidate?.manualOnly!==true||candidate.audio!=='none'||candidate.crossVoiceMerge!==false||!candidate.measures?.length)
    throw Error('Missing strictly written-only manual');
  p=candidate;pkey=k;m=0;v=0;i=0;return current();
 }
 function selectMeasure(n){
  const k=p.measures.findIndex(x=>String(x.number)===String(n));
  if(k<0)return current();
  const prior=p.measures[m].voices[v].id;
  m=k;v=Math.max(0,p.measures[m].voices.findIndex(x=>x.id===prior));i=0;return current();
 }
 function adjacentMeasure(delta){
  if(![-1,1].includes(delta))return current();
  const next=p.measures[m+delta];
  return next?selectMeasure(next.number):current();
 }
 function selectVoice(id){
  const k=p.measures[m].voices.findIndex(x=>x.id===id);
  if(k<0)return current();
  v=k;i=0;return current();
 }
 function selectGroup(j){
   const groups=p.measures[m].voices[v].groups;
   if(Number.isInteger(j)&&j>=0&&j<groups.length)i=j;
   return current();
 }
 function step(delta){return [-1,1].includes(delta)?selectGroup(i+delta):current();}
 selectPiece(key);
 return {current,selectPiece,selectMeasure,adjacentMeasure,selectVoice,selectGroup,step};
}
function mount(root,{config,key}={}){
 const d=root.ownerDocument;
 const c=controller(config,key);
 const el=(tag,txt)=>{const n=d.createElement(tag); if(txt!==undefined)n.textContent=txt;return n;};
 const picker=(text)=>{const l=el('label',text+' '), s=el('select');l.append(s);return [l,s];};
 const [lm,meters]=picker('小节'),[lv,voices]=picker('书写声部'),[lg,groups]=picker('书写音组');
 const subtitle=el('p','只看谱写顺序。你点一下才前进一步，不发声、不计节拍、不提示指法。两个声部可分别看；显示先后不是合奏时序。');
 const pane=el('section');pane.className='written-manual-readout';
 const line=el('p');line.setAttribute('aria-live','polite');
 const notes=el('ul'), hint=el('p');hint.className='w';
 const controls=el('div');controls.className='buttons';
 const button=(label,fn)=>{const n=el('button',label);n.type='button';n.addEventListener('click',fn);return n;};
 const prev=button('上一组',()=>update(c.step(-1))),next=button('下一组',()=>update(c.step(1)));
 const pbar=button('上一小节',()=>update(c.adjacentMeasure(-1))),nbar=button('下一小节',()=>update(c.adjacentMeasure(1)));
 controls.append(prev,next,pbar,nbar);pane.append(line,notes,hint);
 root.replaceChildren(subtitle,lm,lv,lg,pane,controls);
 function options(s,items,value){
   s.replaceChildren(...items.map(([label,v])=>{const o=el('option',label);o.value=String(v);return o;}));
   s.value=String(value);
 }
 function update(z){
  const {piece,measure,voice,group,position}=z;
  options(meters,piece.measures.map(m=>[m.label,m.number]),measure.number);
  options(voices,measure.voices.map(v=>['声部 '+v.id,v.id]),voice.id);
  lv.hidden=measure.voices.length<2;
  options(groups,voice.groups.map(x=>['第 '+x.index+' 组',x.index-1]),position);
  line.textContent=measure.label+' · 声部 '+voice.id+' · 第 '+(position+1)+' / '+voice.groups.length+' 组'+
    (group.notationGroup==='explicit-chord'?'（原谱同声部和弦）':'');
  const headLabel=(h)=>{
   if(h.kind==='rest')return '休止';
   if(h.kind==='harmonic-touch')return '菱形 '+h.writtenPitch+'（仅记谱触点，实际音高未核）';
   if(h.kind==='grace')return h.writtenPitch+'（书写装饰音，不给演奏次序）';
   return h.writtenPitch;
  };
  notes.replaceChildren(...group.heads.map(h=>el('li',headLabel(h)+(h.flags.length?' · '+h.flags.join(' / '):''))));
  hint.textContent=measure.note||'';
  prev.disabled=position===0;next.disabled=position===voice.groups.length-1;
  pbar.disabled=!z.prevMeasure;nbar.disabled=!z.nextMeasure;
 }
 meters.addEventListener('change',()=>update(c.selectMeasure(meters.value)));
 voices.addEventListener('change',()=>update(c.selectVoice(voices.value)));
 groups.addEventListener('change',()=>update(c.selectGroup(Number(groups.value))));
 update(c.current());
 return {selectPiece:k=>update(c.selectPiece(k))};
}
const api={controller,mount};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else g.CelloWrittenManual=api;
})(globalThis);
