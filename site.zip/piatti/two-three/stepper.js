(function (root) {
  'use strict';
  function createManualStepper(data) {
    if (!data || data.schema !== 'piatti-physical-manual-v1') throw new Error('wrong source schema');
    let mode, bar, step;
    const listeners = new Set();
    const state = () => {
      const m = mode.measures[bar];
      return {mode, measure:m, index:step, group:m.steps[step] || null,
        atStart:bar === 0 && step <= 0, atEnd:bar === mode.measures.length-1 && step >= m.steps.length-1};
    };
    const emit = () => {for (const f of [...listeners]) f(state());return state();};
    function select(id) {
      const m = data.modes.find(x => x.id === id);
      if (!m) return false;
      mode=m;bar=0;step=0;return emit();
    }
    function seek(n,k=0) {
      if (!Number.isInteger(n)) return false;
      const i=mode.measures.findIndex(x => x.measure===n);
      if (i<0) return false;
      if(!Number.isInteger(k)||k<0||k>=Math.max(1,mode.measures[i].steps.length))return false;
      bar=i;step=k;return emit();
    }
    function advance(dir) {
      if (dir!==1 && dir!==-1) return false;
      const s=state(), row=s.measure.steps, ix=step+dir;
      if (ix>=0 && ix<row.length) {step=ix;return emit();}
      const i=bar+dir;
      if (i<0||i>=mode.measures.length) return false;
      bar=i;step=dir===1?0:Math.max(0,mode.measures[i].steps.length-1);
      return emit();
    }
    select(data.modes[0].id);
    return Object.freeze({state,select,seek,advance,subscribe(fn){listeners.add(fn);return () => listeners.delete(fn);}});
  }
  root.createManualStepper=createManualStepper;
})(globalThis);
