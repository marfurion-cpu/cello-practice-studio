'use strict';
const $ = id=>document.getElementById(id);
const data=globalThis.PIATTI_WRITTEN, guide=createManualStepper(data);
const labels={rest:'休止',small:'装饰小头', 'tie-continuation':'延续，不重起',rolled:'滚奏记号',fermata:'延长记号',
  'trill-principal':'颤音本音','harmonic-written':'菱形写音', 'source-head':'原谱写音'};
let ctx, active;
function clearCue() {
  if(active){try{active.stop();}catch{} active=null;}
  $('audio-status').textContent='';
}
function draw(s){
  const {mode,measure,index,group,atStart,atEnd}=s;
  const known=mode.measures.filter(x=>x.steps.length).length;
  const n=measure.measure;
  const im=measure.notation;
  $('measure').min=mode.first;$('measure').max=mode.last;$('measure').value=n;
  $('coverage').textContent=mode.id==='no2'
    ? '92 个原谱小节可定位，'+ known +' 个小节有音序，'+(92-known)+' 个仅供对照原谱。'
    : mode.id==='no3m97' ? '本节仅核对 8 枚原谱音头，不是演奏版。'
    : '本段 '+known+' 节有音序。第 97 小节时值仍待核，可单独选择查看写音。';
  $('place').textContent='第 '+n+' 小节'+(group?' · '+(index+1)+' / '+measure.steps.length+' 组':' · 尚未录入音序');
  $('heads').replaceChildren(...(group?.heads ?? []).map(h=>{
    const li=document.createElement('li');li.textContent=h.pitch??'休止';
    const meta=[labels[h.kind]&&h.kind!=='rest'?labels[h.kind]:null,
      mode.id.startsWith('no3')&&n>=58&&n<=78&&h.pitch?'谱表 '+h.staff:null].filter(Boolean);
    if(meta.length){const span=document.createElement('span');span.className='headlabel';span.textContent=meta.join(' · ');li.append(span);}
    return li;
  }));
  $('status').textContent=measure.note|| (!group?'':'此处只按书写音组推进。同组音不推断弓法或物理弦位。');
  $('prev').disabled=atStart;$('next').disabled=atEnd;$('cue').disabled=!group?.cue?.length;
  $('score-caption').textContent='Simrock 原谱第 '+im.page+' 页'+(im.system?'，第 '+im.system+' 行':'（整页对照）');
  $('score-alt').hidden=!im.alternate;
  if(im.alternate)$('score-alt').href=im.alternate;
  if ($('score').getAttribute('src')!==im.src){$('score').src=im.src;$('scoreScroll').scrollTop=0;}
  $('score').alt=$('score-caption').textContent;
  clearCue();
}
for(const mode of data.modes){
  const o=document.createElement('option');o.value=mode.id;o.textContent=mode.name;$('mode').append(o);
}
$('mode').addEventListener('change',e=>guide.select(e.target.value));
$('jump').addEventListener('submit',e=>{e.preventDefault();guide.seek(Number($('measure').value));});
$('prev').onclick=()=>guide.advance(-1);$('next').onclick=()=>guide.advance(1);
window.addEventListener('keydown',e=>{
  if(e.altKey||e.ctrlKey||e.metaKey||e.shiftKey||['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;
  if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();guide.advance(e.key==='ArrowLeft'?-1:1);}
});
$('cue').onclick=async()=>{
  clearCue();
  const intended=guide.state().group;
  if(!intended||intended.cue.length!==1)return;
  try{
    const C=window.AudioContext||window.webkitAudioContext; if(!C) throw Error('not available');
    ctx??=new C();await ctx.resume();
    if(guide.state().group!==intended)return;
    const o=ctx.createOscillator(),g=ctx.createGain(),now=ctx.currentTime;
    o.type='sine';o.frequency.setValueAtTime(440*2**((intended.cue[0]-69)/12),now);
    g.gain.setValueAtTime(0,now);g.gain.linearRampToValueAtTime(.12,now+.012);
    g.gain.linearRampToValueAtTime(0,now+.12);o.connect(g).connect(ctx.destination);
    active=o;o.onended=()=>{if(active===o)active=null;o.disconnect();g.disconnect();};
    o.start(now);o.stop(now+.125);
    $('audio-status').textContent='短音提示，非谱面时值。';
  }catch{$('audio-status').textContent='此浏览器未能播提示，仍可逐组看谱。';}
};
guide.subscribe(draw);draw(guide.state());

{const id=new URLSearchParams(location.search).get('piece');if(['no2','no3a'].includes(id)){const mode=Array.from(document.querySelectorAll('select')).find(x=>Array.from(x.options).some(o=>o.value===id));if(mode){mode.value=id;mode.dispatchEvent(new Event('change'));}}}
