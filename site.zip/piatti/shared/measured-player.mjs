import {locate,activeMeasure,encodeBlock} from './measured-core.mjs';
export function mountMeasured({ranges,getPoint,showPoint,stopManual,host,optInLabel,playLabel}){
 let generation=0, raf=0,url=null, state='idle', resume=null,lastKey=null, locationNow=null, block=null;
 const make=(type,label)=>Object.assign(document.createElement(type),{textContent:label});
 const top=make('div',''), label=make('label','试听速度 '), tempo=make('select',''), play=make('button','从当前处试听'), stop=make('button','停止');
 const message=make('p',''), audio=make('audio','');
 audio.id='verified-audio'; audio.preload='none'; audio.hidden=true;
 tempo.id='verified-tempo'; play.id='verified-play'; stop.id='verified-stop'; message.id='verified-status';
 for(const bpm of [30,45,60,72,80,90,100,120,144,160])tempo.add(new Option(bpm+' BPM',String(bpm),false,bpm===90));
 label.append(tempo); top.append(play,stop,label); top.className='verified-controls';
 message.setAttribute('role','status'); host.replaceChildren(top,message,audio);
 const write=(kind,text)=>{state=kind;message.dataset.state=kind;message.textContent=text;stop.disabled=kind!=='playing'&&kind!=='loading';};
 const cancel=()=>{
  ++generation; cancelAnimationFrame(raf); audio.onplaying=audio.onended=audio.onerror=null;
  audio.pause();audio.removeAttribute('src');audio.load();if(url)URL.revokeObjectURL(url);url=null;block=null;
 };
 const current=()=>{const [bar,local]=getPoint();const start=locate(typeof ranges==='function'?ranges():ranges,bar,local);return start?[bar,local,start]:[bar,local,null]};
 const idle=()=>{const [bar,local,here]=current();
  play.disabled=!here;play.textContent=playLabel?.()??'从当前处试听';
  write('idle',here?((typeof optInLabel==='function'?optInLabel():optInLabel)??'合成电子音按已核时值试听；不会跨未核小节。'):'第 '+bar+' 小节或所选音组无已核连续时值，只能手动读谱。请选择下一个已核小节再试听。');
 };
 const detach=()=>{resume=null;lastKey=null;locationNow=null;cancel();idle();};
 function show(band,beat){
  const ix=activeMeasure(band,beat);if(ix<0)return;
  const [bar,base]=band.starts[ix];
  const key=showPoint(bar,beat-base,lastKey);
  lastKey=key;locationNow={band,beat,bar};
 }
 function fail(token){if(token!==generation)return;cancel();write('error','浏览器未能启动试听；可以重试，或继续手动读谱。');}
 function startBlock(band,beat,bpm,token){
  if(token!==generation)return;
  let made;try{made=encodeBlock(band,beat,bpm)}catch{fail(token);return}
  if(url)URL.revokeObjectURL(url);
  url=URL.createObjectURL(new Blob([made.wav],{type:'audio/wav'}));
  audio.src=url; block={band,beat,bpm,end:made.end};
  audio.dataset.startQuarter=String(beat);audio.dataset.endQuarter=String(made.end);
  audio.dataset.samplePeak=String(new Int16Array(made.wav,44).reduce((n,s)=>Math.max(n,Math.abs(s)),0));
  // Capture playback progress from native audio, not a separate clock.
  const tick=()=>{if(token!==generation||audio.ended)return;if(!audio.paused)show(band,Math.min(made.end-1e-6,beat+audio.currentTime*bpm/60));raf=requestAnimationFrame(tick)};
  audio.onplaying=()=>{if(token===generation)write('playing','正在试听：'+band.label);};
  audio.onerror=()=>fail(token);
  audio.onended=()=>{
   if(token!==generation)return;
   cancelAnimationFrame(raf);
   if(made.end<band.total-1e-7){startBlock(band,made.end,bpm,token);return;}
   show(band,band.total-1e-6);cancel();resume=null;
   const last=band.starts.at(-1)[0];write('ended','已在第 '+last+' 小节末停止。其他小节请手动选择，不会自动跨段。');
  };
  write('loading','正在准备当前片段的电子试听…');
  // Synchronous play() in the user-initiated call for the first block.
  audio.play().then(()=>{if(token===generation)raf=requestAnimationFrame(tick)}).catch(()=>fail(token));
 }
 play.onclick=()=>{const [,,here]=current();if(!here)return;stopManual();
   const start=resume?.band===here.band?resume.beat:here.beat;
   cancel();resume=null;lastKey=null;show(here.band,start);startBlock(here.band,start,+tempo.value,generation);
 };
 stop.onclick=()=>{if(block){const end=block.end-1e-6;resume={band:block.band,beat:Math.min(end,block.beat+audio.currentTime*block.bpm/60)};show(resume.band,resume.beat);}
  cancel();write('stopped','已停止。再次试听从当前处继续；手动选音会改用新位置。');
 };
 tempo.onchange=()=>{if(block)stop.click();};
 window.addEventListener('pagehide',()=>{cancel();stopManual();});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&block)stop.click();});
 idle(); return {detach};
}
