import {makePolyWav} from '../five-timed/polyphonic-audio.mjs';
const eps=1e-8;
export function locate(ranges, measure, within=0){
 const band=ranges.find(r=>r.starts.some(([n])=>n===measure));
 if(!band||!Number.isFinite(within)||within<0)return null;
 const i=band.starts.findIndex(([n])=>n===measure), left=band.starts[i][1], right=band.starts[i+1]?.[1]??band.total;
 if(left+within>=right-eps)return null;
 return {band,beat:left+within};
}
export function activeMeasure(band,q){
 return band.starts.findLastIndex(([,t])=>t<=q+eps);
}
export function planBlock(band,beat,bpm){
 if(!Number.isFinite(beat)||beat<0||beat>=band.total-eps||!Number.isFinite(bpm)||bpm<30||bpm>160)throw Error('当前试听起点不可用');
 const cap=beat+45*bpm/60;
 const end=band.total<=cap?band.total:(band.starts.findLast(([,t])=>t<=cap+eps&&t>beat+eps)?.[1]??cap);
 const duration=(end-beat)*60/bpm;
 const events=band.events.filter(([,t,len])=>t<end-eps&&t+len>beat+eps).map(([midi,t,len])=>{
  const left=Math.max(beat,t),right=Math.min(end,t+len);
  return {midi,time:(left-beat)*60/bpm,duration:(right-left)*60/bpm,phaseOffset:(left-t)*60/bpm};
 });
 return {end,duration,events};
}
export function encodeBlock(band,beat,bpm){
 const p=planBlock(band,beat,bpm);
 return {...p,wav:makePolyWav(p)};
}
