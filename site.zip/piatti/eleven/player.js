import {mountMeasured} from '../shared/measured-player.mjs';
(function(){
'use strict';
let transport,automated=false;
const data=window.NO11,bars=data.ledger.measures,$=id=>document.getElementById(id);
const titles={opening:'开头慢板',manual6:'第 6 小节 · 只按书写顺序',fermata:'第 7 小节 · 延长写音',allegro:'快板原谱',tail:'尾声 · 仅逐音读谱'};
const flags={'fermata':'延长记号','rolled':'卷奏记号','tie-continuation':'延音续头，不重发','grace':'装饰小音头，无时值安排','rest':'休止'};
let m=0,k=0,stepButtons=-1,displayKey=-1,scoreSequence=0,renderer=null,loadedSegment=null;
let ctx=null,nodes=[],audioSequence=0;
const now=()=>bars[m].steps[k], say=t=>$('audio-state').textContent=t;
function stop(){
 audioSequence++;
 for(const n of nodes){try{n.stop()}catch{}}
 nodes=[];
}
function selectable(h){return h.midi!==null&&!h.flags.includes('tie-continuation')}
async function hear(one=null){
 transport?.detach();
 const s=now();stop();const gate=audioSequence;
 const isIndividual=one!==null;
 const pitches=isIndividual&&s.mode==='reference-heads'&&selectable(one)?[one.midi]:!isIndividual&&s.mode==='known-group'?s.cue:[];
 if(!pitches.length){say(s.mode==='reference-heads'?'请点下面一个音头，单独听书写音。':'本步静默，不另外起音。');return}
 try{
  const A=window.AudioContext||window.webkitAudioContext;
  if(!A)throw Error('no native audio');
  ctx??=new A();await ctx.resume();
  if(gate!==audioSequence||ctx.state!=='running')return;
  const start=ctx.currentTime+.012;
  const mix=ctx.createGain();mix.gain.value=1/pitches.length;mix.connect(ctx.destination);
  nodes=pitches.map(x=>{
   const o=ctx.createOscillator(),g=ctx.createGain();
   o.type='sine';o.frequency.value=440*2**((x-69)/12);
   g.gain.setValueAtTime(0,start);g.gain.linearRampToValueAtTime(.22,start+.012);
   g.gain.setValueAtTime(.22,start+.16);g.gain.linearRampToValueAtTime(0,start+.24);
   o.connect(g).connect(mix);o.start(start);o.stop(start+.245);
   o.onended=()=>{o.disconnect();g.disconnect()};
   return o;
  });
  nodes[nodes.length-1].addEventListener?.('ended',()=>mix.disconnect(),{once:true});
  say(isIndividual?'单独试听这一书写音。时值、展开或泛音效果不作推断。':'试听本组，不自动走下一步。');
 }catch{say('浏览器未能启动声音。仍可继续读谱。')}
}
async function renderBar(bar){
 if(displayKey===bar.measure)return;
 displayKey=bar.measure;
 const ticket=++scoreSequence,host=$('staff'),state=$('score-state');
 if(bar.images.length){
  const div=document.createElement('div');div.className='cropGroup';
  for(const file of bar.images){
   const im=document.createElement('img');im.alt='第'+bar.measure+'小节原谱';im.src='./'+file;div.append(im);
  }
  host.replaceChildren(div);loadedSegment=null;renderer=null;
  state.textContent='已核原谱裁片；所选音头见下方，不做未验的自动亮点。';return;
 }
 state.textContent='正在载入当前谱面…';
 try{
  if(loadedSegment!==bar.segment||!renderer){
   const inner=document.createElement('div');
   const OSMD=window.opensheetmusicdisplay.OpenSheetMusicDisplay;
   const newOne=new OSMD(inner,{backend:'svg',drawingParameters:'compacttight',followCursor:false,pageFormat:'Endless',autoResize:false,drawTitle:false,drawComposer:false,drawCredits:false,drawMeasureNumbers:false,autoBeam:true,newSystemFromXML:false,newPageFromXML:false});
   renderer=null;loadedSegment=null;host.replaceChildren();
   await newOne.load(data.xml[bar.segment]);
   if(ticket!==scoreSequence)return;
   host.append(inner);renderer=newOne;loadedSegment=bar.segment;
  }
  renderer.setOptions({drawFromMeasureNumber:bar.ordinal,drawUpToMeasureNumber:bar.ordinal});
  renderer.render();
  if(!host.querySelector('svg path'))throw Error('no SVG');
  host.firstElementChild.dataset.renderedPhysical=String(bar.measure);
  state.textContent='当前小节的五线谱；精确书写音序和声部见下方。';
 }catch{
  if(ticket!==scoreSequence)return;
  loadedSegment=null;renderer=null;host.replaceChildren();
  state.textContent='此处排谱未完成，请点原印本。下方音组仍可人工读谱。';
 }
}
function paint(){
 const b=bars[m],s=now();
 if(document.activeElement!==$('m')||!automated)$('m').value=b.measure;
 $('scope').textContent='印本第 '+b.page+' 页 · '+titles[b.segment]+(b.note?' · '+b.note:'');
 $('paper').href='./original-pp28-29.pdf#page='+(b.page-27);
 $('prev').disabled=m===0&&k===0;$('next').disabled=m===bars.length-1&&k===b.steps.length-1;
 $('group').textContent='第 '+b.measure+' 小节 · 第 '+(k+1)+'／'+b.steps.length+' 步';
 $('hint').textContent=s.label||(s.mode==='reference-heads'?'此组只逐头参考，不替卷奏、延长或记号决定顺序。':'点一个音组试听。上、下一步只移动，不自动发声。');
 if(stepButtons!==m){
  $('steps').replaceChildren(...b.steps.map((x,i)=>{
   const button=document.createElement('button');button.type='button';
   button.textContent=(i+1)+' '+x.heads.map(h=>h.pitch??'休').join('＋');
   button.onclick=()=>{set(m,i);hear()};return button;
  }));stepButtons=m;
 }
 Array.from($('steps').children).forEach((x,i)=>x.setAttribute('aria-current',String(i===k)));
 $('heads').replaceChildren(...s.heads.map(h=>{
  const li=document.createElement('li'),lab=h.pitch??'休止';
  const meta=' · 谱表 '+h.staff+' / 声部 '+h.voice+(h.flags.length?' · '+h.flags.map(f=>flags[f]).join('、'):'');
  if(s.mode==='reference-heads'&&selectable(h)){
   const btn=document.createElement('button');btn.textContent='听 '+lab+'（书写音）';btn.onclick=()=>hear(h);li.append(btn,meta);
  }else li.textContent=lab+meta;
  return li;
 }));
 $('hear').hidden=s.mode!=='known-group';$('hear').onclick=()=>hear();
 renderBar(b);
}
function set(i,j){stop();m=i;k=j;say('');paint();cueBoundary();transport?.detach()}
function shift(change){
 if(change>0){if(k+1<bars[m].steps.length)set(m,k+1);else if(m+1<bars.length)set(m+1,0);}
 else if(k>0)set(m,k-1);else if(m>0)set(m-1,bars[m-1].steps.length-1);
}
function jump(){const t=Number($('m').value);if(t>=1&&t<=101&&Number.isInteger(t))set(t-1,0);else say('请输入 1 到 101 的小节号。')}
$('prev').onclick=()=>shift(-1);$('next').onclick=()=>shift(1);$('m').onchange=jump;
$('m').replaceChildren(...bars.map(b=>new Option('第 '+b.measure+' 小节',b.measure)));
window.addEventListener('pagehide',()=>{stop();if(ctx)ctx.suspend().catch(()=>{})});
paint();

const ranges=window.TIMED11;
const allTimed=ranges.flatMap(x=>x.starts.map(m=>m[0]));
const q=x=>{if(typeof x!=='string')return NaN;const [a,b=1]=x.split('/').map(Number);return a/b};
function cueBoundary(){
 const bar=bars[m].measure, next=allTimed.find(x=>x>bar);
 const button=$('verified-next');button.hidden=!next||(allTimed.includes(bar)&&next===bar+1);
 if(next){button.textContent='去第 '+next+' 小节（不自动播放）';button.onclick=()=>set(next-1,0);}
}
transport=mountMeasured({
 ranges,host:$('verified-host'),stopManual:stop,
 optInLabel:'按已核时值试听；卷奏和弓法不模拟，也不扩写延长。',
 getPoint(){return [bars[m].measure,q(now().position)]},
 showPoint(bar,local,lastKey){
  const i=bar-1;
  let j=bars[i].steps.findLastIndex(s=>q(s.position)<=local+1e-8);if(j<0)j=0;
  const key=bar+':'+j;
  if(lastKey!==key){m=i;k=j;automated=true;try{paint();cueBoundary();}finally{automated=false;}}
  return key;
 }
});cueBoundary();$('m').disabled=false;
})();
