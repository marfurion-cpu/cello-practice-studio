import {parseMusicXML} from './musicxml-events.mjs';
import {buildTimeline} from './timeline.mjs';
import {createKtvRenderer} from './ktv-renderer.mjs';
import {slicePlan,makePolyWav} from './polyphonic-audio.mjs';
const $=id=>document.getElementById(id),p=$('player');
const files={A:'simrock-no5-m01-m22.musicxml',B:'simrock-no5-m24-m68.musicxml'};
const timing=files, cache=new Map(), bounds={A:[22,88,354],B:[45,180,946]};
let selected='A', state=null, generation=0, audioGen=0, lastFrame=-1, activeDisplay=null, pendingDisplay=null, paintSeq=0, raf=0, url=null, cursor=null, nativeBlock=null;
const renderer=createKtvRenderer({container:$('engraving'),OpenSheetMusicDisplay:opensheetmusicdisplay.OpenSheetMusicDisplay});
const q=o=>o.n/o.d, viewFor=m=>m<23?'A':m>23?'B':null;
async function get(file){if(!cache.has(file))cache.set(file,(async()=>{const r=await fetch(file);if(!r.ok)throw Error('找不到已核谱面');const xml=await r.text();const score=parseMusicXML(xml);return {xml,score,byId:new Map(score.notes.map(n=>[n.sourceId,n]))};})());return cache.get(file);}
function publish(status){const e=$('state');e.dataset.status=status;e.dataset.band=selected;e.textContent=({loading:'正在加载',ready:'分段已就绪',playing:'正在试听本段',ended:'本段结束，不自动切换',stopped:'已停止',error:'谱面或音频验收失败'})[status];}
function cancelAudio(){audioGen++;cancelAnimationFrame(raf);p.pause();p.onended=null;p.onplaying=null;p.onerror=null;p.removeAttribute('src');p.load();if(url)URL.revokeObjectURL(url);url=null;nativeBlock=null;}
function stop(){
 if(nativeBlock&&state){
   const {beat,end,bpm}=nativeBlock;
   cursor=Math.max(beat,Math.min(end-1e-6,beat+p.currentTime*bpm/60));
   const f=state.frames.findLast(x=>x.time<=cursor+1e-8);
   if(f)display(f).catch(fail);
 }
 cancelAudio();publish('stopped');
}
async function display(frame){
 const section=viewFor(Number(frame.measure)), token=generation, seq=++paintSeq;
 if(!section||section!==selected)throw Error('本段不含原谱第 23 小节，也不能跨段播放');
 if(activeDisplay?.section!==section){
  if(pendingDisplay?.section!==section){
   const promise=(async()=>{const d=await get(files[section]);if(token!==generation)return null;
    const loaded=await renderer.load(d.xml,{measureCount:d.score.measures.length,identitySource:d.score,sourceLabels:d.score.measures.map(m=>m.number)});
    return token===generation&&!loaded.stale?{...d,section}:null;})();
   pendingDisplay={section,promise};
  }
  const d=await pendingDisplay.promise;if(token!==generation||!d)return;
  if(seq!==paintSeq)return;activeDisplay=d;pendingDisplay=null;
 }
 if(token!==generation||seq!==paintSeq)return;
 const ordinal=activeDisplay.score.measures.findIndex(m=>m.number===frame.measure)+1;
 if(!ordinal)throw Error('小节身份丢失');
 renderer.showMeasure(ordinal);
 const heads=frame.notes.filter(n=>!n.rest&&!n.cue).map(t=>{
   const n=activeDisplay.byId.get(t.sourceId), measure=activeDisplay.score.measures[ordinal-1];
   if(!n||n.measureIndex!==ordinal-1||n.staff!==t.staff||n.voice!==t.voice||n.midi!==t.midi)throw Error('谱面/声音身份不一致');
   return {measureOrdinal:ordinal,noteOrdinal:measure.noteIds.indexOf(n.id)+1,noteId:n.id,sourceId:n.sourceId,voice:n.voice,staff:n.staff,grace:Boolean(n.grace),pitch:n.pitch};
 });
 for(const x of $('engraving').querySelectorAll('[data-qa-source-id]'))delete x.dataset.qaSourceId;
 if(!heads.length)renderer.hideCursor();else renderer.seekIdentities(heads).forEach((node,i)=>{node.dataset.qaSourceId=heads[i].sourceId;});
 $('position').dataset.localQ=String(frame.time-q(state.score.measures[frame.measureIndex].onset));
 $('position').dataset.currentMidi=frame.sounding.map(n=>n.midi).join(',');

 $('position').textContent=selected+' 段 · 第 '+frame.measure+' 小节 · '+frame.name;
 $('position').dataset.measure=frame.measure;if(document.activeElement!==$('bar'))$('bar').value=frame.measure;
}
async function select(b){
 $('five-boundary').hidden=true;cursor=null;state=null;
 cancelAudio();const token=++generation;renderer.cancelPending();pendingDisplay=null;activeDisplay=null;lastFrame=-1;selected=b;publish('loading');$('play').disabled=$('bar').disabled=true;
 const {score}=await get(timing[b]);if(token!==generation)return;
 const expect=bounds[b];if(score.measures.length!==expect[0]||score.totalBeats!==expect[1]||score.notes.length!==expect[2])throw Error('冻结谱例身份不一致');
 state={score,frames:buildTimeline(score)};
 const vals=score.measures.map(m=>m.number);$('bar').replaceChildren(...vals.map(n=>new Option(n,n)));$('bar').value=vals[0];
 cursor=state.frames[0].time;await display(state.frames[0]);if(token!==generation)return;$('play').disabled=$('bar').disabled=false;publish('ready');
}
const fail=e=>{$('state').dataset.status='error';$('state').textContent=e.message;cancelAudio();};
async function jump(){
 if(!state)return;
 const token=generation;cancelAudio();lastFrame=-1;const e=state.frames.find(m=>m.measure===$('bar').value);
 if(!e)return;cursor=e.time;$('five-boundary').hidden=true;
 await display(e);if(token===generation)publish('ready');
}
function play(){
 if(!state)return;
 if(nativeBlock)stop();
 cancelAudio();const token=audioGen, branch=selected, s=state.score, frames=state.frames, bpm=Number($('five-tempo').value), measure=s.measures.find(m=>m.number===(state.frames.findLast(f=>f.time<=cursor+1e-8)?.measure??$('bar').value));
 if(!measure)return;$('five-boundary').hidden=true;
 const start=Number.isFinite(cursor)?Math.max(q(measure.onset),Math.min(q(measure.onset)+q(measure.duration)-1e-5,cursor)):q(measure.onset);
 const finish=$('range').value==='measure'?q(measure.onset)+q(measure.duration):s.totalBeats;
 const playFrom=beat=>{
  if(token!==audioGen||branch!==selected)return;
  const maxEnd=beat+50*bpm/60;
  const boundary=finish<=maxEnd?finish:s.measures.findLast(m=>q(m.onset)>beat&&q(m.onset)<=maxEnd)?.onset;
  const end=typeof boundary==='number'?boundary:boundary?q(boundary):Math.min(finish,maxEnd);
  const span=(end-beat)*60/bpm,plan=slicePlan(s,beat,bpm,span),wav=makePolyWav(plan);
  $('state').dataset.startQ=String(beat);
  $('state').dataset.startingTracks=String(plan.events.filter(e=>e.time===0).length);
  $('state').dataset.startingMidi=plan.events.filter(e=>e.time===0).map(e=>e.midi).join(',');
  $('state').dataset.finishQ=String(finish);
  // For acceptance: compute bounded peak and confirm no silent/file-shaped placeholder.
  const data=new Int16Array(wav,44),peak=data.reduce((a,v)=>Math.max(a,Math.abs(v)),0);
  $('state').dataset.samplePeak=String(peak);
  if(branch==='A'&&measure.number==='18'){
   const mags=[];
   for(const midi of [38,45,53,62]){
    const f=440*Math.pow(2,(midi-69)/12),omega=2*Math.PI*f/16000;
    let sin=0,cos=0,total=0;
    for(let i=960;i<Math.min(4640,data.length);i++){const a=data[i];sin+=a*Math.sin(i*omega);cos+=a*Math.cos(i*omega);total++;}
    mags.push(Math.round(Math.hypot(sin,cos)/total));
   }
   $('state').dataset.m18FundamentalMagnitudes=mags.join(',');
  }else delete $('state').dataset.m18FundamentalMagnitudes;

  if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(new Blob([wav],{type:'audio/wav'}));p.src=url;nativeBlock={beat,end,bpm};
  p.onplaying=()=>{if(token===audioGen)publish('playing');};
  p.onerror=()=>{if(token===audioGen)fail(Error('本地试听媒体载入失败'));};
  p.onended=()=>{
    if(token!==audioGen||branch!==selected)return;cancelAnimationFrame(raf);
    if(end<finish-1e-6){playFrom(end);return;}
    const f=frames.findLast(x=>x.time<finish-1e-8);
    cursor=f?.time??start;if(f)display(f).catch(fail);
    cancelAudio();publish('ended');
    $('five-boundary').hidden=!(branch==='A'&&Math.abs(finish-s.totalBeats)<1e-7);
  };
  const follow=()=>{
    if(token!==audioGen||branch!==selected||p.ended)return;
    if(!p.paused){const now=beat+p.currentTime*bpm/60;const index=frames.findLastIndex(f=>f.time<=now+1e-8);
    if(index>=0&&index!==lastFrame){lastFrame=index;display(frames[index]).catch(err=>{if(token===audioGen)fail(err);});}}
    raf=requestAnimationFrame(follow);
  };
  p.play().then(()=>{if(token===audioGen)raf=requestAnimationFrame(follow);}).catch(e=>{if(token===audioGen)fail(e);});
 };
 playFrom(start);
}
$('section-a').onclick=()=>select('A').catch(fail);$('section-b').onclick=()=>select('B').catch(fail);
$('bar').onchange=()=>jump().catch(fail);$('play').onclick=()=>{try{play();}catch(error){fail(error);}};$('stop').onclick=stop;
$('skip-cadenza').onclick=()=>select('B').catch(fail);
const args=new URLSearchParams(location.search), requestedBpm=args.get('bpm');
if([...$('five-tempo').options].some(o=>o.value===requestedBpm))$('five-tempo').value=requestedBpm;
function retainTempo(){
 for(const a of document.querySelectorAll('a[href*="free-solo/index.html"]')){
  const target=new URL(a.href);target.searchParams.set('bpm',$('five-tempo').value);a.href=target.href;
 }
}
$('five-tempo').onchange=()=>{if(nativeBlock)stop();retainTempo();};
retainTempo();
document.addEventListener('visibilitychange',()=>{if(document.hidden&&nativeBlock)stop();});
window.addEventListener('pagehide',cancelAudio);
const startBand=new URLSearchParams(location.search).get('section')==='b'?'B':'A';
select(startBand).catch(fail);
