import {tiedPlaybackPlan} from './musicxml-events.mjs';
import {assignPracticeBows} from './bowing.mjs';
// Navigation uses true onsets. Simultaneous and sustained voices remain intact.
const value=f=>f.n/f.d;
const descendants=n=>n?[n,...(n.children||[]).flatMap(descendants)]:[];
export function buildTimeline(score){
 const normalized=score.notes.map(n=>({...n,ties:n.ties||[]}));
 const byId=new Map(normalized.map(n=>[n.id,n]));
 score={...score,notes:normalized,events:score.events.map(e=>({...e,notes:e.notes.map(n=>byId.get(n.id))}))};
 // Explicit technique marks apply to the whole tied sounding event, including
 // continuations that omit the repeated mark. Absence is not proof of ordinary technique.
 const techniqueById=new Map(score.notes.map(n=>[n.id,descendants(n.notations).filter(x=>['harmonic','thumb-position'].includes(x.name)).map(x=>x.name)]));
 for(const event of tiedPlaybackPlan(score).notes){const marks=[...new Set(event.noteIds.flatMap(id=>techniqueById.get(id)||[]))];for(const id of event.noteIds)techniqueById.set(id,marks);}
 const pitched=score.notes.filter(n=>!n.rest&&!n.cue),active=new Map(),groups=[];
 // Source slur identities are scoped by voice and number, never by screen.
 for(const n of score.notes){
  if(n.cue || (score.verifiedPractice && score.slurInterpretation==='display-only-cross-voice'))continue;
  for(const s of n.slurs||[]){const key=n.voice+':'+(s.number||'1');
   if(s.type==='start'){if(active.has(key))throw Error('重叠同编号连线未支持');active.set(key,{key,start:value(n.onset),noteIds:[]});}
  }
  for(const [key,g]of active)if(key.startsWith(n.voice+':')&&!n.rest)g.noteIds.push(n.id);
  for(const s of n.slurs||[])if(s.type==='stop'){const key=n.voice+':'+(s.number||'1'),g=active.get(key);if(!g)throw Error('连线终点缺少起点');g.end=value(n.onset);groups.push(g);active.delete(key);}
 }
 if(active.size)throw Error('未闭合连线');
 // Include silent / sustained measure starts so every real measure can be selected.
 const cuts=[...score.measures.map(m=>value(m.onset)),...score.events.map(e=>e.onsetBeats),...score.notes.map(n=>value(n.onset)+n.beats)].sort((a,b)=>a-b).filter((t,i,a)=>t<score.totalBeats-1e-9&&(i===0||t-a[i-1]>1e-9));
 const timeline=cuts.map((time,i)=>{
  const original=score.events.find(e=>Math.abs(e.onsetBeats-time)<1e-9),e=original||{notes:[]},next=cuts[i+1]??score.totalBeats;
  const measure=score.measures.findLast(m=>value(m.onset)<=time+1e-9)||score.measures[0];
  const sounding=pitched.filter(n=>value(n.onset)<=time+1e-9&&value(n.onset)+n.beats>time+1e-9);
  const soundingMidi=[...new Set(sounding.map(n=>n.midi))];
  const one=soundingMidi.length===1?sounding.find(n=>n.midi===soundingMidi[0]):null;
  const name=n=>n.pitch.step+({'-2':'♭♭','-1':'♭','0':'','1':'♯','2':'♯♯'}[n.pitch.alter]??'')+n.pitch.octave;
  return {index:i,time,beats:next-time,notes:e.notes,sounding,rest:!sounding.length,midi:one?.midi??null,
   unsupportedTechniques:[...new Set(sounding.flatMap(n=>techniqueById.get(n.id)||[]))],
   polyphonic:soundingMidi.length>1,name:one?name(one):sounding.length?sounding.map(name).join(' + '):'休止',
   releaseOnly:!original,measureIndex:measure.index,measure:measure.number,
   sourceGroups:groups.filter(g=>time>=g.start-1e-9&&time<=g.end+1e-9),
   ties:e.notes.filter(n=>!n.cue).flatMap(n=>n.ties||[]), annotations:e.notes.filter(n=>!n.cue).flatMap(n=>descendants(n.notations).filter(x=>x.name==='up-bow'||x.name==='down-bow').map(x=>x.name))};
 });
 const result=assignPracticeBows(timeline);
 if(score.verifiedPractice && score.slurInterpretation==='display-only-cross-voice')for(const e of result){e.practiceBow=null;e.practiceGroup=null;e.sourceGroups=[];e.bowReason='跨声部连线仅保留谱面，不推断连弓或模拟连奏';}
 return result;
}
