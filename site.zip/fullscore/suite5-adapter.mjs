import {parseMusicXML} from './pinned-grace-parser.mjs';
import {tiedPlaybackPlan} from './musicxml-events.mjs';
import {verifyBytes} from './verified-courante.mjs';
const pins={"Prelude": ["11b0a5861af77fc116983ce7bb0de6c00dca17ffb4672470980c1a80d1e48ea7", "c9478f34367bb903d261e2a87ed6e7928b6cf2214e3888f81991535500cd967e"], "Allemande": ["b32f8c395bd22f0475de23bdf86b9e80331ea6a4dc9357ff60680fc5d3a29790", "c85edcbe1bc49bab3503b5ea9b23df5d850a5b948e2cb058b49598da76db708a"], "Courante": ["6df5b76c04f78c36713ac630a7995e17eaff8cac86a05a5dd51058f11b9bd5d8", "cb8aa2f126209732e40e46453a9c40426298871306f62c28cfca1db8cd6f97a9"], "Sarabande": ["19cdbcd6c6ff22e7d88ecf602f617f9d8eb88203bfa4d239104248e5af0c3853", "89f7064f40bd71f9a9822cfed6260fbd563cc67fbeeb63fa49d76828c6571768"], "GavotteI": ["c8bb203619ecd625e8b0b8d6d5b733c3c866d6dc8d11ff2ddd76c84f620ed838", "aebc50a7567d3df56e5d56dd6af6e7f609e1e161dab6406cb137ed7596ea0f85"], "GavotteII": ["afbceaef21d6f809025887cad2d92b6d900ec07bc4f44789810e177066e8aa66", "5098238db9d8cebb5bf32c059dd6b2f080effa28cd4ff52f301046b9c2022272"], "Gique": ["1b4624cacfd17e5dfdedd3f7746dbf0e1e64c12747a6a1b7e2dd0aa7ad8072fb", "43897bbc5c3de913223f42df2456ec00ee81d71dc77d0554685747b902290007"]};
const val=f=>f.n/f.d,frac=x=>({n:Math.round(x*960),d:960});
export async function adaptSuite5(xml,metaText){
 const p=JSON.parse(metaText);if(!pins[p.name])throw Error('Unknown suite5 movement');await verifyBytes(metaText,pins[p.name][1]);await verifyBytes(xml,pins[p.name][0]);const written=parseMusicXML(xml);
 if(written.measures.length!==p.writtenMeasures)throw Error('第五组曲小节完整性不符');
 const actual=written.notes.filter(n=>!n.rest).map(n=>[n.measureIndex,Number(n.voice),val(n.onsetInMeasure),val(n.duration),n.midi,n.ties.map(t=>t.type)]);
 const rat=s=>String(s).split('/').map(Number).reduce((a,b)=>a/b);
 if(actual.length!==p.expected.length||actual.some((a,i)=>a.some((x,k)=>k===5?JSON.stringify(x)!==JSON.stringify(p.expected[i][k]):x!==(k===2||k===3?rat(p.expected[i][k]):p.expected[i][k]))))throw Error('第五组曲音高/声部/时值/延音对照失败');
 let pos=0;const notes=[],measures=[];
 for(const [visit,sourceIndex]of p.route.entries()){
  const m=written.measures[sourceIndex];if(!m)throw Error('第五组曲反复路线越界');
  const ns=written.notes.filter(n=>n.measureIndex===sourceIndex).map(n=>({...n,id:`suite5-v${visit}-${n.id}`,order:notes.length+n.order,measureIndex:visit,onset:frac(pos+val(n.onsetInMeasure)),sourceQuarter:val(n.onset),sourceMeasure:sourceIndex+1,sourceNoteId:n.id}));
  measures.push({...m,index:visit,onset:frac(pos),noteIds:ns.map(n=>n.id),sourceOrdinal:sourceIndex+1,sourceQuarter:val(m.onset)});notes.push(...ns);pos+=val(m.duration);
 }
 // Three source grace notes receive an explicit short-appoggiatura practice timing:
 // borrow 1/4 quarter-note beat (or half of a shorter principal) from following same-voice note.
 for(const n of notes.filter(n=>n.grace)){
  const principal=notes.find(x=>x!==n&&!x.grace&&!x.rest&&x.voice===n.voice&&x.measureIndex===n.measureIndex&&val(x.onset)===val(n.onset));
  if(!principal)throw Error('Grace principal not found');const stolen=Math.min(.25,val(principal.duration)/2);
  n.duration=frac(stolen);n.beats=stolen;n.suggestedOrnament=true;
  principal.onset=frac(val(principal.onset)+stolen);principal.duration=frac(val(principal.duration)-stolen);principal.beats=val(principal.duration);
 }
 // The source contains cross-voice ties. Preserve sourceVoice and give only the
 // uniquely matching same-pitch contiguous tie its start voice for sound merging.
 const active=[];for(const n of [...notes].sort((a,b)=>val(a.onset)-val(b.onset)||a.order-b.order)){
  const ts=n.ties.map(t=>t.type);n.sourceVoice=n.voice;
  if(ts.includes("stop")){const matches=active.filter(a=>a.midi===n.midi&&Math.abs(a.end-val(n.onset))<1e-9);if(matches.length!==1)throw Error("Ambiguous source tie");const a=matches[0];n.voice=a.voice;active.splice(active.indexOf(a),1);}
  if(ts.includes("start"))active.push({midi:n.midi,end:val(n.onset)+val(n.duration),voice:n.voice});
 }
 if(active.length)throw Error("Unclosed source tie");
 const grouped=new Map();for(const n of notes){const t=val(n.onset);if(!grouped.has(t))grouped.set(t,[]);grouped.get(t).push(n);}
 const events=[...grouped].sort((a,b)=>a[0]-b[0]).map(([t,ns],index)=>({index,onset:frac(t),onsetBeats:t,notes:ns,noteIds:ns.map(n=>n.id)}));
 const score={...written,notes,events,measures,totalBeats:pos,totalDuration:frac(pos),displayRoute:p.route.map(sourceIndex=>sourceIndex+1),verifiedPractice:true,sourceIdentityRequired:false,writtenMeasureCount:p.writtenMeasures,warnings:['标准定弦改编；保留语料音高、时值、全部声部与延音。此简化转录不含原版装饰、连弓和排版；反复仅按语料编码，不含跨乐章回返。指法为算法建议。']};
 tiedPlaybackPlan(score,60);return score;
}
