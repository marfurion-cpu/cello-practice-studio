const strings=[{name:'C',midi:36,num:4},{name:'G',midi:43,num:3},{name:'D',midi:50,num:2},{name:'A',midi:57,num:1}];
const positions=[['半把位',1],['第一把位',2],['低第二把位',3],['高第二把位',4],['第三把位',5],['第四把位',7]];
function candidates(note){if(note.rest)return [{rest:true,key:'rest'}];if(note.unsupportedTechniques?.length||note.polyphonic||!Number.isInteger(note.midi))return [];const out=[];for(const s of strings){const offset=note.midi-s.midi;if(offset===0)out.push({...s,offset,finger:0,pos:'空弦',start:0,key:s.name+'0'});for(const [pos,start] of positions){const finger=offset-start+1;if(finger>=1&&finger<=4)out.push({...s,offset,finger,pos,start,key:s.name+':'+start+':'+finger});}}return out;}
function cost(c){return c.rest?0:Math.max(0,c.start-2)*.5+(c.start===1?.8:0)+(c.finger===0?0:.05);}
function transition(a,b){if(a.rest||b.rest)return 0;return Math.abs(a.num-b.num)*1.2+(a.start&&b.start?Math.abs(a.start-b.start)*.7:0);}
function solve(notes,locks={}){const path=Array(notes.length).fill(null);let segment=[];function flush(){if(!segment.length)return;let layers=[];segment.forEach((row,k)=>{layers[k]=row.cs.map(c=>{if(k===0)return {c,value:cost(c),prev:-1};let best={value:Infinity};layers[k-1].forEach((p,j)=>{const value=p.value+transition(p.c,c)+cost(c);if(value<best.value)best={c,value,prev:j};});return best;});});let j=layers.at(-1).reduce((b,c,i,a)=>c.value<a[b].value?i:b,0);for(let k=layers.length-1;k>=0;k--){path[segment[k].index]=layers[k][j].c;j=layers[k][j].prev;}segment=[];}
 notes.forEach((n,index)=>{let cs=candidates(n);if(locks[index])cs=cs.filter(c=>c.key===locks[index]);if(!cs.length){flush();return;}if(n.rest){flush();path[index]=cs[0];return;}segment.push({index,cs});});flush();return path;}
function label(c){return c.rest?'休止：不发声':`${c.name} 弦（第 ${c.num} 弦） · ${c.pos} · ${c.finger} 指`;}

export {strings,positions,candidates,solve,label};
