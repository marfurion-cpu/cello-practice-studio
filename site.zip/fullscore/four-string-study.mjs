import {candidates as lowCandidates} from './fingering.mjs';
// Standard cello only: C2 G2 D3 A3. Educational suggestions, not source fingerings.
export const tuning=[{name:'A',midi:57},{name:'D',midi:50},{name:'G',midi:43},{name:'C',midi:36}];
export const patterns=[{name:'全全半',steps:[0,2,4,5]},{name:'全半全',steps:[0,2,3,5]},{name:'全全全',steps:[0,2,4,6]},{name:'半全全',steps:[0,1,3,5]}];
export const pitchName=m=>['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'][m%12]+(Math.floor(m/12)-1);
export const pointX=offset=>50+390*(1-2**(-offset/12));
export function locations(midi){if(!Number.isInteger(midi))return [];return tuning.map(s=>({...s,offset:midi-s.midi})).filter(s=>s.offset>=0&&s.offset<=31);}
export function thumbCandidates(midi){const out=[];if(!Number.isInteger(midi))return out;for(const s of tuning.slice(0,2))for(let anchor=12;anchor<=26;anchor++)for(const p of patterns){const finger=p.steps.indexOf(midi-s.midi-anchor);if(finger<0)continue;out.push({...s,offset:midi-s.midi,anchor,finger,pattern:p.name,steps:p.steps,key:`${s.name}:${anchor}:${p.name}:${finger}`});}return out.sort((a,b)=>a.anchor-b.anchor||tuning.findIndex(s=>s.name===a.name)-tuning.findIndex(s=>s.name===b.name));}
export function bassClefView(xml){return xml.replace(/<clef\b[^>]*>[\s\S]*?<\/clef>/g,c=>c.replace(/<sign>[\s\S]*?<\/sign>/,'<sign>F</sign>').replace(/<line>[\s\S]*?<\/line>/,'<line>4</line>'));}
export function renderFourStringStudy(note,{board,recommendation,candidates,selection,onSelect,compact=false,documentObject=globalThis.document}){
 if(compact)return renderCompactStudy(note,{board,recommendation,candidates,selection,onSelect,documentObject});
 const ns='http://www.w3.org/2000/svg',shape=(tag,attrs,text)=>{const e=documentObject.createElementNS(ns,tag);Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));if(text)e.textContent=text;board.append(e);return e;};
 board.replaceChildren();board.setAttribute('viewBox','0 0 410 130');board.setAttribute('aria-label','四弦全指板理论音高落点；A、D、G、C 弦，从空弦至31半音，不新增第五弦');
 for(const off of [0,2,5,7,9,12,17,19,24,29,31]){const x=pointX(off);shape('line',{x1:x,x2:x,y1:24,y2:93,stroke:'#b5c6b9','stroke-dasharray':'2 3'});shape('text',{x,y:17,'font-size':9,'text-anchor':'middle'},String(off));}
 const midis=[...new Set((note.sounding ?? note.notes ?? []).filter(n=>!n.rest&&!n.cue).map(n=>n.midi).filter(Number.isInteger))];
 if(!midis.length&&!Array.isArray(note.sounding)&&Number.isInteger(note.midi))midis.push(note.midi);
 const special=!!note.unsupportedTechniques?.length;
 if(special)midis.length=0; // Written harmonic pitch is not a verified stopped-string sounding location.
 const cs=!note.polyphonic&&midis.length===1&&!note.unsupportedTechniques?.length?thumbCandidates(midis[0]):[];
 const chosen=cs.find(c=>c.key===selection)||cs.find(c=>c.name==='A')||cs[0];
 tuning.forEach((s,i)=>{const y=35+i*18;shape('text',{x:8,y:y+4,'font-size':13},s.name+'弦');shape('line',{x1:50,x2:380,y1:y,y2:y,stroke:'#728f7a'});for(const midi of midis){const loc=locations(midi).find(l=>l.name===s.name);if(!loc)continue;const selected=chosen?.name===s.name&&chosen.offset===loc.offset;shape('circle',{cx:pointX(loc.offset),cy:y,r:selected?7:4,fill:selected?'#255f45':'#fff',stroke:'#255f45'});if(selected)shape('text',{x:pointX(loc.offset),y:y+3,'text-anchor':'middle',fill:'white','font-size':10},chosen.finger===0?'拇':String(chosen.finger));}});
 shape('text',{x:205,y:113,'text-anchor':'middle','font-size':10},'上方数字 = 距空弦半音；实心 = 所选练习候选；空心 = 可选音高落点');
 shape('text',{x:205,y:127,'text-anchor':'middle','font-size':10},'保持原音高 · 不是移调 · 多音落点不代表可以同时按下');
 const desc=c=>`${c.name}弦 · 拇指锚点${pitchName(c.midi+c.anchor)} · ${c.finger===0?'拇指':c.finger+'指'} · ${c.pattern}`;
 recommendation.textContent=special?'源谱含特殊奏法：保留记谱与试听，不把书写音高当作实响按弦落点':chosen?'四弦练习候选：'+desc(chosen)+'（非原谱指法，可切换）':note.rest?'休止':midis.length>1?'四弦各音落点；和弦组合需分弓/手型核对，不自动推荐同时按弦': '四弦音高落点参考；此音未生成拇指手型';
 candidates.replaceChildren();for(const c of cs.slice(0,32)){const b=documentObject.createElement('button');b.textContent=desc(c);b.setAttribute('aria-pressed',String(c.key===chosen?.key));b.onclick=()=>onSelect(c.key);candidates.append(b);}
}

// One default stop per sounding pitch; candidate choice never changes audio.
export function compactStudyStops(note, selection){
 if(note.unsupportedTechniques?.length)return {options:[],stops:[],special:true};
 const sounds=note.sounding??note.notes??[],midis=[...new Set(sounds.filter(n=>!n.rest&&!n.cue).map(n=>n.midi).filter(Number.isInteger))].sort((a,b)=>b-a);
 if(!midis.length&&!Array.isArray(note.sounding)&&!note.rest&&Number.isInteger(note.midi))midis.push(note.midi);
 const candidatesFor=midi=>locations(midi).map(loc=>{
   const low=lowCandidates({midi}).find(c=>c.name===loc.name&&c.offset===loc.offset);
   const thumb=thumbCandidates(midi).find(c=>c.name===loc.name);
   return {...loc,pitch:midi,key:loc.name+':'+loc.offset,finger:loc.offset===0?0:(low?.finger??(thumb?.finger===0?'拇':thumb?.finger)),position:loc.offset===0?'空弦':(low?.pos??(thumb?'拇指把位':'高把位参考'))};
 }).sort((a,b)=>(a.offset===0?-1:0)-(b.offset===0?-1:0)||a.offset-b.offset);
 const groups=midis.map(candidatesFor),available=groups.filter(g=>g.length);
 const fit=(i,used)=>i===available.length?[]:available[i].map(c=>{
   if(used.includes(c.name))return null;const rest=fit(i+1,[...used,c.name]);return rest?[c,...rest]:null;
 }).find(Boolean)??null;
 if(midis.length===1){const options=groups[0];return {options,stops:options.length?[options.find(c=>c.key===selection)??options[0]]:[],missing:!options.length};}
 const unique=available.length>4?null:fit(0,[]);
 return {options:[],stops:unique??available.map(g=>g[0]),missing:available.length!==groups.length,fallback:!unique};
}
function renderCompactStudy(note,{board,recommendation,candidates,selection,onSelect,documentObject}){
 const ns='http://www.w3.org/2000/svg',shape=(tag,attrs,text)=>{const el=documentObject.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))el.setAttribute(k,v);if(text!==undefined)el.textContent=text;board.append(el);};
 const {options,stops,special,missing,fallback}=compactStudyStops(note,selection), x=n=>65+330*(1-2**(-n/12));
 board.replaceChildren();board.setAttribute('viewBox','0 0 380 108');board.setAttribute('role','img');board.setAttribute('aria-label','四弦指板：实心点为当前发声音高的练习落点');
 for(const n of [0,2,5,7,9,12,17,19,24,29]){shape('line',{x1:x(n),x2:x(n),y1:18,y2:82,stroke:'#8a9c8f','stroke-dasharray':n?'3 3':'none'});shape('text',{x:x(n),y:12,'text-anchor':'middle',fill:'#4b6655','font-size':10},String(n));}
 tuning.forEach((s,i)=>{const y=25+i*16,row=stops.filter(c=>c.name===s.name);
  shape('line',{x1:65,x2:350,y1:y,y2:y,stroke:row.length?'#285b46':'#c6d0c5','stroke-width':row.length?3:1});shape('text',{x:10,y:y+5,'font-size':15,fill:'#234a38'},s.name+'弦');
  for(const c of row){shape('circle',{cx:x(c.offset),cy:y,r:8,fill:'#285b46','data-current-pitch':c.pitch,'data-string':c.name});if(c.finger!==undefined)shape('text',{x:x(c.offset),y:y+4,'text-anchor':'middle',fill:'white','font-size':12},String(c.finger));}
 });
 shape('text',{x:190,y:95,'text-anchor':'middle','font-size':10,fill:'#52695a'},'实心 = 当前音落点 · 数字 = 距空弦半音（非琴品）');
 shape('text',{x:190,y:106,'text-anchor':'middle','font-size':9,fill:'#6d7a6f'},stops.length>1?'多音仅分列落点，未验证同时按弦':'空弦为 0 · 高把位指法为练习建议');
 const desc=c=>c.name+'弦 · '+pitchName(c.pitch)+' · '+c.position+(c.finger===undefined||c.finger===0?'':c.finger==='拇'?' · 拇指':' · '+c.finger+' 指');
 recommendation.textContent=special?'源谱含特殊奏法，不推测按弦位置':note.rest?'休止':missing?'部分音高超出此指板范围，未画未知落点':stops.length>1?(fallback?'分别标音，未找到不同弦上的组合':'同时发声的音分别高亮；手型未审定'):stops[0]?desc(stops[0]):'无当前音';
 // The parent already gives this area a collapsed “换弦 / 换把看手形”.
 candidates.replaceChildren();
 if(options.length>1)for(const c of options){const b=documentObject.createElement('button');b.type='button';b.textContent=desc(c);b.setAttribute('aria-pressed',String(c.key===stops[0]?.key));b.onclick=()=>onSelect(c.key);candidates.append(b);}
}
