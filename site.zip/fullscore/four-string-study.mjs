import {drawTrialBoard} from './shared-board.mjs';
import {candidates as lowCandidates} from './fingering.mjs';
// Standard cello only: C2 G2 D3 A3. Educational suggestions, not source fingerings.
export const tuning=[{name:'A',midi:57},{name:'D',midi:50},{name:'G',midi:43},{name:'C',midi:36}];
export const patterns=[{name:'全全半',steps:[0,2,4,5]},{name:'全半全',steps:[0,2,3,5]},{name:'全全全',steps:[0,2,4,6]},{name:'半全全',steps:[0,1,3,5]}];
export const pitchName=m=>['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'][m%12]+(Math.floor(m/12)-1);
export const pointX=offset=>50+390*(1-2**(-offset/12));
export function locations(midi){if(!Number.isInteger(midi))return [];return tuning.map(s=>({...s,offset:midi-s.midi})).filter(s=>s.offset>=0&&s.offset<=31);}
export function thumbCandidates(midi){const out=[];if(!Number.isInteger(midi))return out;for(const s of tuning.slice(0,2))for(let anchor=12;anchor<=26;anchor++)for(const p of patterns){const finger=p.steps.indexOf(midi-s.midi-anchor);if(finger<0)continue;out.push({...s,offset:midi-s.midi,anchor,finger,pattern:p.name,steps:p.steps,key:`${s.name}:${anchor}:${p.name}:${finger}`});}return out.sort((a,b)=>a.anchor-b.anchor||tuning.findIndex(s=>s.name===a.name)-tuning.findIndex(s=>s.name===b.name));}
export function bassClefView(xml){return xml.replace(/<clef\b[^>]*>[\s\S]*?<\/clef>/g,c=>c.replace(/<sign>[\s\S]*?<\/sign>/,'<sign>F</sign>').replace(/<line>[\s\S]*?<\/line>/,'<line>4</line>'));}
export function renderFourStringStudy(note,{board,recommendation,candidates,selection,onSelect,compact=false,knownStops=[],documentObject=globalThis.document}){
 if(compact)return renderCompactStudy(note,{board,recommendation,candidates,selection,onSelect,documentObject});
 const midis=[...new Set((note.sounding ?? note.notes ?? []).filter(n=>!n.rest&&!n.cue).map(n=>n.midi).filter(Number.isInteger))];
 if(!midis.length&&!Array.isArray(note.sounding)&&Number.isInteger(note.midi))midis.push(note.midi);
 const special=!!note.unsupportedTechniques?.length;
 if(special)midis.length=0; // Written harmonic pitch is not a verified stopped-string sounding location.
 const cs=!note.polyphonic&&midis.length===1&&!note.unsupportedTechniques?.length?thumbCandidates(midis[0]):[];
 const chosen=cs.find(c=>c.key===selection)||cs.find(c=>c.name==='A')||cs[0];
 // These are already-resolved source player choices, not a new placement algorithm.
 const fallback=knownStops.filter(c=>c&&!c.rest&&midis.includes(c.midi+c.offset))
  .map(c=>({name:c.name,offset:c.offset,pitch:c.midi+c.offset,finger:c.finger,position:c.pos}));
 const stops=chosen?[{name:chosen.name,offset:chosen.offset,pitch:chosen.midi+chosen.offset,
   finger:chosen.finger===0?'拇':chosen.finger,position:'拇指把位'}]:fallback;
 drawTrialBoard(board,{},{stops,rest:!!note.rest,special,unverifiedTogether:stops.length>1},documentObject);
 const desc=c=>`${c.name}弦 · 拇指锚点${pitchName(c.midi+c.anchor)} · ${c.finger===0?'拇指':c.finger+'指'} · ${c.pattern}`;
 recommendation.textContent=special?'源谱含特殊奏法：保留记谱与试听，不把书写音高当作实响按弦落点':chosen?'四弦练习候选：'+desc(chosen)+'（非原谱指法，可切换）':note.rest?'休止':midis.length>1?'四弦各音落点；和弦组合需分弓/手型核对，不自动推荐同时按弦': stops[0]?stops[0].name+' 弦 · 指法：'+(stops[0].finger===0?'空弦（不按指）':stops[0].finger+' 指')+' · 把位：'+(stops[0].offset===0?'不适用':stops[0].position):'此音未指定可靠弦或指法；不画假落点';
 candidates.replaceChildren();for(const c of cs.slice(0,32)){const b=documentObject.createElement('button');b.textContent=desc(c);b.setAttribute('aria-pressed',String(c.key===chosen?.key));b.onclick=()=>onSelect(c.key);candidates.append(b);}
}

// One default stop per sounding pitch; candidate choice never changes audio.
export function compactStudyStops(note, selection){
 if(note.unsupportedTechniques?.length)return {options:[],stops:[],special:true};
 const sounds=note.sounding??note.notes??[],midis=[...new Set(sounds.filter(n=>!n.rest&&!n.cue).map(n=>n.midi).filter(Number.isInteger))].sort((a,b)=>b-a);
 if(!midis.length&&!Array.isArray(note.sounding)&&!note.rest&&Number.isInteger(note.midi))midis.push(note.midi);
 const candidatesFor=midi=>locations(midi).map(loc=>{
   const low=lowCandidates({midi}).find(c=>c.name===loc.name&&c.offset===loc.offset);
   const thumb=thumbCandidates(midi).find(c=>c.name===loc.name);
   return {...loc,pitch:midi,key:loc.name+':'+loc.offset,finger:loc.offset===0?0:(low?.finger??(thumb?.finger===0?'拇':thumb?.finger)),position:loc.offset===0?'空弦':(low?.pos??(thumb?'拇指把位':'高把位参考'))};
 }).sort((a,b)=>(a.offset===0?-1:0)-(b.offset===0?-1:0)||a.offset-b.offset);
 const groups=midis.map(candidatesFor),available=groups.filter(g=>g.length);
 const fit=(i,used)=>i===available.length?[]:available[i].map(c=>{
   if(used.includes(c.name))return null;const rest=fit(i+1,[...used,c.name]);return rest?[c,...rest]:null;
 }).find(Boolean)??null;
 if(midis.length===1){const options=groups[0];return {options,stops:options.length?[options.find(c=>c.key===selection)??options[0]]:[],missing:!options.length};}
 const unique=available.length>4?null:fit(0,[]);
 return {options:[],stops:unique??available.map(g=>g[0]),missing:available.length!==groups.length,fallback:!unique};
}
// Use the trusted written pitch of this sounding note for labels only; never infer spelling from an accidental glyph.
function compactPitchLabel(note,midi){
 const names=new Set();
 for(const n of note.sounding??note.notes??[]){
   const p=n.pitch;
   if(n.rest||n.cue||n.midi!==midi||!p||!['A','B','C','D','E','F','G'].includes(p.step)||!Number.isInteger(p.octave)||!Number.isInteger(p.alter)||Math.abs(p.alter)>2)continue;
   const base={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
   if((p.octave+1)*12+base[p.step]+p.alter===midi)names.add(p.step+['♭♭','♭','','♯','♯♯'][p.alter+2]+p.octave);
 }
 return names.size===1?[...names][0]:pitchName(midi);
}
function renderCompactStudy(note,{board,recommendation,candidates,selection,onSelect,documentObject}){
 const {options,stops,special,missing,fallback}=compactStudyStops(note,selection);
 drawTrialBoard(board,{},{stops,rest:!!note.rest,special,unverifiedTogether:stops.length>1},documentObject);
 const desc=c=>c.name+' 弦 · '+compactPitchLabel(note,c.pitch)+' · 指法：'+(c.offset===0?'空弦（不按指）':c.finger===undefined?'未指定':c.finger==='拇'?'拇指':c.finger+' 指')+' · 把位：'+(c.offset===0?'不适用':c.position);
 recommendation.textContent=special?'源谱含特殊奏法，不推测按弦位置':note.rest?'休止':missing?'部分音高超出此指板范围，未画未知落点':stops.length>1?(fallback?'分别标音，未找到不同弦上的组合':'同时发声的音分别高亮；手型未审定'):stops[0]?desc(stops[0]):'无当前音';
 // The parent already gives this area a collapsed “换弦 / 换把看手形”.
 candidates.replaceChildren();
 if(options.length>1)for(const c of options){const b=documentObject.createElement('button');b.type='button';b.textContent=desc(c);b.setAttribute('aria-pressed',String(c.key===stops[0]?.key));b.onclick=()=>onSelect(c.key);candidates.append(b);}
}
