// Standard cello only: C2 G2 D3 A3. Educational suggestions, not source fingerings.
export const tuning=[{name:'A',midi:57},{name:'D',midi:50},{name:'G',midi:43},{name:'C',midi:36}];
export const patterns=[{name:'全全半',steps:[0,2,4,5]},{name:'全半全',steps:[0,2,3,5]},{name:'全全全',steps:[0,2,4,6]},{name:'半全全',steps:[0,1,3,5]}];
export const pitchName=m=>['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'][m%12]+(Math.floor(m/12)-1);
export const pointX=offset=>50+390*(1-2**(-offset/12));
export function locations(midi){if(!Number.isInteger(midi))return [];return tuning.map(s=>({...s,offset:midi-s.midi})).filter(s=>s.offset>=0&&s.offset<=31);}
export function thumbCandidates(midi){const out=[];if(!Number.isInteger(midi))return out;for(const s of tuning.slice(0,2))for(let anchor=12;anchor<=26;anchor++)for(const p of patterns){const finger=p.steps.indexOf(midi-s.midi-anchor);if(finger<0)continue;out.push({...s,offset:midi-s.midi,anchor,finger,pattern:p.name,steps:p.steps,key:`${s.name}:${anchor}:${p.name}:${finger}`});}return out.sort((a,b)=>a.anchor-b.anchor||tuning.findIndex(s=>s.name===a.name)-tuning.findIndex(s=>s.name===b.name));}
export function bassClefView(xml){return xml.replace(/<clef\b[^>]*>[\s\S]*?<\/clef>/g,c=>c.replace(/<sign>[\s\S]*?<\/sign>/,'<sign>F</sign>').replace(/<line>[\s\S]*?<\/line>/,'<line>4</line>'));}
export function renderFourStringStudy(note,{board,recommendation,candidates,selection,onSelect,documentObject=globalThis.document}){
 const ns='http://www.w3.org/2000/svg',shape=(tag,attrs,text)=>{const e=documentObject.createElementNS(ns,tag);Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));if(text)e.textContent=text;board.append(e);return e;};
 board.replaceChildren();board.setAttribute('viewBox','0 0 410 130');board.setAttribute('aria-label','四弦全指板理论音高落点；A、D、G、C 弦，从空弦至31半音，不新增第五弦');
 for(const off of [0,2,5,7,9,12,17,19,24,29,31]){const x=pointX(off);shape('line',{x1:x,x2:x,y1:24,y2:93,stroke:'#b5c6b9','stroke-dasharray':'2 3'});shape('text',{x,y:17,'font-size':9,'text-anchor':'middle'},String(off));}
 const midis=[...new Set((note.sounding ?? note.notes ?? []).filter(n=>!n.rest&&!n.cue).map(n=>n.midi).filter(Number.isInteger))];
 if(!midis.length&&!Array.isArray(note.sounding)&&Number.isInteger(note.midi))midis.push(note.midi);
 const special=!!note.unsupportedTechniques?.length;
 if(special)midis.length=0; // Written harmonic pitch is not a verified stopped-string sounding location.
 const cs=!note.polyphonic&&midis.length===1&&!note.unsupportedTechniques?.length?thumbCandidates(midis[0]):[];
 const chosen=cs.find(c=>c.key===selection)||cs.find(c=>c.name==='A')||cs[0];
 tuning.forEach((s,i)=>{const y=35+i*18;shape('text',{x:8,y:y+4,'font-size':13},s.name+'弦');shape('line',{x1:50,x2:380,y1:y,y2:y,stroke:'#728f7a'});for(const midi of midis){const loc=locations(midi).find(l=>l.name===s.name);if(!loc)continue;const selected=chosen?.name===s.name&&chosen.offset===loc.offset;shape('circle',{cx:pointX(loc.offset),cy:y,r:selected?7:4,fill:selected?'#255f45':'#fff',stroke:'#255f45'});if(selected)shape('text',{x:pointX(loc.offset),y:y+3,'text-anchor':'middle',fill:'white','font-size':10},chosen.finger===0?'拇':String(chosen.finger));}});
 shape('text',{x:205,y:113,'text-anchor':'middle','font-size':10},'上方数字 = 距空弦半音；实心 = 所选练习候选；空心 = 可选音高落点');
 shape('text',{x:205,y:127,'text-anchor':'middle','font-size':10},'保持原音高 · 不是移调 · 多音落点不代表可以同时按下');
 const desc=c=>`${c.name}弦 · 拇指锚点${pitchName(c.midi+c.anchor)} · ${c.finger===0?'拇指':c.finger+'指'} · ${c.pattern}`;
 recommendation.textContent=special?'源谱含特殊奏法：保留记谱与试听，不把书写音高当作实响按弦落点':chosen?'四弦练习候选：'+desc(chosen)+'（非原谱指法，可切换）':note.rest?'休止':midis.length>1?'四弦各音落点；和弦组合需分弓/手型核对，不自动推荐同时按弦': '四弦音高落点参考；此音未生成拇指手型';
 candidates.replaceChildren();for(const c of cs.slice(0,32)){const b=documentObject.createElement('button');b.textContent=desc(c);b.setAttribute('aria-pressed',String(c.key===chosen?.key));b.onclick=()=>onSelect(c.key);candidates.append(b);}
}
