# Suite II Courante: complete independent written movement
2026-11-15. Source is a DIFFERENT MXL, not copied Suite I repertoire:
pdmx-review-20261115/six-mxl/QmaLP7iqyqextuctycxSpPJRYDQnAQaq1agNVPrzFNWM1h.mxl
SHA25668bbade1370609f364e85b3e5b083838ce2987265b74d7d0159824de8b69532c.
Raw archive-member XML preserved byte-for-byte. PDMX v9 https://zenodo.org/records/15571083 ; archived score https://musescore.com/user/13057/scores/4430776 .
Archived uploader license cc-zero / https://creativecommons.org/publicdomain/zero/1.0/ ; embedded rights empty, not independent copyright clearance.

Courante source90–123,34 written nodes375 note elements. Source divisions=8; do NOT apply Suite I divisions24. Key1 flat,3/4 meter, tempo90 at90. Implicit opening repeat anchored90 and explicit forward107; backward106/123. Route90–106 twice,107–123 twice:68 visits192 quarterbeats,128s at90 BPM.
90/107 pickups each1/4;106/123 complements each11/4; all other written measures3 quarters. Real4tie pairs at92,96,109,113 are within their measures.750 repeated events ->742 merged sound events, no reattack at ties. Raw pitches/voices/timing and source references retained.
No source grace,trill,mordent,fermata,chord or ending in this movement. No ornament substitution/suggested grace timing needed. Scope acknowledgement required, default no playback; no misleading extra ornament toggle.
Slurs retained as notation, no physical bow articulation/dynamics/cello timbre claim. Unknown notation/ornaments/special tuning/navigation rejected; this is not a generic full-suite engine.
Independent original-MXL/metadata and full SuiteII audit passed; every375 source note and742 merged event independently checked, with correct divisions8. Five explicitly synthetic rejection tests passed. Shared actual-entry silent regression46 groups passed across4558 events, including68 SuiteII visits. Evidence INDEPENDENT-QA.json and ../../INDEPENDENT-HUB-QA.json. No deployment, actual browser/listening/phone/headphones/professional acceptance.
