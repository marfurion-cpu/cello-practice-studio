# Complete Courante, opt-in suggested rendition (isolated)
2026-11-15 UTC. Not deployed. Earlier candidates and v13/release archives unchanged.

## Real-source scope
Source is original Suite I MXL member copied byte-identically, hash checked against source-audit.json. PDMX v9 https://zenodo.org/records/15571083 ; archived source https://musescore.com/user/13057/scores/4395821 . Uploader metadata asserts CC0 1.0 https://creativecommons.org/publicdomain/zero/1.0/ ; embedded rights absent, not independent copyright clearance.
Complete Courante written source nodes77–120, bounded by Courante heading at77 and Sarabande at121:44 measure nodes including pickup/complement nodes,411 note elements. Not six suites or formal V14.
Route77–95 twice,96–120 twice. Opening implicit repeat anchored at movement77, not suite1.88 visits,252 quarterbeats.77/96 each1/2 beat,95/120 each5/2; remaining nodes3 beats.
Expanded822 source events merge two repeated occurrences of104's D-sharp4 tie into820 continuous events. No reattack at the tie junction.

## Explicit optional override, not MusicXML-default fidelity
Three real empty trill-mark elements:87 C-sharp4,93 F-sharp3,116 B3. There are no explicit ornament parameters, BUT MusicXML still defines defaults.
Official reference: https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/trill-mark/
Defaults include3 attacks, main start, whole-step neighbor, second/last attack at12%/24%, no acceleration, no terminal two-note turn. These defaults are recorded separately in plan metadata. They must NOT be confused with unspecified semantics.
This candidate offers only an explicitly chosen ALGORITHMIC OVERRIDE: four equal attacks main/upper/main/upper within original duration, using D4/G3/C4 as diatonic G-major neighbors. This differs from standard-default whole-step neighbors and timing. It is a selectable practice suggestion, NOT composer-specified timing, normative default playback, historical interpretation or professional musical certification.
6 performed trill occurrences add18 events ->838 total suggested events, with no score duration change. Every suggested attack retains source reference, original pitch/duration and suggestedOrnament flag.
Both UI acknowledgements default unchecked; playback defaults disabled. Turning suggestion off stops and DISABLES playback; no plain-note fallback that silently drops trills. Standard-default trill playback is NOT implemented/claimed.

## Boundaries
All original XML retained. New grace/fermata, unknown ornaments/parameters, endings, navigation, special tuning/transposition rejected. Combined trill/tie rejected. Fixed80 BPM189s chosen consistently with the source's80 mark, including pickup. Sine audition does not reproduce cello timbre, dynamics, bowing or professional phrasing.
This is full written-movement coverage with an optional declared ornament interpretation, not proof that every interpretive aspect of the score is rendered.
No actual browser, listening, iPhone, earphone or professional acceptance. UI operates locally only.

## Reproduce
python cello-real-courante-candidate-20261115/plan.py
Actual entry index.html -> app.mjs -> player.mjs -> practice-plan.json.
Independent source/route QA passed: every411 written notes,822 expanded notes,820 tie-merged events,838 suggested events,88 visits252 beats. Actual HTML/mount WebAudio silent simulation13 groups passed, including838 schedules and all88 cursor visits. Three clearly synthetic unsupported-symbol rejection checks passed. See INDEPENDENT-QA.json / INDEPENDENT-PLAYER-QA.json; reproduce independent_qa.py and independent-player-qa.mjs.
