# Complete Prelude with explicit optional fermata suggestion
Checked2026-11-15. Integrated only via shared hub, no new standalone song page. Original raw XML/MXL identity retained. PDMX v9 https://zenodo.org/records/15571083 ; archived source https://musescore.com/user/13057/scores/4395821 . Uploader CC0 1.0 assertion https://creativecommons.org/publicdomain/zero/1.0/ , embedded rights absent, not independent copyright clearance.

## Source facts
Complete Prelude source1–42,42 four-quarter measures,693 note elements,168 notated quarterbeats. No repeats,grace,trill or other ornaments.
Source22 note7 D4:half-quarter duration and tie-start, normal upright fermata; note8 tie-stop quarter-quarter. Merged written duration3/4.
Source42 note1 G2 whole-note4 quarters with fermata; note2 B3 and note3 G4 chord elements share onset and4-quarter duration. Original chord metadata and all notes retained.
https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/fermata/ specifies sign shape/orientation, not a mandated2x hold. This candidate's duration rule is a practice choice, NOT a source-prescribed value.

## Declared optional timing
Tie merging yields692 events. Define source-quarterbeat intervals[85.5,86] and[164,168] from the two marked source notes. The explicit suggestion stretches each interval2x on a single monotonic time axis, shifting all later events consistently. W(t)=t+clamp(t−85.5,0,0.5)+clamp(t−164,0,4).
Each event starts atW(originalStart) and ends atW(originalEnd). Thus22 D4 stays one continuous event, duration3/4->5/4, not two attacks. All three final chord tones extend4->8 quarters with identical start/end. Original168 beat notation is unchanged, separate suggested timing172.5 baseline-quarterbeats,129.375s at80 BPM.
This is NOT professional fermata duration, cello bowing, dynamics or triple-stop technique. No manual/conductor-responsive hold is claimed.
Full source refs/original timing remain next to suggested timing. Both scope and suggestion confirmation default OFF; disabling stops and prohibits playback rather than discarding fermatas.
Other fermata profiles/types,ornaments,grace,repeat/navigation and special tuning/transposition are rejected; this is pinned-source support, not generic MusicXML completeness.

Independent raw-source QA passed693 notes,692 events and warp using separate interval integration; source22 tied tone and final three chord tones verified. Four explicitly synthetic unsupported-symbol rejection tests passed. Shared-entry silent regression38 groups/2824 events passed including allPrelude events and42 visits. See INDEPENDENT-QA.json and ../../INDEPENDENT-HUB-QA.json; reproduce independent_qa.py and parent independent-hub-qa.mjs. No actual browser/listening/mobile/headphones/professional validation. No deployment or prior candidate edits.
Known slur notation is preserved but no physical bow/legato model is claimed. A notations-child allowlist (slur,tied,fermata) rejects unknown additional symbols rather than silently dropping them; source hash remains pinned.
