# Suite I Menuet II isolated practice candidate
2026-11-15. Derived local player from sibling Menuet I candidate, but separately validated against same original MXL/XML.
Source original byte-identical, SHA256/source provenance retained in source-audit.json and source.xml. PDMX v9 https://zenodo.org/records/15571083 ; archived source https://musescore.com/user/13057/scores/4395821 . Archived uploader CC0 1.0 assertion, embedded rights absent; not independent copyright clearance.
Explicit practice nodes161–184 only: first8 twice, next16 twice,48 visits144 quarterbeats; fixed90 BPM. Source126 note elements,252 performed events. No grace, tie, chord or trill tags in selection.
D.C. at184 is retained in original but explicitly NOT executed at this declared practice endpoint. Full paired-dance/full-suite navigation remains unsupported. UI requires explicit confirmation. No deploy or old candidate changes.
No actual browser, listening, iPhone or headphones validation; independent silent entry QA14 groups passed. Original MXL source126 notes (voice1 only),252 performed events checked independently note-by-note for pitch, duration and local/absolute onset. Six90-BPM slices each16seconds and actual HTML+mount gate/stop/selection/visibility/pagehide/async-cancel simulation passed. Evidence INDEPENDENT-QA.json and INDEPENDENT-PLAYER-QA.json; reproduce independent_qa.py and independent-player-qa.mjs.

## Remaining Suite I movement feasibility
Assessment derives directly from retained original XML: suite-I-movement-assessment.json (reproduce with assess_movements.py). Heading node ranges are not independently authoritative completeness proof.
- Prelude1–42: real ties at22, fermata22/42, chord tags42. Existing player cannot silently ignore fermata or reattack a tied note. A later explicitly designed fermata pause/resume plus tie QA is required.
- Allemande43–76: grace63; trill48/54/55/57/63/64/65/67, mordent51, ties44/61. Not eligible for this simple audition.
- Courante77–120: trill87/93/116 and tie104; includes pickup considerations.
- Sarabande121–136: trill122/124/126/130/131 and tie135.
- Gigue185–220: trill189 and incoming coda185, pickup/6–8. Not eligible without ornament and context handling.
None of these has been declared playable merely because notes can be read. Menuet II is a declared standalone practice selection, not proof of paired-dance return or full suite completeness. Both Menuets now have separate experimental entrypoints; no existing V14/main UI changes.
