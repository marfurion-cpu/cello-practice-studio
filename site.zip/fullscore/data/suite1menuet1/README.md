# Real Suite I Menuet I: isolated event-plan candidate
Checked 2026-11-15 UTC. This is an isolated, explicitly selected excerpt audition candidate, NOT a deployed player or complete-suite import.

## Original evidence retained
Original MXL: ../pdmx-review-20261115/six-mxl/QmU92kuEMsqZQRpdX6eY8a6iyvWYaYNg98MK3uzbSbmZBz.mxl
SHA256: 55efa2c091d31bfc932e4e2d0a87be3bdfb9f5c63588cf210efe9622ab3e25ae
source.xml is the byte-identical original archive XML member, not rewritten or a newly generated conversion.
Origin PDMX v9 https://zenodo.org/records/15571083 ; archived source https://musescore.com/user/13057/scores/4395821 .
Archived uploader metadata asserts CC0 1.0 https://creativecommons.org/publicdomain/zero/1.0/ . Embedded rights absent; not independent copyright verification. Keep provenance with any derived plan.

## Precise scope
Menuet I source nodes137–160 (24 written measures):134 note elements, no grace in this edition's selection. Source audit retains full XML for each note and inherited attributes; paired Menuet I+II audit covers260 note elements and voices1–3.
Explicit practice mode plans137–144 twice then145–160 twice:48 visits,144 quarter beats,268 note/rest events. Exact rational timing and voice labels preserved. This real selection has no chord tags, so it does not validate the chord-anchor branch.
This differs from the DCMLab MSCX edition's known ornament at Menuet I measure4. Absence here is not evidence that ornament support was solved or that editions are equivalent.

## Navigation safety
Full-suite/menuet-pair playback remains UNSUPPORTED. Entry without acknowledge_excerpt=True fails closed.
Source node137 contains segno,160 To Coda,184 D.C. plus backward repeat,185 coda at Gigue. W3C specifies dacapo returns to movement start; mapping this to whole-suite node1 would be wrong. Coda jump defaults to second pass, demanding navigation context beyond naive repeat counting.
https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/sound/
The explicit excerpt has a declared stop boundary after160 and reports the outgoing To Coda as not executed. It DOES NOT delete any navigation in source.xml or claim original complete performance. No generic D.C. repair is asserted.

## Reproduce
python cello-real-menuet-candidate-20261115/audit.py
python cello-real-menuet-candidate-20261115/practice.py
The local index.html/app.mjs entry now connects the selected plan through player.mjs to WebAudio sine oscillators, with an explicit excerpt acknowledgement, six selectable8-visit slices at98 BPM, stop/selection/visibility/pagehide protection. No actual browser, iPhone, hearing, earphone or musical professional validation. No source original, v13, existing candidate or release archive changed. SuitesV scordatura/VI five-string are outside this work. Independent QA passed source-member identity, all134 source notes and268 performed events (pitch, voice, duration, local/performed onset),48 visits144 beats and acknowledgement rejection. See INDEPENDENT-QA.json and independent_qa.py. This remains event-plan QA, not actual playback. Entry integration passed14 independent silent DOM/WebAudio simulation groups: actual HTML and mount wiring, all6 slices268 events, frequency/onset/duration, acknowledgement, stop, selection, acknowledgement withdrawal, visibility/pagehide, async-resume cancellation. Evidence INDEPENDENT-PLAYER-QA.json and independent-player-qa.mjs. Actual audio remains unverified. Resolve complete movement navigation separately; do not interpret silent tests as hearing validation.
