# Suite I Gigue complete-movement suggested rendition
Checked2026-11-15 UTC. Separate candidate, not deployed; earlier Courante/Menuet/tie candidates and v13/release unchanged.

## Real source
PDMX v9 https://zenodo.org/records/15571083
Archived score https://musescore.com/user/13057/scores/4395821
Uploader metadata asserts CC0 1.0 https://creativecommons.org/publicdomain/zero/1.0/ ; embedded rights absent, not independent copyright verification. source.xml byte-identical to the retained original MXL member; source-audit.json holds identity and provenance.
Gigue starts at source185 and ends at220, the original suite's end.36 measure nodes including two pickup/complement pairs,213 note elements. No source grace, fermata, tie or chord tags here; no claim that this verifies such capabilities.
Repeated route185–197 twice then198–220 twice:72 visits204 quarterbeats.185/198 each1/2,197/220 each5/2, remaining3. Source sound tempo144 quarter notes/minute, so85 seconds at this fixed tempo (6/8 notation). Do not confuse this with144 dotted-quarter beats.
A coda sign and sound coda=coda at185 are the prior dance's landing marker. This isolated movement starts there directly; it does not execute or claim complete preceding Da Capo/To Coda navigation. Source marker preserved; other coda placements or sound navigation are rejected.

## Ornament interpretation
One empty trill-mark at source189 B3, duration3/2 quarterbeats, performed twice. Source default parameters are not absent semantics:
https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/trill-mark/
MusicXML defaults3 attacks/main start/whole neighbor/second12%/last24%, no acceleration or terminal turn. Metadata records these.
Our opt-in algorithm explicitly overrides defaults:4 equal attacks B3/C4/B3/C4 within the original3/2 beats. This is a diatonic suggested practice interpretation, not standard-default playback, composer-specific timing, historical authenticity or professional certification.426 source-performance events become432 suggested events, duration unchanged.
Two confirmations are OFF by default; no playback unless both selected. Closing suggestion stops and disables audio, never drops the trill to play plain notes.

## Safety and fidelity boundaries
No new grace, fermata, unknown ornament or parameters, ending, special tuning/transposition, or outgoing navigation silently ignored. Source-notated rhythms and pitch events retained with separate suggestion fields. Sine oscillator audition is not cello sound/bow articulation/dynamics performance. No actual browser, listening, phone or headphones acceptance.
This covers one full written movement under a transparent optional interpretation, NOT six-suite completion or formalV14.

## Reproduce
python cello-real-gigue-candidate-20261115/plan.py
Entry index.html -> app.mjs -> player.mjs -> practice-plan.json.
Independent full-source QA passed213 written notes,426 expanded source events,432 suggested events,72 visits204 beats,85 seconds. Actual HTML/mount silent WebAudio simulation13 groups passed, all432 schedules and72 cursor visits;5 explicitly synthetic unsupported-symbol/navigation rejection checks passed. Evidence INDEPENDENT-QA.json and INDEPENDENT-PLAYER-QA.json; rerun independent_qa.py and independent-player-qa.mjs.
