import {parseMusicXML,tiedPlaybackPlan} from './musicxml-events.mjs';
import {verifyBytes} from './verified-courante.mjs';
const num=f=>f.n/f.d,frac=x=>{const n=x*96;if(!Number.isSafeInteger(n))throw Error("Unsupported exact Sarabande time");return {n,d:96}},rat=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b);
const midi=p=>12*(Number(p.octave)+1)+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[p.step])+Number(p.alter||0);
export async function adaptSarabande(xml,planText,options={}){
 await verifyBytes(xml,'4b81b8e48e21a1e9db884a11151ca067b88cc66d57c6264dd74f29650b4fd899');await verifyBytes(planText,'c0da0d3e7f3e822526ab58b6a3f8496a8a66e4584ae11b0b614252e2c1b08dc6');
 const plan=JSON.parse(planText),written=parseMusicXML(xml,options),route=plan.sourceRoute.map(x=>x-120);
 if(written.measures.length!==16||written.notes.length!==157||plan.events.length!==342||route.length!==32)throw Error('Sarabande I内置范围不一致');
 const bySource=new Map();for(let i=0;i<written.notes.length;i++){const a=written.notes[i],b=plan.writtenNotes[i];if(a.measureIndex+121!==b.sourceMeasure||a.voice!==b.voice||a.beats!==rat(b.duration)||num(a.onsetInMeasure)!==rat(b.onset)||JSON.stringify(a.pitch&&[a.pitch.step,a.pitch.alter,a.pitch.octave])!==JSON.stringify(b.pitch&&[b.pitch.step,Number(b.pitch.alter||0),Number(b.pitch.octave)]))throw Error('Sarabande I源音符不一致');bySource.set(`${b.sourceMeasure}/${b.sourceNote}`,a);}
 const performance=plan.performedSourceNotes.flatMap(e=>e.trill?plan.events.filter(x=>x.visit===e.visit&&x.sourceMeasure===e.sourceMeasure&&x.sourceNote===e.sourceNote):[e]);
 const notes=performance.map((e,i)=>{const n=bySource.get(`${e.sourceMeasure}/${e.sourceNote}`),pitch=e.pitch?{step:e.pitch.step,alter:Number(e.pitch.alter||0),octave:Number(e.pitch.octave)}:null,vi=e.visit-1;
 if(!n)throw Error('Unexpected Sarabande I source or tie');
 const slurs=e.suggestedOrnament?n.slurs.filter(s=>s.type==='start'?e.ornamentAttack===1:s.type==='stop'?e.ornamentAttack===4:false):n.slurs;
 return {...n,id:`v${vi}:attack${i}:${n.id}`,order:i,measureIndex:vi,measureNumber:String(e.sourceMeasure),onset:frac(rat(e.performedOnset)),duration:frac(rat(e.duration)),beats:rat(e.duration),pitch,midi:pitch?midi(pitch):null,slurs,sourceQuarter:num(n.onset),sourceNoteId:n.id,sourceMeasure:e.sourceMeasure,visit:vi,suggestedOrnament:!!e.suggestedOrnament,sourceOriginalPitch:n.pitch};});
 const measures=plan.visits.map((v,vi)=>{const source=written.measures[v.sourceMeasure-121];if(num(source.duration)!==rat(v.duration))throw Error('Sarabande I measure duration');return {...source,index:vi,number:String(v.sourceMeasure),onset:frac(rat(v.onset)),noteIds:notes.filter(n=>n.measureIndex===vi).map(n=>n.id),sourceQuarter:num(source.onset),sourceOrdinal:source.index+1};});
 const groups=new Map();for(const n of notes){const t=num(n.onset);if(!groups.has(t))groups.set(t,[]);groups.get(t).push(n);}const events=[...groups].sort((a,b)=>a[0]-b[0]).map(([t,ns],index)=>({index,onset:frac(t),onsetBeats:t,notes:ns,noteIds:ns.map(n=>n.id)}));
 const score={...written,notes,measures,events,totalBeats:96,totalDuration:frac(96),verifiedPractice:true,suggestedTrill:true,displayRoute:route,writtenMeasureCount:16};
 const actual=tiedPlaybackPlan(score,60).notes,expected=plan.events.filter(n=>n.pitch).map(n=>({midi:midi(n.pitch),voice:n.voice,time:rat(n.performedOnset),duration:rat(n.duration)})),sort=xs=>xs.map(n=>[n.time,n.duration,n.midi,n.voice]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 if(JSON.stringify(sort(actual))!==JSON.stringify(sort(expected)))throw Error('Sarabande I播放计划不一致');return score;
}
