/* Standalone MusicXML timeline adapter. No I/O, storage, UI or dependency. */
const children=(n,name)=>(n.children||[]).filter(x=>!name||x.name===name);
const first=(n,name)=>children(n,name)[0];
const value=(n,name)=>first(n,name)?.text?.trim()||'';
const attrs=n=>({...n?.attrs});
function integer(x,label,{min=0}={}){if(!/^-?\d+$/.test(String(x)))throw Error(label+' must be an integer');const n=Number(x);if(!Number.isSafeInteger(n)||n<min)throw Error(label+' is out of range');return n;}
const gcd=(a,b)=>b?gcd(b,a%b):a;
function frac(n,d=1){if(!Number.isSafeInteger(n)||!Number.isSafeInteger(d)||d<=0)throw Error('Timing exceeds safe exact range');const g=gcd(Math.abs(n),d);return {n:n/g,d:d/g};}
const add=(a,b)=>frac(a.n*b.d+b.n*a.d,a.d*b.d);
const neg=a=>({n:-a.n,d:a.d});
const cmp=(a,b)=>a.n*b.d-b.n*a.d;
const key=a=>`${a.n}/${a.d}`;
const decimal=a=>a.n/a.d;
const walk=(n,name)=>[...(n.name===name?[n]:[]),...(n.children||[]).flatMap(x=>walk(x,name))];
const zero=()=>frac(0);
export function normalizeDOM(node){return {name:node.localName,attrs:Object.fromEntries(Array.from(node.attributes||[]).map(a=>[a.name,a.value])),text:node.textContent||'',children:Array.from(node.childNodes||[]).filter(n=>n.nodeType===1).map(normalizeDOM)};}
export function parseMusicXML(xml,{DOMParserClass=globalThis.DOMParser,maxLength=8_000_000}={}){
 if(typeof xml!=='string'||xml.length>maxLength)throw Error('MusicXML exceeds input size limit');
 if(/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('DTD/entities not supported; export plain MusicXML');
 if(!DOMParserClass)throw Error('DOMParser unavailable');
 const doc=new DOMParserClass().parseFromString(xml,'application/xml');
 if(!doc.documentElement||doc.getElementsByTagName('parsererror').length)throw Error('Invalid XML');
 const result=parseMusicXMLTree(normalizeDOM(doc.documentElement));return {...result,originalXML:xml};
}
export function parseMusicXMLTree(root){
 if(root.name!=='score-partwise')throw Error('Only score-partwise is supported');
 const parts=children(root,'part');if(parts.length!==1)throw Error('Select a single cello part; multiple voices within that part are supported');
 for(const tag of ['scordatura','staff-tuning','capo','transpose','unpitched','grace'])if(walk(root,tag).length)throw Error(`Unsupported ${tag}; no notes imported`);
 const notes=[],measures=[],attributeEvents=[],directions=[],warnings=[];let divisions=null,absolute=zero(),order=0;
 let context={key:null,time:null,clefs:[],staves:1};
 for(const [mi,m]of children(parts[0],'measure').entries()){
  let cursor=zero(),extent=zero(),anchor=null;const measureNotes=[];const offset=absolute;
  for(const e of children(m)){
   if(e.name==='attributes'){
    if(first(e,'divisions'))divisions=integer(value(e,'divisions'),'divisions',{min:1});
    if(first(e,'staves'))context.staves=integer(value(e,'staves'),'staves',{min:1});
    if(context.staves!==1)throw Error('Multiple staves need a full-score renderer; no notes imported');
    if(first(e,'key'))context.key=first(e,'key');if(first(e,'time'))context.time=first(e,'time');
    if(children(e,'clef').length)context.clefs=children(e,'clef');
    attributeEvents.push({measureIndex:mi,onset:add(offset,cursor),context:structuredClone(context),source:e});continue;
   }
   if(e.name==='backup'||e.name==='forward'){
    if(!divisions)throw Error('divisions required before timing');
    const duration=frac(integer(value(e,'duration'),e.name+' duration',{min:1}),divisions);
    cursor=add(cursor,e.name==='backup'?neg(duration):duration);if(cursor.n<0)throw Error('backup precedes measure start');
    if(cmp(cursor,extent)>0)extent=cursor;anchor=null;continue;
   }
   if(e.name==='direction'){directions.push({measureIndex:mi,cursor:add(offset,cursor),divisions,source:e});continue;}
   if(e.name!=='note'){if(e.name==='barline')directions.push({measureIndex:mi,cursor:add(offset,cursor),divisions,source:e});continue;}
   if(!divisions)throw Error('divisions required before first note');
   const duration=frac(integer(value(e,'duration'),'note duration',{min:1}),divisions),voice=value(e,'voice')||'1',staff=value(e,'staff')||'1';
   if(staff!=='1')throw Error('Multiple staves unsupported');
   const chord=!!first(e,'chord'),rest=!!first(e,'rest');
   if(chord&&(!anchor||anchor.voice!==voice||anchor.rest||rest))throw Error('Chord note has no preceding pitched anchor in the same voice');
   if(chord&&cmp(duration,anchor.duration)>0)throw Error('Chord member duration exceeds anchor duration');
   const onsetInMeasure=chord?anchor.onsetInMeasure:cursor;
   let pitch=null,midi=null;
   if(!rest){const p=first(e,'pitch');if(!p)throw Error('Pitched note missing pitch');
    const step=value(p,'step'),octave=integer(value(p,'octave'),'octave'),alter=Number(value(p,'alter')||0),base={C:0,D:2,E:4,F:5,G:7,A:9,B:11}[step];
    if(base===undefined||!Number.isInteger(alter)||Math.abs(alter)>2)throw Error('Unsupported pitch spelling or microtone');midi=(octave+1)*12+base+alter;if(midi<0||midi>127)throw Error('MIDI pitch out of range');pitch={step,octave,alter};
   }
   const notation=first(e,'notations');
   const n={id:`p0-m${mi}-n${order}`,sourceId:e.attrs?.id||null,order:order++,measureIndex:mi,measureNumber:m.attrs?.number||String(mi+1),voice,staff,chord,rest,cue:!!first(e,'cue'),pitch,midi,onsetInMeasure,onset:add(offset,onsetInMeasure),duration,beats:decimal(duration),type:value(e,'type')||null,dots:children(e,'dot').length,accidental:first(e,'accidental')||null,stem:value(e,'stem')||null,beams:children(e,'beam'),ties:children(e,'tie').map(attrs),tied:notation?children(notation,'tied').map(attrs):[],slurs:notation?children(notation,'slur').map(attrs):[],timeModification:first(e,'time-modification')||null,notations:notation||null,source:e,context:structuredClone(context)};
   notes.push(n);measureNotes.push(n);
   if(!chord){anchor=n;cursor=add(cursor,duration);}const end=add(onsetInMeasure,duration);if(cmp(end,extent)>0)extent=end;
   if(notes.length>30000)throw Error('Note limit exceeded');
  }
  measures.push({index:mi,number:m.attrs?.number||String(mi+1),implicit:m.attrs?.implicit==='yes',onset:offset,duration:extent,noteIds:measureNotes.map(n=>n.id),source:m});absolute=add(absolute,extent);
 }
 if(!notes.length)throw Error('No notes');
 if(walk(root,'repeat').length||walk(root,'ending').length||walk(root,'sound').some(n=>['dacapo','dalsegno','tocoda','fine'].some(k=>k in(n.attrs||{}))))warnings.push('Playback uses written order; repeats/navigation are preserved, not expanded');
 if(walk(root,'fermata').length)warnings.push('Fermata is preserved; extra duration needs interpretation');
 warnings.push('Timing uses MusicXML duration/divisions; all voices retained. Fingering and bowing are not inferred.');
 const groups=new Map();for(const n of notes){const k=key(n.onset);if(!groups.has(k))groups.set(k,{onset:n.onset,notes:[]});groups.get(k).notes.push(n);}
 const events=[...groups.values()].sort((a,b)=>cmp(a.onset,b.onset)).map((e,i)=>({...e,index:i,onsetBeats:decimal(e.onset),noteIds:e.notes.map(n=>n.id)}));
 return {schema:'cello-polyphony/0.1',title:value(root,'movement-title')||value(first(root,'work')||{},'work-title')||'Imported score',notes,events,measures,attributeEvents,directions,totalDuration:absolute,totalBeats:decimal(absolute),sourceTree:root,warnings};
}
// One playback record per source note, including every chord/voice. Tie merging is deliberately separate.
export function rawPlaybackPlan(score,bpm=72){if(!Number.isFinite(bpm)||bpm<=0)throw Error('Invalid tempo');return {duration:score.totalBeats*60/bpm,notes:score.notes.filter(n=>!n.rest&&!n.cue).map(n=>({id:n.id,voice:n.voice,midi:n.midi,time:decimal(n.onset)*60/bpm,duration:decimal(n.duration)*60/bpm,ties:n.ties,tied:n.tied}))};}
export function tiedPlaybackPlan(score,bpm=72){
 const base=rawPlaybackPlan(score,bpm),out=[],active=new Map();
 for(const n of [...score.notes].sort((a,b)=>cmp(a.onset,b.onset)||a.order-b.order)){
  if(n.rest||n.cue)continue;
  // MusicXML tie controls sound; notations/tied controls engraving only.
  const types=new Set((n.ties||[]).map(t=>t.type));
  const k=`${n.voice}/${n.staff}/${n.midi}`;let item;
  if(types.has('stop')){item=active.get(k);if(!item||cmp(item.end,n.onset)!==0)throw Error(`Unmatched/noncontiguous tie at ${n.id}`);item.end=add(n.onset,n.duration);item.noteIds.push(n.id);active.delete(k);}
  else {if(active.has(k))throw Error(`Unclosed tie before ${n.id}`);item={midi:n.midi,voice:n.voice,onset:n.onset,end:add(n.onset,n.duration),noteIds:[n.id]};out.push(item);}
  if(types.has('start'))active.set(k,item);
 }
 if(active.size)throw Error('Open ties at end of imported score');
 return {duration:base.duration,notes:out.map(n=>({midi:n.midi,voice:n.voice,noteIds:n.noteIds,time:decimal(n.onset)*60/bpm,duration:decimal(add(n.end,neg(n.onset)))*60/bpm}))};
}
