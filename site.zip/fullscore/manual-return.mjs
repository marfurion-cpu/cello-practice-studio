// Manual navigation only. This does not execute D.C./D.S./Coda or an I-II-I plan.
export const RETURN_PAIRS=Object.freeze({
 suite1menuet2:'suite1menuet1',suite2menuet2:'suite2menuet1',
 suite3bourree2:'suite3bourree1',suite4bourree2:'suite4bourree1',
 suite5GavotteII:'suite5GavotteI',suite6gavotte2:'suite6gavotte1'
});
export function returnTarget({piece,acceptedRequest,request,measureIndex,measureCount}){
 if(acceptedRequest!==request||!Number.isInteger(measureCount)||measureCount<1||measureIndex!==measureCount-1)return null;
 return RETURN_PAIRS[piece]??null;
}
export function mountManualReturn({button,snapshot,stop,activate}){
 const sync=()=>{const target=returnTarget(snapshot());button.hidden=!target;button.disabled=!target;return target;};
 button.onclick=()=>{const target=sync();if(!target)return;stop();button.hidden=true;button.disabled=true;activate(target);};
 sync();return sync;
}
