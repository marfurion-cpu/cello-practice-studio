import {parseMusicXML} from './musicxml-events.mjs';
// Display annotations only. Pitch encodes step + alter + octave; key signatures
// and octave-shift are not applied again. Never feed annotations to audio/solve.
const children=(n,t)=>(n.children||[]).filter(x=>x.name===t),one=(n,t)=>children(n,t)[0],value=(n,t)=>one(n,t)?.text?.trim()||'';
const all=(n,t)=>[...(n.name===t?[n]:[]),...(n.children||[]).flatMap(x=>all(x,t))];
export function encodedPitchLabel(note){
 const p=one(note,'pitch');if(!p)return null;
 const step=value(p,'step'),raw=value(p,'alter'),alter=raw===''?0:Number(raw),octave=Number(value(p,'octave'));
 if(!/^[A-G]$/.test(step)||!/^\d+$/.test(value(p,'octave'))||!Number.isInteger(octave)||octave>9||!Number.isInteger(alter)||Math.abs(alter)>2)throw Error('音名标注不支持此音高拼写或微分音');
 const midi=(octave+1)*12+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[step])+alter;
 if(midi<0||midi>127)throw Error('音名超出支持音域');
 const accidental=({'-2':'𝄫','-1':'♭','0':'','1':'♯','2':'𝄪'})[alter];
 const special=all(note,'harmonic').length>0||all(note,'thumb-position').length>0;
 return {label:step+accidental+octave,midi,special};
}
export function labelPlan(root){
 if(all(root,'transpose').length)throw Error('移调乐器音名未支持，不推测实响');
 const result=[],warnings=[];let flatIndex=0;
 for(const part of children(root,'part'))for(const measure of children(part,'measure')){
  let anchor=null;
  for(const node of measure.children||[]){
   if(node.name!=='note'){if(['backup','forward'].includes(node.name))anchor=null;continue;}
   const noteIndex=flatIndex++,pitch=encodedPitchLabel(node),voice=value(node,'voice')||'1',staff=value(node,'staff')||'1';
   if(!pitch||node.attrs?.['print-object']==='no'){anchor=null;continue;}
   if(one(node,'grace')){warnings.push('装饰小音符暂不加音名，避免把标注放到主音上');anchor=null;continue;}
   const entry={noteIndex,...pitch,cue:!!one(node,'cue')};
   if(one(node,'chord')){
    if(!anchor||anchor.voice!==voice||anchor.staff!==staff)throw Error('和弦音名缺少同声部起音，不猜标注位置');
    anchor.notes.push(entry);
   }else{anchor={anchorIndex:noteIndex,voice,staff,notes:[entry]};result.push(anchor);}
  }
 }
 for(const group of result)group.text=group.notes.map(p=>(p.cue?'提示/不试听 ':p.special?'书写 ':'')+p.label).join(' / ');
 return {groups:result,warnings:[...new Set(warnings)],noteCount:flatIndex};
}
function normalized(el){return {name:el.localName||el.nodeName,text:Array.from(el.childNodes||[]).filter(x=>x.nodeType===3||x.nodeType===4).map(x=>x.nodeValue).join(''),attrs:Object.fromEntries(Array.from(el.attributes||[]).map(a=>[a.name,a.value])),children:Array.from(el.childNodes||[]).filter(x=>x.nodeType===1).map(normalized)};}
export function annotateMusicXML(xml,{Parser=globalThis.DOMParser,Serializer=globalThis.XMLSerializer,mergeCoincidentVoices=false,identitySource=null}={}){
 if(typeof xml!=='string'||/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('不接受外部实体或文档类型');
 const doc=new Parser().parseFromString(xml,'application/xml');if(doc.getElementsByTagName('parsererror').length||doc.documentElement.localName!=='score-partwise')throw Error('无效 MusicXML');
 const plan=labelPlan(normalized(doc.documentElement)),notes=Array.from(doc.getElementsByTagName('note'));
 if(mergeCoincidentVoices){
  const written=identitySource||parseMusicXML(xml);if(written.notes.length!==plan.noteCount)throw Error('音名显示与源音符序号不一致');
  // A hash-validated pinned grace score may supply written onsets. Check every
  // note against this exact XML before using it for display-only grouping.
  if(identitySource){const raw=all(normalized(doc.documentElement),'note');for(let i=0;i<raw.length;i++){const a=raw[i],b=written.notes[i],p=encodedPitchLabel(a);if((p?.midi??null)!==b.midi||(value(a,'voice')||'1')!==b.voice||(value(a,'staff')||'1')!==b.staff||!!one(a,'grace')!==b.grace)throw Error('音名合并身份与源谱不一致');}}
  const grouped=new Map();
  for(const group of plan.groups){const n=written.notes[group.anchorIndex],q=n.onset,gcd=(a,b)=>b?gcd(b,a%b):Math.abs(a),g=gcd(q.n,q.d)||1,key=[n.measureIndex,n.staff,q.n/g,q.d/g].join(':');
   const old=grouped.get(key);if(old){old.notes.push(...group.notes);old.text+=' / '+group.text;}else grouped.set(key,{...group,notes:[...group.notes]});
  }
  plan.groups=[...grouped.values()];
 }
 const make=(tag,text)=>{const el=doc.createElementNS(doc.documentElement.namespaceURI,tag);if(text!==undefined)el.textContent=text;return el;};
 for(const group of plan.groups){
  const lyric=make('lyric'),text=make('text',group.text);
  lyric.setAttribute('number','99');lyric.setAttribute('name','dot-pitch-label');lyric.setAttribute('placement','below');
  lyric.setAttribute('id','dot-pitch-label-'+group.anchorIndex);
  text.setAttribute('font-size','6');text.setAttribute('font-weight','normal');text.setAttribute('color','#365B48');
  lyric.appendChild(make('syllabic','single'));lyric.appendChild(text);
  notes[group.anchorIndex].appendChild(lyric);
 }
 return {xml:new Serializer().serializeToString(doc),...plan};
}
