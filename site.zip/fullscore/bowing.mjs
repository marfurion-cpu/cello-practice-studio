// Practice model, NOT an editorial reconstruction or teacher-approved bowing.
// Derive once on the full timeline so screens, seeking and audio chunks never reset it.
export function assignPracticeBows(timeline){
 let group=-1,previousKey=null,previousDirection=null,restart=true;
 const opposite=x=>x==='下弓'?'上弓':'下弓';
 for(const e of timeline){
  e.practiceBow=null;e.sourceBow=null;e.bowReason='';e.practiceGroup=null;
  const explicit=[...new Set((e.annotations||[]).filter(x=>x==='up-bow'||x==='down-bow'))];
  if(explicit.length===1)e.sourceBow=explicit[0]==='up-bow'?'上弓':'下弓';
  if(e.unsupportedTechniques?.length){previousKey=null;previousDirection=null;restart=true;e.bowReason='特殊奏法需另定弓法，不推断普通运弓';continue;}
  if(e.sourceGroups.length>1){previousKey=null;previousDirection=null;restart=true;e.bowReason='多个连线组重叠，需另定分弓';continue;}
  if(e.rest||e.polyphonic){previousKey=null;previousDirection=null;restart=true;e.bowReason=e.rest?'休止后重新假设首弓':'复音不推断唯一运弓';continue;}
  if(e.releaseOnly){e.practiceBow=previousDirection;e.practiceGroup=group;e.bowReason='持续音，不新起弓';continue;}
  if(explicit.length>1){previousKey=null;previousDirection=null;restart=true;e.bowReason='同一时点弓向标注冲突，停止建议';continue;}
  const source=e.sourceGroups[0],key=source?'slur:'+source.key+':'+source.start:'event:'+e.index;
  const continuation=e.notes.length>0&&e.notes.every(n=>n.rest||(n.ties||[]).some(t=>t.type==='stop'));
  let direction;
  if(explicit.length){direction=explicit[0]==='up-bow'?'上弓':'下弓';e.sourceBow=direction;e.bowReason='所选谱本明确标注';}
  else if(continuation){direction=previousDirection;e.bowReason=direction?'同音延续，不新起弓':'延音缺少可延续方向，不猜测';}
  else if(key===previousKey){direction=previousDirection;e.bowReason='沿所选谱本连线保持同一建议方向';}
  else{direction=restart?'下弓':opposite(previousDirection);e.bowReason=restart?'软件段首假设下弓，未审':'软件按弓组交替，未审';}
  if(key!==previousKey&&!continuation)group++;
  e.practiceBow=direction||null;e.practiceGroup=group;previousKey=key;previousDirection=direction||null;restart=!direction;
 }
 return timeline;
}
