import {parseMusicXML,tiedPlaybackPlan} from './musicxml-events.mjs';
import {verifyBytes} from './verified-courante.mjs';
const num=f=>f.n/f.d,frac=x=>{const n=x*24;if(!Number.isSafeInteger(n))throw Error('Inexact Prelude time');return{n,d:24}},rat=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b),midi=p=>12*(Number(p.octave)+1)+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[p.step])+Number(p.alter||0);
export const fermataWarp=t=>t+Math.max(0,Math.min(1,t-141));
export async function adaptPrelude2(xml,planText,options={}){
 await verifyBytes(xml,'8f8e0f23909bdea89248bf8a9fdffc378bf4aa2019727bb8b42a50bd354d95af');await verifyBytes(planText,'60b87acae85fdbc92a23d41aee4028f3e9dff894efd481a8f8b4b305241c1ee3');
 const plan=JSON.parse(planText),written=parseMusicXML(xml,options),route=plan.sourceRoute;
 if(written.measures.length!==63||written.notes.length!==657||plan.events.length!==651||written.totalBeats!==189||route.some((x,i)=>x!==i+1))throw Error('Prelude source shape');
 for(let i=0;i<written.notes.length;i++){const a=written.notes[i],b=plan.writtenNotes[i];if(a.measureIndex+1!==b.sourceMeasure||a.voice!==b.voice||a.beats!==rat(b.duration)||num(a.onsetInMeasure)!==rat(b.onset)||JSON.stringify(a.pitch&&[a.pitch.step,a.pitch.alter,a.pitch.octave])!==JSON.stringify(b.pitch&&[b.pitch.step,Number(b.pitch.alter||0),Number(b.pitch.octave)]))throw Error('Prelude source mismatch');}
 const notes=written.notes.map(n=>{const t=num(n.onset),duration=fermataWarp(t+n.beats)-fermataWarp(t);return {...n,onset:frac(fermataWarp(t)),duration:frac(duration),beats:duration,sourceQuarter:t,sourceNoteId:n.id,sourceMeasure:n.measureIndex+1,visit:n.measureIndex,suggestedFermataTiming:duration!==n.beats};});
 const measures=written.measures.map((m,i)=>{const t=num(m.onset),onset=fermataWarp(t),duration=fermataWarp(t+num(m.duration))-onset,v=plan.visits[i];if(onset!==rat(v.onset)||duration!==rat(v.duration))throw Error('Prelude visit mismatch');return {...m,onset:frac(onset),duration:frac(duration),sourceQuarter:t,sourceOrdinal:i+1};});
 const groups=new Map();for(const n of notes){const t=num(n.onset);if(!groups.has(t))groups.set(t,[]);groups.get(t).push(n);}const events=[...groups].sort((a,b)=>a[0]-b[0]).map(([t,ns],index)=>({index,onset:frac(t),onsetBeats:t,notes:ns,noteIds:ns.map(n=>n.id)}));
 const score={...written,notes,measures,events,totalBeats:190,totalDuration:frac(190),verifiedPractice:true,suggestedFermata:true,displayRoute:route,writtenMeasureCount:63};
 const actual=tiedPlaybackPlan(score,60).notes,expected=plan.events.filter(n=>n.pitch).map(n=>({midi:midi(n.pitch),voice:n.voice,time:rat(n.performedOnset),duration:rat(n.duration)})),sort=xs=>xs.map(n=>[n.time,n.duration,n.midi,n.voice]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 if(JSON.stringify(sort(actual))!==JSON.stringify(sort(expected)))throw Error('Prelude audio mismatch');return score;
}
