import {buildIdentityMap} from '../grace-identity.mjs';
export function pinHeads(osmd,written,ids,container){
 if(written.piatti6?.frameIdentities==null)throw Error('第6首冻结的谱头身份缺失');
 const ord=new Set(ids.map(n=>n.measureOrdinal-1));
 const local={...written,measures:written.measures.filter(m=>ord.has(m.index)),notes:written.notes.filter(n=>ord.has(n.measureIndex))};
 const map=buildIdentityMap(osmd,local), results=[];
 for(const p of container.querySelectorAll('[data-mother-active]')){p.style.fill=p.dataset.originalFill||'';delete p.dataset.originalFill;delete p.dataset.motherActive;delete p.dataset.piatti6SourceId;}
 for(const id of ids){
  const target=map.get(id.measureOrdinal+'/'+id.noteOrdinal);
  const n=target?.original;
  if(!n||n.id!==id.noteId||n.sourceId!==id.sourceId||n.voice!==id.voice||n.staff!==id.staff||JSON.stringify(n.pitch)!==JSON.stringify(id.pitch))throw Error('谱头身份不匹配 '+id.sourceId);
  const g=osmd.EngravingRules.GNote(target.note),svg=g?.getSVGGElement();
  const own=[...(svg?.children||[])].find(e=>e.classList.contains('vf-note'));
  const paths=[...(own?.children||[])].filter(e=>e.tagName==='path'&&e.classList.contains('vf-notehead'));
  const vf=g?.vfnote?.[0]?.note_heads,i=g?.vfnoteIndex, j=Array.isArray(vf)&&vf.length===paths.length&&Number.isInteger(i)?i:-1;
  const head=paths.length===1?paths[0]:paths[j];
  if(!head?.isConnected||!container.contains(head)||results.some(([p])=>p===head))throw Error('谱头没有唯一可见路径 '+id.sourceId);
  results.push([head,id.sourceId]);
 }
 for(const [p,id] of results){p.dataset.originalFill=p.style.fill||'';p.dataset.motherActive='true';p.dataset.piatti6SourceId=id;p.style.fill='#e97721';}
 return results.map(([p])=>p);
}
