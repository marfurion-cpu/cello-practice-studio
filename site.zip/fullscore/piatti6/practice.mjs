import {parseMusicXML,tiedPlaybackPlan} from '../musicxml-events.mjs';
import {buildTimeline} from '../timeline.mjs';
import {pinHeads} from './pinned-heads.mjs';
export const frozenSourceSHA='158b33a6cc34fdcb90c0815202d4df078e97d68b10b90af78de848002b3b1912';
const crossVoiceArcs=[
 ['m37-v1-t10','m37-v2-t22','1'],
 ['m38-v1-t0','m38-v2-t14','1'],
 ['m38-v2-t10','m38-v1-t16','2']
];
export const pitchReferenceID='m7-t16-n6';
export function preparePiatti6(written){
 const bars=written.measures;
 if(bars.length!==66||written.totalBeats!==198||bars.some((b,i)=>+b.number!==i+1||b.duration.n/b.duration.d!==3))throw Error('第6首小节与拍数未通过冻结核对');
 if(written.notes.filter(n=>!n.rest).length!==954||tiedPlaybackPlan(written,60).notes.length!==930)throw Error('第6首写定谱头或起音不符');
 const bySource=new Map(written.notes.map(n=>[n.sourceId,n])), byOrdinal=new Map();
 for(const m of bars)m.noteIds.forEach((id,i)=>{if(byOrdinal.has(id))throw Error('重复谱头身份');byOrdinal.set(id,i+1);});
 if(bySource.size!==written.notes.length||bySource.has(null))throw Error('第6首谱头无唯一原谱 ID');
 const harmonic=bySource.get(pitchReferenceID), last=written.notes.filter(n=>n.measureNumber==='66');
 if(harmonic?.midi!==85||harmonic?.onsetInMeasure?.n/harmonic?.onsetInMeasure?.d!==2||harmonic.beats!==1||!harmonic.notations?.children.find(x=>x.name==='technical')?.children.some(x=>x.name==='harmonic'&&x.children.some(y=>y.name==='sounding-pitch'))||
   last.map(n=>n.rest?'R':n.midi).join(',')!=='44,51,60,R,R')throw Error('第6首的泛音提示或尾部休止身份不符');
 const cut=new Map();
 for(const [a,b,number] of crossVoiceArcs){
  const A=bySource.get(a),B=bySource.get(b);
  if(!A||!B||A.staff!==B.staff||A.voice===B.voice||A.measureIndex!==B.measureIndex)throw Error('没有确认的跨声部弧线');
  for(const [n,type] of [[A,'start'],[B,'stop']]){
   if(cut.has(n.id)||n.slurs.filter(s=>s.number===number&&s.type===type).length!==1)throw Error('跨声部原谱弧线标记不符');
   cut.set(n.id,{number,type});
  }
 }
 const notes=written.notes.map(n=>{const s=cut.get(n.id);return s?{...n,slurs:n.slurs.filter(x=>x.number!==s.number||x.type!==s.type)}:n;});
 const byId=new Map(notes.map(n=>[n.id,n]));
 const projection={...written,notes,events:written.events.map(e=>({...e,notes:e.notes.map(n=>byId.get(n.id))}))};
 const frames=buildTimeline(projection);
 if(frames.length!==882)throw Error('第6首逐音练习帧未校验');
 function frameIdentities(frame){
  const bar=bars[frame.measureIndex];if(!bar||bar.number!==frame.measure)throw Error('谱头小节身份不符');
  return frame.notes.filter(n=>!n.rest&&!n.cue).map(n=>{
   const source=bySource.get(n.sourceId),i=byOrdinal.get(n.id);
   if(!source||!i||source.id!==n.id||source.measureIndex!==bar.index||source.voice!==n.voice||source.staff!==n.staff||source.midi!==n.midi)throw Error('谱头原始身份不符');
   return {measureOrdinal:bar.index+1,noteOrdinal:i,noteId:n.id,sourceId:n.sourceId,voice:n.voice,staff:n.staff,grace:false,pitch:n.pitch};
  });
 }
 return {frames,score:{...written,verifiedPractice:true,fingeringEnabled:false,piatti6:{frameIdentities,pitchReferenceID},localPinnedHeadResolver:pinHeads}};
}
let loading;
export function loadPiatti6(){
 if(!loading)loading=(async()=>{
  const r=await fetch(new URL('simrock-no6-m01-m66.musicxml',import.meta.url));if(!r.ok)throw Error('未能加载第6首冻结 Simrock 谱');
  const bytes=await r.arrayBuffer();
  const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
  if(sha!==frozenSourceSHA)throw Error('第6首谱指纹校验失败');
  const xml=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  return {...preparePiatti6(parseMusicXML(xml)),xml};
 })().catch(e=>{loading=null;throw e;});
 return loading;
}
