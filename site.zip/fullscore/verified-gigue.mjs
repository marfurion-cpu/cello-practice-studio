import {parseMusicXML,tiedPlaybackPlan} from './musicxml-events.mjs';
import {verifyBytes} from './verified-courante.mjs';
const num=f=>f.n/f.d,frac=x=>({n:Math.round(x*24),d:24}),rat=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b);
const midi=p=>12*(Number(p.octave)+1)+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[p.step])+Number(p.alter||0);
export async function adaptGigue(xml,planText,options={}){
 await verifyBytes(xml,'38b4686ec43c4d54f0935474757c78bfbaa4db21ad9f30c3f6392acfb0396d5f');await verifyBytes(planText,'af24250049e6c4d78c497b35a61239d6bba60b6722cb5cf5caf20ee7890b3c42');
 const plan=JSON.parse(planText),written=parseMusicXML(xml,options),route=plan.sourceRoute.map(x=>x-184);
 if(written.measures.length!==36||written.notes.length!==213||plan.events.length!==432||route.length!==72)throw Error('Gigue内置范围不一致');
 const bySource=new Map();for(let i=0;i<written.notes.length;i++){const a=written.notes[i],b=plan.writtenNotes[i];if(a.measureIndex+185!==b.sourceMeasure||a.voice!==b.voice||a.beats!==rat(b.duration)||num(a.onsetInMeasure)!==rat(b.onset)||JSON.stringify(a.pitch&&[a.pitch.step,a.pitch.alter,a.pitch.octave])!==JSON.stringify(b.pitch&&[b.pitch.step,Number(b.pitch.alter||0),Number(b.pitch.octave)]))throw Error('Gigue源音符不一致');bySource.set(`${b.sourceMeasure}/${b.sourceNote}`,a);}
 const notes=plan.events.map((e,i)=>{const n=bySource.get(`${e.sourceMeasure}/${e.sourceNote}`),pitch=e.pitch?{step:e.pitch.step,alter:Number(e.pitch.alter||0),octave:Number(e.pitch.octave)}:null,vi=e.visit-1;
 if(!n||n.ties.length)throw Error('Unexpected Gigue source or tie');
 const slurs=e.suggestedOrnament?n.slurs.filter(s=>s.type==='start'?e.ornamentAttack===1:s.type==='stop'?e.ornamentAttack===4:false):n.slurs;
 return {...n,id:`v${vi}:attack${i}:${n.id}`,order:i,measureIndex:vi,measureNumber:String(e.sourceMeasure),onset:frac(rat(e.performedOnset)),duration:frac(rat(e.duration)),beats:rat(e.duration),pitch,midi:pitch?midi(pitch):null,slurs,sourceQuarter:num(n.onset),sourceNoteId:n.id,sourceMeasure:e.sourceMeasure,visit:vi,suggestedOrnament:!!e.suggestedOrnament,sourceOriginalPitch:n.pitch};});
 const measures=plan.visits.map((v,vi)=>{const source=written.measures[v.sourceMeasure-185];if(num(source.duration)!==rat(v.duration))throw Error('Gigue measure duration');return {...source,index:vi,number:String(v.sourceMeasure),onset:frac(rat(v.onset)),noteIds:notes.filter(n=>n.measureIndex===vi).map(n=>n.id),sourceQuarter:num(source.onset),sourceOrdinal:source.index+1};});
 const groups=new Map();for(const n of notes){const t=num(n.onset);if(!groups.has(t))groups.set(t,[]);groups.get(t).push(n);}const events=[...groups].sort((a,b)=>a[0]-b[0]).map(([t,ns],index)=>({index,onset:frac(t),onsetBeats:t,notes:ns,noteIds:ns.map(n=>n.id)}));
 const score={...written,notes,measures,events,totalBeats:204,totalDuration:frac(204),verifiedPractice:true,suggestedTrill:true,displayRoute:route,writtenMeasureCount:36};
 const actual=tiedPlaybackPlan(score,60).notes,expected=plan.events.filter(n=>n.pitch).map(n=>({midi:midi(n.pitch),voice:n.voice,time:rat(n.performedOnset),duration:rat(n.duration)})),sort=xs=>xs.map(n=>[n.time,n.duration,n.midi,n.voice]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 if(JSON.stringify(sort(actual))!==JSON.stringify(sort(expected)))throw Error('Gigue播放计划不一致');return score;
}
