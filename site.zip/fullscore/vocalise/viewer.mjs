import {inspectVocalise} from './inspect.mjs';
import {createScoreRenderer} from '../vendor/browser-bundle/osmd-renderer.mjs';
const $=id=>document.getElementById(id);let renderer=null,measure=1,total=0,ready=false;
function error(e){ready=false;$('status').textContent='电子排版未成功：'+e.message+'。可查看下方原始 PDF；未启用任何演奏。';$('prev').disabled=$('next').disabled=$('seek').disabled=true;}
function draw(){try{renderer.showWindow(measure,Math.min(measure+1,total));renderer.hideCursor();$('count').textContent=`书写小节 ${measure}–${Math.min(measure+1,total)} / ${total}`;$('seek').value=measure;$('prev').disabled=measure===1;$('next').disabled=measure===total;}catch(e){error(e);}}
$('prev').onclick=()=>{if(ready){measure=Math.max(1,measure-2);draw();}};$('next').onclick=()=>{if(ready){measure=Math.min(total,measure+2);draw();}};
$('seek').oninput=()=>{if(ready){measure=Number($('seek').value);draw();}};
try{
 const response=await fetch('./score-r6.musicxml');if(!response.ok)throw Error('曲谱下载失败');const xml=await response.text();
 const report=inspectVocalise(xml);if(report.measures!==41||report.notes!==247||report.cues!==18||report.grace!==4||report.trills!==2)throw Error('曲谱版本不匹配');
 total=report.measures;$('seek').max=total;
 renderer=createScoreRenderer({container:$('engraving'),OpenSheetMusicDisplay:opensheetmusicdisplay.OpenSheetMusicDisplay});
 await renderer.load(xml,{measureCount:total});ready=true;$('seek').disabled=false;draw();
 if(ready)$('status').textContent='已载入41个书写小节。仅看谱，未启用指法、运弓建议或声音；实际手机排版尚待验收。';
}catch(e){error(e);}
let timer;globalThis.addEventListener('resize',()=>{clearTimeout(timer);timer=setTimeout(()=>{if(ready)try{renderer.resize();draw();}catch(e){error(e);}},150);});
