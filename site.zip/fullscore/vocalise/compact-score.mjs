import {annotateMusicXML} from '../note-labels.mjs';
// Display only. The practice/audio model still uses the ORIGINAL score-r6 XML.
export function annotateVocalisePractice(xml,{Parser=globalThis.DOMParser,Serializer=globalThis.XMLSerializer}={}){
 const result=annotateMusicXML(xml,{Parser,Serializer});
 const doc=new Parser().parseFromString(result.xml,'application/xml');
 let removed=0;
 for(const note of doc.getElementsByTagName('note')){
  if(![...note.children].some(n=>n.localName==='cue'))continue;
  for(const el of [...note.children])if(el.localName==='lyric'&&el.getAttribute('name')==='dot-pitch-label'){
   el.remove(); removed++;
  }
 }
 return {...result,xml:new Serializer().serializeToString(doc),removedCueDisplayLabels:removed};
}
export function compactVocaliseOsmd(Base){
 return class extends Base {
  render(...args){
   const w=globalThis.innerWidth;
   this.Zoom=w<=360?.80:w<=420?.88:1;
   return super.render(...args);
  }
 };
}
