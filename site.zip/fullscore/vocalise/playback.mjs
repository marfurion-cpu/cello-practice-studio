import {parseMusicXMLTree,tiedPlaybackPlan} from './base-parser.mjs';
const cs=(n,t)=>(n.children||[]).filter(c=>!t||c.name===t),one=(n,t)=>cs(n,t)[0],txt=(n,t)=>one(n,t)?.text?.trim()||'';
const all=(n,t)=>[...(n.name===t?[n]:[]),...(n.children||[]).flatMap(c=>all(c,t))];
const techniqueFlags=nodes=>{const unsupportedTechniques=[...new Set(nodes.flatMap(n=>['thumb-position','harmonic'].filter(t=>all(n,t).length)))];return {unsupportedTechniques,thumbPosition:unsupportedTechniques.includes('thumb-position'),harmonic:unsupportedTechniques.includes('harmonic')};};
const midi=n=>{const p=one(n,'pitch');if(!p)throw Error('Grace pitch required');
 const step=txt(p,'step'),oct=txt(p,'octave'),raw=txt(p,'alter'),alter=raw===''?0:Number(raw),base={C:0,D:2,E:4,F:5,G:7,A:9,B:11}[step];
 if(base===undefined||!/^\d+$/.test(oct)||!Number.isSafeInteger(Number(oct))||!Number.isInteger(alter)||Math.abs(alter)>2)throw Error('Invalid grace pitch');
 const v=12*(Number(oct)+1)+base+alter;if(v<0||v>127)throw Error('Invalid grace pitch');return v;};
const validEnding=(m,number,stop)=>{const bars=cs(m,'barline');const entries=bars.flatMap(b=>cs(b,'ending').map(e=>({e,location:b.attrs.location})));return all(m,'ending').length===2&&entries.length===2&&entries.filter(({e,location})=>e.attrs.number===number&&e.attrs.type==='start'&&location==='left').length===1&&entries.filter(({e,location})=>e.attrs.number===number&&stop.includes(e.attrs.type)&&location==='right').length===1;};
/** Bounded subset: disjoint forward/backward repeats, exactly two passes,
 * single-measure first and second endings. Reject rather than guess other forms. */
export function performancePath(root){
 const ms=cs(one(root,'part'),'measure'),path=[],regions=[];let start=null;
 if(all(root,'sound').some(n=>['dacapo','dalsegno','tocoda','fine','segno','coda'].some(k=>k in n.attrs)))throw Error('Jump navigation unsupported');
 for(let i=0;i<ms.length;i++)for(const b of cs(ms[i],'barline'))for(const r of cs(b,'repeat')){
  if(r.attrs.direction==='forward'){if(start!==null)throw Error('Nested repeat unsupported');if(b.attrs.location!=='left')throw Error('Repeat start must be left');start=i;}
  else if(r.attrs.direction==='backward'){
   if(start===null)throw Error('Implicit repeat start unsupported');if(b.attrs.location!=='right'||(r.attrs.times&&r.attrs.times!=='2'))throw Error('Unsupported repeat count/location');
   const e=all(ms[i],'ending');const second=ms[i+1]&&all(ms[i+1],'ending');
   const firstEnd=validEnding(ms[i],'1',['stop']);
   if(e.length&&!firstEnd)throw Error('Only single-measure endings supported');
   if(firstEnd&&!(second&&validEnding(ms[i+1],'2',['stop','discontinue'])))throw Error('Matching second ending required');
   regions.push({start,end:i,ending:firstEnd});start=null;
  }else throw Error('Unknown repeat');
 }
 if(start!==null)throw Error('Unclosed repeat');
 const covered=new Set(regions.filter(r=>r.ending).flatMap(r=>[r.end,r.end+1]));
 ms.forEach((m,i)=>{if(all(m,'ending').length&&!covered.has(i))throw Error('Unmatched or multi-measure ending');});
 for(let i=0;i<ms.length;i++){const r=regions.find(r=>r.start===i);if(!r){path.push(i);continue;}for(let j=i;j<=r.end;j++)path.push(j);for(let j=i;j<=(r.ending?r.end-1:r.end);j++)path.push(j);if(r.ending){path.push(r.end+1);i=r.end+1;}else i=r.end;}
 return path;
}
export function buildPlayback(root, {bpm=72,voice='1',gracePolicy,trillPolicy,fermataPolicy,fermataFactor=1.5,trillUpperBySource={},trillRate=8}={}){
 if(gracePolicy!=='steal-previous-quarter'||!['principal-only','explicit-upper'].includes(trillPolicy)||!['written','extend'].includes(fermataPolicy))throw Error('Explicit grace, trill and fermata interpretation policies required');
 if(!Number.isFinite(bpm)||bpm<20||bpm>240||!Number.isFinite(trillRate)||trillRate<2||trillRate>16||!Number.isFinite(fermataFactor)||fermataFactor<1||fermataFactor>4)throw Error('Invalid playback options');
 const path=performancePath(root),tree=structuredClone(root),part=one(tree,'part'),sourceMs=cs(part,'measure');let graceCount=0,cueCount=0;
 sourceMs.forEach((m,mi)=>{let previous=null;let ni=0;const kept=[];for(const e of cs(m)){
  if(e.name!=='note'){kept.push(e);continue;}e.attrs={...e.attrs,'data-source':`${mi+1}:${ni++}`};
  if(one(e,'cue')){cueCount++;e.attrs['data-muted']='cue';}
  if(one(e,'grace')){if(['steal-time-previous','steal-time-following','make-time'].some(k=>Object.hasOwn(one(e,'grace').attrs||{},k)))throw Error('Explicit grace timing attributes unsupported; no timing interpretation applied');if(!previous||one(previous,'rest')||txt(previous,'voice')!==voice||one(previous,'cue'))throw Error('Grace requires previous main-voice pitched note in same measure');(previous.graces??=[]).push({midi:midi(e),sourceId:e.attrs['data-source'],...techniqueFlags([e])});graceCount++;continue;}
  if((txt(e,'voice')||'1')===voice&&!one(e,'cue'))previous=e;
  kept.push(e);
 }m.children=kept;});
 // Unfold physical measures first, keeping IDs tied to source. This makes ties
 // validate over the actual performed route, not over skipped first endings.
 part.children=path.map((mi,visit)=>{const m=structuredClone(sourceMs[mi]);m.attrs={...m.attrs,number:String(visit+1)};m.children=m.children.filter(e=>e.name!=='barline');return m;});
 const score=parseMusicXMLTree(tree);score.notes=score.notes.filter(n=>n.voice===voice&&!n.source.attrs['data-muted']);
 if(!score.notes.some(n=>!n.rest))throw Error('Selected voice has no melody');
 const base=tiedPlaybackPlan(score,bpm);const sourceMap=new Map(score.notes.map(n=>[n.id,n]));let shift=0;const output=[],extensions=[];let trillCount=0,fermataCount=0;
 for(const event of base.notes){const group=event.noteIds.map(id=>sourceMap.get(id));const decorated=group.filter(n=>n.source.graces?.length||all(n.source,'trill-mark').length||all(n.source,'fermata').length);
  if(decorated.length>1)throw Error('Multiple decorated notes in a tie require explicit interpretation');
  const n=decorated[0]||group[0],graces=n.source.graces||[],trill=all(n.source,'trill-mark').length>0,fermata=all(n.source,'fermata').length>0;
  if(graces.length&&group.length>1)throw Error('Grace on tied group unsupported');
  let duration=event.duration;const extension=fermata&&fermataPolicy==='extend'?n.beats*60/bpm*(fermataFactor-1):0;duration+=extension;
  const graceDuration=graces.length?Math.min(duration*.25,.25*60/bpm):0,mainDuration=duration-graceDuration,time=event.time+shift;
  const common={...techniqueFlags(group.map(g=>g.source)),sourceId:n.source.attrs['data-source'],sourceNoteIds:group.map(g=>g.source.attrs['data-source']),performedNoteIds:event.noteIds,performedMeasure:group[0].measureIndex+1};
  if(trill){trillCount++;if(trillPolicy==='explicit-upper'){
   const upper=trillUpperBySource[common.sourceId];if(!Number.isInteger(upper)||upper<=event.midi||upper-event.midi>2)throw Error(`Explicit upper-neighbor pitch required: ${common.sourceId}`);
   let t=0,k=0;while(t<mainDuration-1e-9){const d=Math.min(1/trillRate,mainDuration-t);output.push({...common,midi:k++%2?upper:event.midi,time:time+t,duration:d,interpretation:'suggested-trill'});t+=d;}
  }else output.push({...common,midi:event.midi,time,duration:mainDuration,interpretation:'principal-only-trill-not-realized'});
  }else output.push({...common,midi:event.midi,time,duration:mainDuration,interpretation:'written-pitch'});
  graces.forEach((p,i)=>output.push({...common,unsupportedTechniques:p.unsupportedTechniques,thumbPosition:p.thumbPosition,harmonic:p.harmonic,sourceId:p.sourceId,sourceNoteIds:[p.sourceId],anchorSourceId:common.sourceId,performedNoteIds:[],anchorPerformedNoteIds:event.noteIds,midi:p.midi,time:time+mainDuration+i*graceDuration/graces.length,duration:graceDuration/graces.length,interpretation:'suggested-grace-allocation'}));
  if(extension)extensions.push({at:event.time+event.duration,amount:extension});
  if(fermata)fermataCount++;shift+=extension;
 }
 const measures=score.measures.map((m,i)=>{
  const raw=m.onset.n/m.onset.d*60/bpm;
  return {visit:i+1,sourceMeasure:path[i]+1,start:raw+extensions.filter(e=>e.at<=raw+1e-8).reduce((a,e)=>a+e.amount,0)};
 });
 return {measures,schema:'vocalise-playback-candidate/0.2',path:path.map(i=>i+1),duration:base.duration+shift,notes:output,stats:{sourceMeasures:sourceMs.length,performedMeasures:path.length,cueCount,graceCount,trillCount,fermataCount},policies:{voice,bpm,gracePolicy,trillPolicy,fermataPolicy,fermataFactor,trillRate},warnings:['电子示范，不是专业演奏验收。装饰音时值、颤音速度和延长量属于可调整软件解释，不属于原谱。','只演奏选定主声部；钢琴提示音保留于原谱但静音。','力度、渐慢、音色、真实弓法音响未实现。',...(trillPolicy==='principal-only'?['颤音当前只演奏主音，不是完整装饰音示范。']:[])]};
}
