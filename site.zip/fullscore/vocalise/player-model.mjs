import {normalizeDOM} from './base-parser.mjs';
import {buildPlayback} from './playback.mjs';
export function prepare(xml,Parser=globalThis.DOMParser,bpm=72){
 if(!Number.isFinite(bpm)||bpm<30||bpm>144)throw Error("Tempo must be 30–144 BPM");
 const doc=new Parser().parseFromString(xml,'application/xml');const root=normalizeDOM(doc.documentElement),map=new Map();let absolute=0,div=1;
 const cs=(n,t)=>n.children.filter(x=>x.name===t),one=(n,t)=>cs(n,t)[0],v=(n,t)=>one(n,t)?.text.trim();
 const measures=cs(one(root,'part'),'measure');
 measures.forEach((m,mi)=>{let cur=0,max=0,ni=0;for(const e of m.children){if(e.name==='attributes'&&v(e,'divisions'))div=+v(e,'divisions');if(e.name==='backup')cur-=+v(e,'duration')/div;if(e.name==='forward')cur+=+v(e,'duration')/div;if(e.name==='note'){const id=`${mi+1}:${ni++}`,grace=!!one(e,'grace'),duration=grace?0:+v(e,'duration')/div;const p=one(e,'pitch'),step=p&&v(p,'step'),alter=p?Number(v(p,'alter')||0):null,octave=p?Number(v(p,'octave')):null;const pitch=p?{step,alter,octave,accidental:v(e,'accidental')||null,midi:(octave+1)*12+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[step])+alter}:null;map.set(id,{pitch,id,measure:mi+1,onset:absolute+cur,duration,grace,cue:!!one(e,'cue')});if(!grace&&!one(e,'chord'))cur+=duration;}max=Math.max(max,cur);}absolute+=max;});
 const plan=buildPlayback(root,{bpm,gracePolicy:'steal-previous-quarter',trillPolicy:'explicit-upper',trillUpperBySource:{'6:3':64,'38:3':67},fermataPolicy:'extend',fermataFactor:1.5});return {plan,map,bpm};
}
export function sourceAt(event,elapsed,map,bpm=72){
 if(!Number.isFinite(bpm)||bpm<30||bpm>144)throw Error("Tempo must be 30–144 BPM");
 let ids=event.sourceNoteIds,remaining=Math.max(0,elapsed);let source=map.get(ids[0]);
 if(event.interpretation!=='suggested-grace-allocation')for(const id of ids){source=map.get(id);if(remaining<source.duration*60/bpm-1e-8)break;remaining-=source.duration*60/bpm;}
 return source;
}
export function clip(plan,start,max=30){
 if(!Number.isFinite(start)||start<0||start>=plan.duration||max<=0||max>60)throw Error('Invalid slice');const duration=Math.min(max,plan.duration-start);
 const events=plan.notes.filter(n=>n.time<start+duration-1e-9&&n.time+n.duration>start+1e-9).map(n=>{const a=Math.max(start,n.time),b=Math.min(start+duration,n.time+n.duration);return {...n,time:a-start,duration:b-a,phaseOffset:a-n.time};});if(events.some(n=>n.unsupportedTechniques?.length))throw Error('当前试听段含未建模的拇指把位或泛音：不推断普通指法或音响，请先核对源谱');return {events,duration,start};
}

// Keep the written spelling: E-sharp is not relabelled F while learning the score.
export function pitchText(event,source){
 const p=source?.pitch, names=['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
 const sounding=Number.isInteger(event?.midi)?names[(event.midi%12+12)%12]+(Math.floor(event.midi/12)-1):'音高未知';
 if(!p||!Object.hasOwn({C:0,D:2,E:4,F:5,G:7,A:9,B:11},p.step)||!Number.isInteger(p.alter)||Math.abs(p.alter)>2||!Number.isInteger(p.octave))return '合成音 '+sounding+'（源谱音名未解析）';
 const acc=({'-2':'𝄫','-1':'♭','0':p.accidental==='natural'?'♮':'','1':'♯','2':'𝄪'})[p.alter];
 const written=p.step+acc+p.octave;
 return p.midi===event.midi?'谱面音 '+written:'合成音 '+sounding+'（源谱主音 '+written+'）';
}
