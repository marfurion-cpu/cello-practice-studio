import {createLifecycleGuard} from './lifecycle-guard.mjs';
import {parseBowingAdvice,bowText} from './bowing-advice.mjs';
import {mountVibrato,comparisonNote} from '../vibrato-panel.mjs';
import {inspectVocalise} from './inspect.mjs';
import {prepare,sourceAt,clip,pitchText} from './player-model.mjs';
import {makePolyWav} from '../polyphonic-audio.mjs';
import {createKtvRenderer as createScoreRenderer,visitForSource} from '../ktv-renderer.mjs';
import {solve,label,drawHandframe} from './high-position.mjs';
const $=id=>document.getElementById(id);let renderer=null,model=null,path=[],index=0,ready=false,segment=null,serial=0,url=null,resume=null,playbackIntent=false,segmentBusy=false;
let preparedNext=null,prepareTimer=null;
function clearPrepared(){if(prepareTimer!==null)clearTimeout(prepareTimer);prepareTimer=null;preparedNext=null;}
function queueNext(selected,current,token){
 clearPrepared();const nextStart=current.start+current.duration;
 if(nextStart>=selected.plan.duration-1e-7)return;
 prepareTimer=setTimeout(()=>{
  prepareTimer=null;
  const valid=()=>serial===token&&model===selected&&playbackIntent&&lifecycle.isAllowed()&&lifecycle.canPlay();
  if(!valid())return;
  try{const next=clip(selected.plan,nextStart),wav=makePolyWav(next);
   // Keep only one bounded WAV; no URL, media element or playback permission is created.
   if(valid()&&wav.byteLength<=1100000)preparedNext={selected,start:nextStart,segment:next,wav};
  }catch(error){if(valid())preparedNext={selected,start:nextStart,error};}
 },100);
}
const audio=$('audio');let bowAdvice=[],sourceXML='';
$('tempo').onchange=()=>{if(!ready)return;const bpm=Number($('tempo').value);if(!Number.isFinite(bpm)||bpm<30||bpm>144){$('tempo').value=model.bpm;$('status').textContent='请输入30–144 BPM；速度未改变。';return;}stop();try{const nextModel=prepare(sourceXML,globalThis.DOMParser,bpm),nextBow=parseBowingAdvice(sourceXML,nextModel.plan),nextPath=solve(nextModel.plan.notes);model=nextModel;bowAdvice=nextBow;path=nextPath;index=0;$('seek').max=model.plan.notes.length-1;show();$('status').textContent=`练习速度 ${model.bpm} BPM，已停止并回到首音；颤音仍为每秒8音，不模拟原谱渐慢。`;}catch(e){$('tempo').value=model.bpm;$('status').textContent='速度调整未完成，保持停止：'+e.message;}};
$('bowPractice').onchange=()=>{if(ready)show(segment?segment.start+audio.currentTime:resume);};
let vibrato=null,sourceVibrato='uncertain';vibrato=mountVibrato($('vibratoPanel'),()=>stop());
const lifecycle=createLifecycleGuard({document,window:globalThis,audio,onInterrupt:()=>{stop();$('status').textContent='试听已停止；返回页面后请手动点击播放。';}});
function stop(){clearPrepared();playbackIntent=false;segmentBusy=false;lifecycle.revoke();vibrato?.stop();serial++;audio.pause();audio.removeAttribute('src');segment=null;resume=null;$('play').textContent='▶ 播放';}
function fail(e){stop();ready=false;$('status').textContent='未能载入：'+e.message+'。请使用原PDF。';for(const id of ['play','prev','next','seek','measureSelect','prevMeasure','nextMeasure'])$(id).disabled=true;}
function show(time=null){if(!ready)return;syncMeasures(time??model.plan.notes[index].time);const n=model.plan.notes[index],s=sourceAt(n,time===null?0:time-n.time,model.map,model.bpm);const visit=visitForSource(model.plan.path,n.performedMeasure-1,s.measure);renderer.showVisit(visit,{waiting:time!==null&&time<n.time-1e-8});renderer.hideCursor();if(time!==null&&time<n.time-1e-8){$('count').textContent=`休止 / 静音 · 下一事件 ${index+1}/${model.plan.notes.length}`;$('note').textContent='休止 / 静音：当前不演奏下一音';$('bow').textContent='休止：不显示下一音弓法。';$('mapping').textContent='下一音尚未开始，指板与谱面游标暂隐';vibrato.update(comparisonNote(null,null));drawHandframe({rest:true},{index,path});$('seek').value=index;$('prev').disabled=index===0;$('next').disabled=index===model.plan.notes.length-1;return;}let cursor='';
 vibrato.update(comparisonNote(n,path[index],{sourceVibrato,unsupported:!!n.unsupportedTechniques?.length||n.interpretation==='suggested-trill'||s.grace,offset:0}));
 if(!s.grace)try{renderer.seekQuarter(s.onset);}catch{cursor=' · 游标不可定位，已隐藏';renderer.hideCursor();}
 $('count').textContent=`第 ${index+1}/${model.plan.notes.length} 个演奏事件 · 源小节 ${s.measure} · 来源音 ${s.id}`;
 $('note').textContent=n.unsupportedTechniques?.length?'源谱含'+n.unsupportedTechniques.join(' / ')+'：未建模，不给普通指法或推定发声音高':`${pitchText(n,s)} · ${(440*2**((n.midi-69)/12)).toFixed(1)} Hz · ${path[index]?label(path[index]):'超出有限指法范围，不猜测'}`;
 $('mapping').textContent=(n.unsupportedTechniques?.length?'特殊奏法未建模：只显示固定参考网格，不给指板落点建议':s.grace?'装饰小音符：指板对应该小音符；谱面游标暂隐':n.interpretation==='suggested-trill'?'颤音上下音交替：游标标主音，指板标当前合成音':'游标对应源谱；延音跨小节时跟随源音')+cursor;
 $('bow').textContent=n.unsupportedTechniques?.length?'特殊奏法待核实：不建议普通弓法、揉弦或音色。':bowText(bowAdvice[index],$('bowPractice').checked);
 drawHandframe(path[index],{index,path});$('seek').value=index;$('prev').disabled=index===0;$('next').disabled=index===model.plan.notes.length-1;
}
function measureAt(time){return Math.max(0,model.plan.measures.findIndex((m,j)=>time>=m.start-1e-8&&(j===model.plan.measures.length-1||time<model.plan.measures[j+1].start-1e-8)));}
function syncMeasures(time){const i=measureAt(time);$('measureSelect').value=String(i);$('prevMeasure').disabled=i===0;$('nextMeasure').disabled=i===model.plan.measures.length-1;}
function populateMeasures(){const seen=new Map();$('measureSelect').replaceChildren(...model.plan.measures.map((m,i)=>{const n=(seen.get(m.sourceMeasure)||0)+1;seen.set(m.sourceMeasure,n);const o=document.createElement('option');o.value=String(i);o.textContent=m.sourceMeasure+'小节'+(n>1?' ·'+n+'次':'');o.title='第 '+m.sourceMeasure+' 小节'+(n>1?' · 反复第 '+n+' 遍':'');return o;}));$('measureSelect').disabled=false;}
function jumpMeasure(i){if(!ready||!Number.isInteger(i)||i<0||i>=model.plan.measures.length)return;i=Math.max(0,Math.min(model.plan.measures.length-1,i));stop();const m=model.plan.measures[i];resume=m.start;index=model.plan.notes.findIndex(n=>n.time+n.duration>resume+1e-8);if(index<0)index=model.plan.notes.length-1;show(resume);renderer.showVisit(i,{waiting:resume<model.plan.notes[index].time-1e-8});syncMeasures(resume);$('status').textContent='已选谱面第 '+m.sourceMeasure+' 小节（演奏顺序 '+m.visit+'/'+model.plan.measures.length+'），点击播放从小节起点试听。';}
$('measureSelect').onchange=()=>jumpMeasure(Number($('measureSelect').value));
$('prevMeasure').onclick=()=>jumpMeasure(Number($('measureSelect').value)-1);
$('nextMeasure').onclick=()=>jumpMeasure(Number($('measureSelect').value)+1);
$('prev').onclick=()=>{stop();index=Math.max(0,index-1);show();};$('next').onclick=()=>{stop();index=Math.min(model.plan.notes.length-1,index+1);show();};$('seek').oninput=()=>{stop();index=Number($('seek').value);show();};$('stop').onclick=stop;
$('play').onclick=async()=>{if(!ready||!lifecycle.canPlay())return;if(playbackIntent||!audio.paused){stop();return;}const start=resume??model.plan.notes[index].time;stop();playbackIntent=true;await startSegment(start,false);};
async function startSegment(start,automatic){
 const token=++serial,selected=model;
 const valid=()=>token===serial&&selected===model&&playbackIntent&&lifecycle.canPlay();
 segmentBusy=true;
 try{
  if(!valid())return;
  const cached=preparedNext?.selected===selected&&preparedNext.start===start?preparedNext:null;
  clearPrepared();
  if(cached?.error)throw cached.error;
  segment=cached?.segment??clip(selected.plan,start);
  const wav=cached?.wav??makePolyWav(segment);
  if(!valid())return;
  if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(new Blob([wav],{type:'audio/wav'}));
  // Revoke old permission before source replacement; delayed media events still require browser QA.
  lifecycle.revoke();audio.src=url;resume=null;
  if(!lifecycle.arm()){stop();return;}
  $('play').textContent='停止';
  $('status').textContent=automatic?'正在接续下一段；分段生成可能有短暂停顿。':'启动电子试听；前台段尾自动接续，停止或切后台即取消。';
  await audio.play();
  if(!valid()||!lifecycle.isAllowed())return;
  queueNext(selected,segment,token);
 }catch(e){
  if(!valid())return;
  stop();resume=start;
  $('play').textContent='▶ 手动继续';
  $('status').textContent=(automatic?'自动接续未成功':'启动未成功')+' ['+(e.name||'Error')+']：'+e.message+'。已停止自动尝试；点手动继续从断点重试。未确认设备有声。';
 }finally{if(token===serial)segmentBusy=false;}
}
audio.ontimeupdate=()=>{if(!segment||audio.paused||audio.ended)return;const time=segment.start+audio.currentTime;let found=model.plan.notes.findIndex(n=>n.time+n.duration>time+1e-8);if(found<0)found=model.plan.notes.length-1;index=found;try{show(time);}catch(e){fail(e);}};
audio.onerror=()=>{if(!segment)return;stop();$('status').textContent='媒体播放失败，已停止。请检查媒体音量或稍后重试；未认定已听到声音。';};
audio.onended=async()=>{
 if(segmentBusy||!playbackIntent||!lifecycle.isAllowed()||!segment||!audio.ended||Math.abs(audio.currentTime-segment.duration)>.25)return;
 const end=segment.start+segment.duration;
 if(end<model.plan.duration-1e-7){resume=end;await startSegment(end,true);}
 else{stop();index=model.plan.notes.length-1;show(model.plan.duration-1e-7);$('play').textContent='▶ 重播末音';$('status').textContent='已到全曲结尾，不会自动循环。';}
};
try{const r=await fetch('./score-r6.musicxml');if(!r.ok)throw Error('曲谱下载失败');const xml=await r.text();sourceXML=xml;sourceVibrato=!/vib|wavy-line|harmonic/i.test(xml)?'unmarked':'uncertain';const report=inspectVocalise(xml);if(report.measures!==41||report.notes!==247)throw Error('版本不匹配');model=prepare(xml);bowAdvice=parseBowingAdvice(xml,model.plan);path=solve(model.plan.notes);renderer=createScoreRenderer({container:$('engraving'),OpenSheetMusicDisplay:opensheetmusicdisplay.OpenSheetMusicDisplay});await renderer.load(xml,{measureCount:41,route:model.plan.path});ready=true;populateMeasures();$('seek').max=model.plan.notes.length-1;for(const id of ['play','seek'])$(id).disabled=false;show();$('status').textContent='已载入70个展开演奏小节；电子解释候选，未教师及真实iPhone验收。';}catch(e){fail(e);}
let timer;globalThis.addEventListener('resize',()=>{clearTimeout(timer);timer=setTimeout(()=>{if(ready)try{renderer.resize();show(segment?segment.start+audio.currentTime:resume);}catch(e){fail(e);}},150);});
