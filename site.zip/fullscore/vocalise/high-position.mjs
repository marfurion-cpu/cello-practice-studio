// Pitch-location reference only. Never invent a source fingering or hand frame.
// A4 at half the A string: Ailbhe McDonagh, Cello Intermediate lesson 29;
// ISFEE/TOR, Cello Scale Fingering example 3. Equal-tempered ideal-string model.
import {solve as solveLow,label as labelLow} from '../fingering.mjs';
import {drawHandframe as drawLow} from '../handframe.mjs';
import {drawTrialBoard,pointX as boardPointX} from '../shared-board.mjs';
export function highLocation(n){
 if(n.rest||n.polyphonic||n.unsupportedTechniques?.length||!Number.isInteger(n.midi)||n.midi<=67||n.midi>88)return null;
 return {name:'A',num:1,midi:57,offset:n.midi-57,finger:null,pos:'高音落点参考',locationOnly:true,key:'A:location:'+n.midi};
}
export function solve(notes){return solveLow(notes).map((c,i)=>c||highLocation(notes[i]));}
export function label(c){return c.locationOnly?'A 弦（第 1 弦） · 高音落点参考 · 不指定指法':labelLow(c);}
export const pointX=boardPointX;
export function drawHandframe(c,state){
 if(!c?.locationOnly)return drawLow(c,state);
 drawTrialBoard(document.getElementById('board'),{},{stops:[{name:c.name,offset:c.offset,pitch:c.midi+c.offset,finger:null,position:null}]});
}
