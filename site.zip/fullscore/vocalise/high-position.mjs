// Pitch-location reference only. Never invent a source fingering or hand frame.
// A4 at half the A string: Ailbhe McDonagh, Cello Intermediate lesson 29;
// ISFEE/TOR, Cello Scale Fingering example 3. Equal-tempered ideal-string model.
import {solve as solveLow,label as labelLow} from '../fingering.mjs';
import {drawHandframe as drawLow} from '../handframe.mjs';
export function highLocation(n){
 if(n.rest||n.polyphonic||n.unsupportedTechniques?.length||!Number.isInteger(n.midi)||n.midi<=67||n.midi>88)return null;
 return {name:'A',num:1,midi:57,offset:n.midi-57,finger:null,pos:'高音落点参考',locationOnly:true,key:'A:location:'+n.midi};
}
export function solve(notes){return solveLow(notes).map((c,i)=>c||highLocation(notes[i]));}
export function label(c){return c.locationOnly?'A 弦（第 1 弦） · 高音落点参考 · 不指定指法':labelLow(c);}
export const pointX=offset=>50+300*(1-2**(-offset/12));
export function drawHandframe(c,state){
 if(!c?.locationOnly)return drawLow(c,state);
 const svg=document.getElementById('board'),ns='http://www.w3.org/2000/svg';
 svg.replaceChildren();svg.setAttribute('viewBox','0 0 380 108');
 svg.setAttribute('role','img');svg.setAttribute('aria-label','A弦高音理论落点参考；圆点不是手指编号，虚线A4是八度中点');
 const shape=(tag,attrs,text)=>{const e=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(text)e.textContent=text;svg.append(e);return e;};
 shape('title',{},'A弦高音落点 · 不指定手指');
 shape('desc',{},'四弦标准定弦不变。按十二平均律有效弦长显示A弦当前音落点，A4八度中点仅作定位参考，不表示本音使用泛音或指定拇指。高音图与低把位图比例不同。');
 for(const off of [0,7,12,19,24,31]){const x=pointX(off);shape('line',{x1:x,x2:x,y1:18,y2:82,stroke:off===12?'#648773':'#ccd8cd','stroke-dasharray':'2 3'});shape('text',{x,y:12,'font-size':10,'text-anchor':'middle',fill:'#4b6655'},off===12?'A4中点':String(off));}
 ['A','D','G','C'].forEach((name,i)=>{const y=25+i*16;shape('text',{x:10,y:y+5,'font-size':15,fill:'#234a38'},name+'弦');shape('line',{x1:50,x2:350,y1:y,y2:y,stroke:i===0?'#285b46':'#c6d0c5','stroke-width':i===0?3:1});});
 shape('circle',{cx:pointX(c.offset),cy:25,r:7,fill:'#285b46','data-high-location':c.offset});
 shape('text',{x:190,y:94,'text-anchor':'middle','font-size':10,fill:'#52695a'},'实心点=音高落点，非指号 · A4虚线=八度中点');
 shape('text',{x:190,y:106,'text-anchor':'middle','font-size':9,fill:'#6d7a6f'},'高音图比例 · 数字为距空弦半音 · 不指定手型');
}
