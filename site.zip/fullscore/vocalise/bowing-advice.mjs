// Practice overlay only: never edits the score, note timing, or audio.
import {normalizeDOM} from './base-parser.mjs';
const cs=(n,t)=>(n?.children||[]).filter(x=>x.name===t),one=(n,t)=>cs(n,t)[0];
const all=(n,t)=>[...(n?.name===t?[n]:[]),...(n?.children||[]).flatMap(x=>all(x,t))];
const value=(n,t)=>one(n,t)?.text?.trim()||'';
export function sourceBowing(root){
 const map=new Map(),ordered=[],active=new Map();
 cs(one(root,'part'),'measure').forEach((m,mi)=>cs(m,'note').forEach((n,ni)=>{
  const item={id:`${mi+1}:${ni}`,voice:value(n,'voice')||'1',slur:false,complex:!!one(n,'grace')||all(n,'ornaments').length>0||all(n,'fermata').length>0||all(n,'harmonic').length>0||all(n,'thumb-position').length>0||!!one(n,'chord'),cue:!!one(n,'cue'),rest:!!one(n,'rest'),tie:cs(n,'tie').length>0||all(n,'tied').length>0,bow:all(n,'up-bow').length&&!all(n,'down-bow').length?'up':all(n,'down-bow').length&&!all(n,'up-bow').length?'down':null};
  item.complex ||= all(n,'up-bow').length+all(n,'down-bow').length>1;
  const pos=ordered.length;ordered.push(item);map.set(item.id,item);
  for(const s of all(n,'slur')){
   const key=`${item.voice}/${s.attrs?.number||'1'}`;
   if(s.attrs?.type==='start'){
    if(active.has(key)){for(let j=active.get(key);j<=pos;j++)if(ordered[j].voice===item.voice)ordered[j].slur=true;}
    else active.set(key,pos);
   }else if(s.attrs?.type==='stop'){
    const start=active.get(key)??0;for(let j=start;j<=pos;j++)if(ordered[j].voice===item.voice)ordered[j].slur=true;active.delete(key);
   }else item.slur=true;
  }
 }));
 for(const [key,start]of active){const voice=key.split('/')[0];for(let j=start;j<ordered.length;j++)if(ordered[j].voice===voice)ordered[j].slur=true;}
 return map;
}
export function adviceForPlan(root,plan){
 const meta=sourceBowing(root);let previous=null,lastEnd=null;
 return plan.notes.map(event=>{
  const ids=event.sourceNoteIds||[],items=ids.map(id=>meta.get(id));
  const sourceMarks=items.filter(Boolean).filter(x=>x.bow).map(x=>({id:x.id,bow:x.bow}));
  let reason='';
  if(!items.length||items.some(x=>!x))reason='谱源映射不全';
  else if(items.some(x=>x.slur))reason='在电子谱连线内：连线不自动视为一弓，需另定分弓';
  else if(items.some(x=>x.complex||x.cue||x.rest)||event.interpretation!=='written-pitch')reason='装饰、延长或特殊奏法需另定弓法';
  else if(items.some(x=>x.tie)||items.length!==1)reason='延音链需规划整段弓量';
  else if(!Number.isFinite(event.duration)||event.duration<.2||event.duration>1.5)reason='当前时长不在短音分弓练习范围';
  if(reason){previous=null;lastEnd=event.time+event.duration;return {sourceMarks,practice:null,reason};}
  const reset=previous===null||lastEnd===null||Math.abs(event.time-lastEnd)>.02;
  const direction=items[0].bow||(reset?'down':previous==='down'?'up':'down');
  previous=direction;lastEnd=event.time+event.duration;
  return {sourceMarks,practice:{direction,region:'中弓短弓',restart:reset&&!items[0].bow},reason:''};
 });
}
export function parseBowingAdvice(xml,plan,Parser=globalThis.DOMParser){const doc=new Parser().parseFromString(xml,'application/xml');if(!doc.documentElement||doc.getElementsByTagName('parsererror').length)throw Error('Invalid score XML');return adviceForPlan(normalizeDOM(doc.documentElement),plan);}
export function bowText(advice,enabled){
 if(!advice)return '弓法：暂无源谱映射，不建议。';
 const mark=advice.sourceMarks.map(x=>`${x.bow==='up'?'∨ 上弓':'∏ 下弓'}（源音 ${x.id}）`).join('、');
 const source=mark?`电子谱识别标记（待核对）：${mark}。`:'本电子谱当前音未记录弓向。';
 if(!enabled)return source+' 分弓练习建议默认关闭；弓段未标。';
 if(!advice.practice)return source+` 暂不建议：${advice.reason}。弓段待定。`;
 const p=advice.practice;return source+` 练习建议：${p.direction==='up'?'∨ 上弓':'∏ 下弓'} · ${p.region}${p.restart?'（此段重新起弓）':''}；非原谱弓法，弓量随音色调整。`;
}
