// No automatic resume: every interruption requires a new explicit play request.
export function createLifecycleGuard({document,window,audio,onInterrupt}){
 let allowed=false,away=document.hidden===true;
 const revoke=()=>{allowed=false;};
 const interrupt=()=>{revoke();onInterrupt();};
 const visible=()=>!away&&!document.hidden;
 document.addEventListener('visibilitychange',()=>{away=document.hidden===true;if(away)interrupt();});
 window.addEventListener('pagehide',()=>{away=true;interrupt();});
 window.addEventListener('pageshow',()=>{away=document.hidden===true;});
 for(const event of ['play','playing'])audio.addEventListener(event,()=>{if(!allowed||!visible()){audio.pause();}});
 // Includes platform/audio-focus pauses. Do not interpret a pause as permission to resume.
 audio.addEventListener('pause',()=>{if(allowed&&audio.paused&&!audio.ended)interrupt();});
 return {revoke,canPlay:visible,arm(){if(!visible())return false;allowed=true;return true;},isAllowed(){return allowed&&visible();}};
}
