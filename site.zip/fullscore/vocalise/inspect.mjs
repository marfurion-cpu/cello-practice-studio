// Read-only score compatibility report. Never converts ornaments into guessed audio.
export function inspectVocalise(xml,Parser=globalThis.DOMParser){
 if(typeof xml!=='string'||xml.length>4e6||/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('Unsupported XML input');
 const d=new Parser().parseFromString(xml,'application/xml');
 if(d.getElementsByTagName('parsererror').length)throw Error('Invalid XML');
 const all=t=>Array.from(d.getElementsByTagName(t));
 for(const t of ['image','credit-image','link','opus'])if(all(t).length)throw Error('External assets not allowed');
 if(d.documentElement.localName!=='score-partwise'||all('part').length!==1)throw Error('Expected one part');
 const notes=all('note'),count=t=>all(t).length;
 const result={measures:count('measure'),notes:notes.length,cues:count('cue'),grace:count('grace'),trills:count('trill-mark'),fermata:count('fermata'),repeat:count('repeat'),endings:count('ending'),playable:false};
 result.mainPitched=notes.filter(n=>!n.getElementsByTagName('cue').length&&!n.getElementsByTagName('grace').length&&n.getElementsByTagName('pitch').length).length;
 result.blockers=['钢琴提示音必须排除，不能当作大提琴演奏','4个装饰音与2个颤音的时值、音高展开尚未实现','反复与一二房子声音展开尚未实现','终止延长号时间解释尚未实现'];
 return result;
}
