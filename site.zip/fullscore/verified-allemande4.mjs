import {parseMusicXML,tiedPlaybackPlan} from './musicxml-events.mjs';
import {verifyBytes} from './verified-courante.mjs';
const num=f=>f.n/f.d,frac=x=>{const n=x*96;if(!Number.isSafeInteger(n))throw Error("Unsupported exact Suite IV Allemande time");return {n,d:96}},rat=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b);
const midi=p=>12*(Number(p.octave)+1)+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[p.step])+Number(p.alter||0);
export async function adaptAllemande4(xml,planText,options={}){
 await verifyBytes(xml,'3e8da2dba3b62e95915c17d63fcd0d5fa7d04fa3426b083e61eeb86e30f5d2ae');await verifyBytes(planText,'90e0c3d923766123430521b0bfd21d40c7b9854b0ae66d06bd70b893d1bc4268');
 const plan=JSON.parse(planText),written=parseMusicXML(xml,options),route=plan.sourceRoute.map(x=>x-91);
 if(written.measures.length!==42||written.notes.length!==535||plan.events.length!==1068||route.length!==84)throw Error('Suite IV Allemande内置范围不一致');
 const bySource=new Map();for(let i=0;i<written.notes.length;i++){const a=written.notes[i],b=plan.writtenNotes[i];if(a.measureIndex+92!==b.sourceMeasure||a.voice!==b.voice||a.beats!==rat(b.duration)||num(a.onsetInMeasure)!==rat(b.onset)||JSON.stringify(a.pitch&&[a.pitch.step,a.pitch.alter,a.pitch.octave])!==JSON.stringify(b.pitch&&[b.pitch.step,Number(b.pitch.alter||0),Number(b.pitch.octave)]))throw Error('Suite IV Allemande源音符不一致');bySource.set(`${b.sourceMeasure}/${b.sourceNote}`,a);}
 const performance=plan.performedSourceNotes.flatMap(e=>e.trill?plan.events.filter(x=>x.visit===e.visit&&x.sourceMeasure===e.sourceMeasure&&x.sourceNote===e.sourceNote):[e]);
 const notes=performance.map((e,i)=>{const n=bySource.get(`${e.sourceMeasure}/${e.sourceNote}`),pitch=e.pitch?{step:e.pitch.step,alter:Number(e.pitch.alter||0),octave:Number(e.pitch.octave)}:null,vi=e.visit-1;
 if(!n)throw Error('Unexpected Suite IV Allemande source or tie');
 const slurs=e.suggestedOrnament?n.slurs.filter(s=>s.type==='start'?e.ornamentAttack===1:s.type==='stop'?e.ornamentAttack===4:false):n.slurs;
 return {...n,id:`v${vi}:attack${i}:${n.id}`,order:i,measureIndex:vi,measureNumber:String(e.sourceMeasure),onset:frac(rat(e.performedOnset)),duration:frac(rat(e.duration)),beats:rat(e.duration),pitch,midi:pitch?midi(pitch):null,slurs,sourceQuarter:num(n.onset),sourceNoteId:n.id,sourceMeasure:e.sourceMeasure,visit:vi,suggestedOrnament:!!e.suggestedOrnament,sourceOriginalPitch:n.pitch};});
 const measures=plan.visits.map((v,vi)=>{const source=written.measures[v.sourceMeasure-92];if(num(source.duration)!==rat(v.duration))throw Error('Suite IV Allemande measure duration');return {...source,index:vi,number:String(v.sourceMeasure),onset:frac(rat(v.onset)),noteIds:notes.filter(n=>n.measureIndex===vi).map(n=>n.id),sourceQuarter:num(source.onset),sourceOrdinal:source.index+1};});
 const groups=new Map();for(const n of notes){const t=num(n.onset);if(!groups.has(t))groups.set(t,[]);groups.get(t).push(n);}const events=[...groups].sort((a,b)=>a[0]-b[0]).map(([t,ns],index)=>({index,onset:frac(t),onsetBeats:t,notes:ns,noteIds:ns.map(n=>n.id)}));
 const score={...written,notes,measures,events,totalBeats:320,totalDuration:frac(320),verifiedPractice:true,suggestedTrill:true,displayRoute:route,writtenMeasureCount:42};
 const actual=tiedPlaybackPlan(score,60).notes,expected=plan.events.filter(n=>n.pitch).map(n=>({midi:midi(n.pitch),voice:n.voice,time:rat(n.performedOnset),duration:rat(n.duration)})),sort=xs=>xs.map(n=>[n.time,n.duration,n.midi,n.voice]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 if(JSON.stringify(sort(actual))!==JSON.stringify(sort(expected)))throw Error('Suite IV Allemande播放计划不一致');return score;
}
