import {verifyBytes} from './verified-courante.mjs';
import {parseMusicXML,tiedPlaybackPlan} from './musicxml-events.mjs';
const num=f=>f.n/f.d, frac=x=>{if(!Number.isSafeInteger(x*8))throw Error('Inexact Bourree time');return{n:x*8,d:8}},rat=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b);
export async function adaptBourree3(xml,planText,options={}){
 await verifyBytes(xml,'dd6011618511dac46663dc557a13cbb00cc4d908cf126da99382fa887bddc628');
 await verifyBytes(planText,'dd501f2bf822e9340b2d96770ec61c0b231b58950ba14abc4def50cbede85a35');
 const plan=JSON.parse(planText),written=parseMusicXML(xml,options),route=plan.sourceRoute.map(x=>x-224);
 if(written.measures.length!==30||written.notes.length!==191||plan.events.length!==382||route.length!==60)throw Error('内置范围不一致');
 for(let i=0;i<written.notes.length;i++){const a=written.notes[i],b=plan.writtenNotes[i];if(a.measureIndex+225!==b.sourceMeasure||a.voice!==b.voice||a.beats!==rat(b.duration)||num(a.onsetInMeasure)!==rat(b.onset)||JSON.stringify(a.pitch&&[a.pitch.step,a.pitch.alter,a.pitch.octave])!==JSON.stringify(b.pitch&&[b.pitch.step,Number(b.pitch.alter||0),Number(b.pitch.octave)]))throw Error('真实音符与已验计划不一致');}
 const notes=[],measures=[];let order=0;
 plan.visits.forEach((v,vi)=>{const source=written.measures[v.sourceMeasure-225],onset=rat(v.onset);if(num(source.duration)!==rat(v.duration))throw Error('小节时值不一致');const ns=written.notes.filter(n=>n.measureIndex===source.index).map(n=>({...n,id:`visit${vi}:${n.id}`,order:order++,measureIndex:vi,measureNumber:String(v.sourceMeasure),onset:frac(onset+num(n.onsetInMeasure)),sourceNoteId:n.id,sourceQuarter:num(n.onset),sourceMeasure:v.sourceMeasure,visit:vi}));notes.push(...ns);measures.push({...source,index:vi,number:String(v.sourceMeasure),onset:frac(onset),noteIds:ns.map(n=>n.id),sourceQuarter:num(source.onset),sourceOrdinal:source.index+1});});
 const groups=new Map();for(const n of notes){const k=num(n.onset);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(n);}const events=[...groups].sort((a,b)=>a[0]-b[0]).map(([t,ns],index)=>({index,onset:frac(t),onsetBeats:t,notes:ns,noteIds:ns.map(n=>n.id)}));
 const score={...written,notes,measures,events,totalBeats:224,totalDuration:frac(224),verifiedPractice:true,displayRoute:route,writtenMeasureCount:30};
 const actual=tiedPlaybackPlan(score,60).notes,expected=plan.events.filter(n=>n.pitch).map(n=>({midi:12*(Number(n.pitch.octave)+1)+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[n.pitch.step])+Number(n.pitch.alter||0),voice:n.voice,time:rat(n.performedOnset),duration:rat(n.duration)}));
 const sort=xs=>xs.map(n=>[n.time,n.duration,n.midi,n.voice]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 if(JSON.stringify(sort(actual))!==JSON.stringify(sort(expected)))throw Error('播放事件不符合已验源计划');
 return score;
}
