import {annotateMusicXML} from './note-labels.mjs';
import {createScoreRenderer} from './vendor/browser-bundle/osmd-renderer.mjs';
// A visit is an index in the performed route, NOT a printed measure number.
export function ktvWindow(route,visit){
 if(!Array.isArray(route)||!route.length||!route.every(n=>Number.isInteger(n)&&n>0)||!Number.isInteger(visit)||visit<0||visit>=route.length)throw Error('Invalid performance visit');
 const activeRow=visit%2,rows=[null,null];rows[activeRow]={visit,measure:route[visit],active:true};
 if(visit+1<route.length)rows[1-activeRow]={visit:visit+1,measure:route[visit+1],active:false};
 return {visit,activeRow,rows};
}
export function visitForSource(route,startVisit,sourceMeasure){
 if(!Number.isInteger(startVisit)||startVisit<0||startVisit>=route.length)throw Error('Invalid source visit');
 const visit=route.findIndex((measure,i)=>i>=startVisit&&measure===sourceMeasure);
 if(visit<0)throw Error('Source measure missing from performance route');return visit;
}
export function createKtvRenderer({container,OpenSheetMusicDisplay,documentObject=globalThis.document,rendererFactory=createScoreRenderer,annotator=annotateMusicXML}){
 let generation=0,current=null,pending=new Set();
 const destroy=s=>{if(!s)return;s.renderers.forEach(r=>r.dispose());s.root.remove();};
 function paint(s,visit,{waiting=false}={}){const view=ktvWindow(s.route,visit);s.renderers.forEach(r=>r.hideCursor());
  view.rows.forEach((row,i)=>{const section=s.sections[i];section.hidden=!row;section.setAttribute('aria-current',row?.active&&!waiting?'true':'false');
   if(row){s.headings[i].textContent=`${row.active?(waiting?'休止 / 静音 · 待演奏':'正在演奏'):'下一小节'} · 源小节 ${s.labels?.[row.measure-1]??row.measure} · 第 ${row.visit+1} 次小节`;
    s.annotations[i].textContent=s.measureAnnotations[row.measure]||'';s.annotations[i].hidden=!s.annotations[i].textContent;
    s.renderers[i].showMeasure(row.measure);}
  });s.view={...view,waiting};return s.view;
 }
 return {
  async load(xml,{measureCount,sourceLabels=null,identitySource=null,mergeCoincidentVoices=false,measureAnnotations={},route=Array.from({length:measureCount},(_,i)=>i+1)}={}){
   if(!Number.isInteger(measureCount)||measureCount<1||!route.length||route.some(n=>!Number.isInteger(n)||n<1||n>measureCount))throw Error('Invalid score route');
   const annotated=annotator(xml,{mergeCoincidentVoices,identitySource:mergeCoincidentVoices?identitySource:null});
   const request=++generation,root=documentObject.createElement('div');root.className='ktv-score';root.style.cssText='position:absolute;left:0;top:0;width:100%;height:100%;visibility:hidden;pointer-events:none';
   const s={root,labels:sourceLabels,route:[...route],renderers:[],sections:[],headings:[],annotations:[],measureAnnotations,view:null};
   for(let i=0;i<2;i++){const section=documentObject.createElement('section'),heading=documentObject.createElement('div'),host=documentObject.createElement('div');section.className='ktv-row';heading.className='ktv-heading';host.className='ktv-staff';host.setAttribute('aria-label',i?'下行五线谱':'上行五线谱');const annotation=documentObject.createElement('small');annotation.className='source-annotation';annotation.style.cssText='white-space:pre-wrap;font-size:11px;line-height:1.4;color:#365B48';section.append(heading,host,annotation);s.annotations.push(annotation);root.append(section);s.sections.push(section);s.headings.push(heading);s.renderers.push(rendererFactory({container:host,OpenSheetMusicDisplay,documentObject}));}
   pending.add(s);container.append(root);
   try{
    await Promise.all(s.renderers.map(r=>r.load(annotated.xml,{measureCount,identitySource})));
    if(request!==generation){destroy(s);return {stale:true};}
    paint(s,0);root.style.cssText='';const previous=current;container.replaceChildren(root);current=s;destroy(previous);
    return {stale:false,measureCount,renderedOrdinal:1,labelWarnings:annotated.warnings};
   }catch(error){destroy(s);throw error;}finally{pending.delete(s);}
  },
  showVisit(visit,options={}){if(!current)throw Error('Score not loaded');return paint(current,visit,options);},
  showMeasure(ordinal){if(!current)throw Error('Score not loaded');const visit=ordinal-1;if(current.route[visit]!==ordinal)throw Error('Use performed visit for repeated scores');return this.showVisit(visit);},
  seekQuarter(onset){if(!current?.view)throw Error('Score not loaded');return current.renderers[current.view.activeRow].seekQuarter(onset);},
  seekIdentities(identities){if(!current?.view)throw Error('Score not loaded');return current.renderers[current.view.activeRow].seekIdentities(identities);},
  hideCursor(){current?.renderers.forEach(r=>r.hideCursor());},
  resize(){if(current){current.renderers.forEach((r,i)=>{if(current.view.rows[i])r.resize();});paint(current,current.view.visit,{waiting:current.view.waiting});}},
  cancelPending(){generation++;for(const s of pending)s.renderers.forEach(r=>r.cancelPending());},
  dispose(){generation++;for(const s of pending)destroy(s);pending.clear();destroy(current);current=null;container.replaceChildren();}
 };
}
