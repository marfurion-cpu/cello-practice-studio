import {mountManualReturn} from './manual-return.mjs';
import {measureEntries,measureTarget} from './measure-navigation.mjs';
import {adaptSuite5} from './suite5-adapter.mjs';
import {bassClefView,renderFourStringStudy} from './four-string-study.mjs';
import {adaptAllemande6} from './verified-allemande6.mjs';
import {adaptPrelude6} from './verified-prelude6.mjs';
import {adaptCourante6} from './verified-courante6.mjs';
import {adaptGigue6} from './verified-gigue6.mjs';
import {adaptGavotte16} from './verified-gavotte16.mjs';
import {adaptGavotte26} from './verified-gavotte26.mjs';
import {adaptSarabande6} from './verified-sarabande6.mjs';
import {adaptCourante4} from './verified-courante4.mjs';
import {adaptPrelude4} from './verified-prelude4.mjs';
import {adaptSarabande4} from './verified-sarabande4.mjs';
import {adaptAllemande4} from './verified-allemande4.mjs';
import {adaptSarabande2} from './verified-sarabande2.mjs';
import {adaptAllemande1} from './verified-allemande1.mjs';
import {parseMusicXML as parsePinnedAllemande1} from './pinned-grace-parser.mjs';
import {adaptPrelude3} from './verified-prelude3.mjs';
import {adaptAllemande3} from './verified-allemande3.mjs';
import {adaptBourree32} from './verified-bourree32.mjs';
import {adaptCourante3} from './verified-courante3.mjs';
import {adaptGigue4} from './verified-gigue4.mjs';
import {adaptBourree42} from './verified-bourree42.mjs';
import {adaptBourree4} from './verified-bourree4.mjs';
import {adaptGigue3} from './verified-gigue3.mjs';
import {adaptSarabande3} from './verified-sarabande3.mjs';
import {adaptBourree3} from './verified-bourree3.mjs';
import {adaptMenuet22} from './verified-menuet22.mjs';
import {adaptMenuet21} from './verified-menuet21.mjs';
import {adaptPrelude2} from './verified-prelude2.mjs';
import {adaptAllemande2} from './verified-allemande2.mjs';
import {adaptGigue2} from './verified-gigue2.mjs';
import {adaptPrelude} from './verified-prelude.mjs';
import {adaptSarabande} from './verified-sarabande.mjs';
import {adaptCourante1} from './verified-courante1.mjs';
import {adaptMenuet2} from './verified-menuet2.mjs';
import {adaptMenuet} from './verified-menuet.mjs';
import {adaptGigue} from './verified-gigue.mjs';
import {adaptCourante,sourcePosition} from './verified-courante.mjs';
import {createLifecycleGuard} from './vocalise/lifecycle-guard.mjs';
import {mountVibrato,comparisonNote} from './vibrato-panel.mjs';
import {tiedPlaybackPlan} from './musicxml-events.mjs';
import {parseMusicXML} from './musicxml-events.mjs';
import {buildTimeline} from './timeline.mjs';
import {candidates,solve,label} from './fingering.mjs';
import {chordAdvice} from './chord-fingering.mjs';
import {drawChordHandframe,drawHandframe} from './handframe.mjs';
import {slicePlan,makePolyWav} from './polyphonic-audio.mjs';
import {createKtvRenderer as createScoreRenderer} from './ktv-renderer.mjs';
const $=id=>document.getElementById(id),player=$('nativeAudio');
// Owner-approved private practice defaults; explicit opt-out remains effective across piece changes.
$('verifiedAck').checked=true;$('trillChoice').checked=true;
let state={notes:[],path:[],locks:{},index:0},score=null,request=0,audioRequest=0,url=null,plan=null,resumeBeat=null,shown=-1;
let selectedPiece=null,selectedRequest=-1;
const returnButton=document.createElement('button');returnButton.id='manualReturn';returnButton.type='button';returnButton.textContent='返回同套 I';returnButton.hidden=true;
returnButton.title='手动加载同套第一支舞曲，不自动播放；不执行完整 I–II–I 或 Coda 路线。';
returnButton.setAttribute('aria-label',returnButton.title);
returnButton.style.cssText='flex:none;width:68px;min-width:68px;height:32px;min-height:32px;font-size:11px;padding:0 3px;margin:0;white-space:nowrap;';
// Reuse the existing 32px score-header row; never insert a new row between score and board.
$('measureSelect').parentElement.prepend(returnButton);
const syncManualReturn=mountManualReturn({button:returnButton,
 snapshot:()=>({piece:selectedPiece,acceptedRequest:selectedRequest,request,measureIndex:state.notes[state.index]?.measureIndex,measureCount:score?.measures.length}),
 stop:()=>stop(),activate:id=>$(id).click()});
const renderer=createScoreRenderer({container:$('engraving'),OpenSheetMusicDisplay:opensheetmusicdisplay.OpenSheetMusicDisplay});
let vibrato=null,sourceVibrato='uncertain';
let playbackIntent=false,segmentBusy=false;
let acceptedTempo=Number($('tempo').value);
function syncTempoControls(){const bpm=Number($('tempo').value);if(Number.isFinite(bpm))acceptedTempo=bpm;$('bpm').textContent=String(bpm);const number=$('tempoNumber');if(number)number.value=String(bpm);}
vibrato=mountVibrato($('vibratoPanel'),()=>stop());
const lifecycle=createLifecycleGuard({document,window:globalThis,audio:player,onInterrupt:()=>{stop();$('audioStatus').textContent='试听已停止；返回页面后请手动点击播放。';}});
function stop(){syncManualReturn();playbackIntent=false;segmentBusy=false;lifecycle.revoke();vibrato?.stop();resumeBeat=null;audioRequest++;plan=null;player.pause();player.removeAttribute('src');$('play').textContent='▶ 播放';$('audioStatus').textContent='试听已停止；点播放从当前音开始。';}
function audioFailure(message){stop();$('audioStatus').textContent=message+'。未确认声音可听。请先点播放，再检查媒体音量及蓝牙/耳机输出；iPhone 可检查静音开关。仍无声请停止反复播放，并记录 iOS、浏览器和输出设备。';}
function rejectExternalAssets(tree){if(tree.name==='sound'&&['dacapo','dalsegno','tocoda','fine'].some(k=>Object.hasOwn(tree.attrs||{},k)))throw Error('暂不支持 D.C./D.S./Coda/Fine 演奏跳转，请导入已展开并校对的版本。');if(['repeat','ending'].includes(tree.name))throw Error('暂不支持反复/一二房子，请使用经过校对的展开主声部版本。');if(['image','credit-image','link','opus'].includes(tree.name))throw Error('为保护本机乐谱，暂不加载带外部图片或链接资源的 MusicXML。');for(const c of tree.children||[])rejectExternalAssets(c);}
function fail(e){$('error').textContent=e.message;$('error').hidden=false;}
let measureScore=null,measureOptions=[];
function syncMeasureControls(n){
 if(measureScore!==score){
  measureScore=score;measureOptions=measureEntries(score);
  $('measureSelect').replaceChildren(...measureOptions.map(m=>{const o=document.createElement('option');o.value=m.index;o.textContent=m.label.replace(/^原谱第\s*/,'').replace(/\s*小节/,'小节').replace(/ · 第 (\d+) 次/,' ·$1次');o.title=m.label;return o;}));
 }
 const index=measureOptions.findIndex(m=>m.measureIndex===n.measureIndex);
 $('measureSelect').value=String(index);$('measureSelect').disabled=index<0;
 $('prevMeasure').disabled=index<=0;$('nextMeasure').disabled=index<0||index>=measureOptions.length-1;
 $('measurePosition').textContent=index<0?'':`${index+1} / ${measureOptions.length} 个演奏小节（含反复）`;
}
function jumpMeasure(index){
 if(!score)return;const target=measureTarget(score,state.notes,index);if(!target)return;
 stop();state.index=target.noteIndex;resumeBeat=target.startBeat;render();
 $('audioStatus').textContent=`已跳到${target.label}；点播放从该小节开头开始。`;
}
$('measureSelect').onchange=()=>jumpMeasure(Number($('measureSelect').value));
$('prevMeasure').onclick=()=>jumpMeasure(Number($('measureSelect').value)-1);
$('nextMeasure').onclick=()=>jumpMeasure(Number($('measureSelect').value)+1);
function render(){
 syncManualReturn();
 syncTempoControls();
 const n=state.notes[state.index];if(!n)return;const fingeringsAllowed=score.fingeringEnabled!==false,c=fingeringsAllowed?state.path[state.index]:null;
 syncMeasureControls(n);
 const events=tiedPlaybackPlan(score,Number($('tempo').value)).notes,t=n.time*60/Number($('tempo').value),sounding=events.filter(e=>e.time<=t+1e-8&&e.time+e.duration>t+1e-8),event=sounding[0];
 const inconsistent=event&&state.notes.some((x,i)=>x.time*60/Number($('tempo').value)>=event.time-1e-8&&x.time*60/Number($('tempo').value)<event.time+event.duration-1e-8&&state.path[i]?.key!==c?.key);
 vibrato.update(comparisonNote(event,c,{sourceVibrato,doubleStop:sounding.length!==1||n.polyphonic,unsupported:!fingeringsAllowed||!!score.suggestedTrill||!!score.suggestedFermata||inconsistent||!!n.unsupportedTechniques?.length,offset:event?Math.max(0,t-event.time):0}));
 $('pitch').textContent=(n.notes.some(x=>x.suggestedTimingKind==='grace')?'装饰小音符（建议借时） · ':n.notes.some(x=>x.suggestedTimingKind==='borrowed-host')?'主音（已借时） · ':n.notes.some(x=>x.suggestedOrnament)?'建议装饰 · ':n.notes.some(x=>x.suggestedFermataTiming)?'建议延长 · ':n.notes.some(x=>x.suggestedStaccato)?'建议断奏 · ':'')+n.name;$('frequency').textContent=n.midi===null?'':(440*2**((n.midi-69)/12)).toFixed(1)+' Hz';
 $('seek').max=state.notes.length-1;$('seek').value=state.index;
 $('position').textContent=`${state.index+1}/${state.notes.length}`;$('count').textContent=score.verifiedPractice?`源节点 ${n.measure} · 第 ${n.measureIndex+1}/${score.measures.length} 次访问`:`第 ${n.measure} 小节 / ${score.measures.length}`;
 // Keep the action reachable: a disabled button cannot explain an unmet practice gate on touch devices.
 $('play').disabled=false;
 const gateMissing=!!score.verifiedPractice&&(!$('verifiedAck').checked||((score.suggestedTrill||score.suggestedFermata)&&!$('trillChoice').checked));
 $('play').setAttribute('aria-label',gateMissing?'播放：练习试听已在设置中关闭':'播放或停止电子试听');
 $('prev').disabled=!state.index;$('next').disabled=state.index===state.notes.length-1;
 const chord=fingeringsAllowed&&n.polyphonic?chordAdvice(n):null;
 $('recommendation').textContent=!fingeringsAllowed?'第六组曲：五弦指法未建模；只阅谱与按编码音高试听，不推荐四弦指法':n.unsupportedTechniques?.length?'源谱含'+n.unsupportedTechniques.map(t=>t==='harmonic'?'泛音':'拇指把位').join('、')+' · 不推测常规指法':n.polyphonic?chord.text:c?label(c):'此音超出当前有限指法范围，不猜测';
 drawHandframe(c,fingeringsAllowed?state:null);if(chord?.option)drawChordHandframe(chord.option);$('candidates').replaceChildren();
 if(fingeringsAllowed&&!n.polyphonic)for(const x of candidates(n)){if(x.rest)continue;const b=document.createElement('button');b.textContent=label(x);b.onclick=()=>{if(score.fingeringEnabled===false)return;state.locks[state.index]=x.key;state.path=solve(state.notes,state.locks);render();};$('candidates').append(b);}
 if(score.fourStringStudy)renderFourStringStudy(n,{compact:score.compactStudy===true,knownStops:chord?.option?.stops??(c&&!c.rest?[c]:[]),board:$('board'),recommendation:$('recommendation'),candidates:$('candidates'),selection:state.studyLocks?.[state.index],onSelect:key=>{state.studyLocks??={};state.studyLocks[state.index]=key;render();}});
 $('reset').hidden=!fingeringsAllowed||!state.locks[state.index];$('reset').disabled=!fingeringsAllowed;
 const group=n.sourceGroups[0], tied=n.notes.some(x=>(x.ties||[]).some(t=>t.type==='stop'));
 // Polyphony suppresses unique bow advice; ties retain prior direction without a new attack.
 const original=n.sourceBow;
 const suggested=original||($('bowPractice').checked&&n.practiceBow);
 $('bowGlyph').textContent=suggested?(suggested==='下弓'?'Π':'V'):'—';$('bowDirection').textContent=suggested||'弓向未标注';$('bowOrigin').textContent=original?'源标优先·非大师认证':suggested?(n.bowReason.includes('段首')?'段首假设·未审':n.bowReason.includes('延续')||n.bowReason.includes('持续')?'延音保持·未审':n.bowReason.includes('连线')?'同组延续·未审':'交替建议·未审'):(n.bowReason.includes('冲突')?'冲突停建议':'源谱未标弓向');$('bowOrigin').title=n.bowReason;
 const groupOrdinal=group?Math.max(0,...n.notes.map(x=>group.noteIds.indexOf(x.id)+1)):0;
 $('bowGroup').textContent=(score.slurInterpretation==='display-only-cross-voice'?'原谱连线保留；不推断运弓，声音未模拟连奏':score.suggestedFermata?'原谱连线保留；延长时值只是练习建议':score.suggestedTrill?'原谱连线保留；建议颤音子击不等于源谱新增音符':n.polyphonic?'多声部连线请见原谱':n.releaseOnly?'持续/释放，不新起弓':group?`源连线 ${groupOrdinal}/${group.noteIds.length} · ${group.end>n.time?'后续仍同组':'本组末音'}`:'连线未标注')+' · 弓段未标注'+(tied?' · 延音保持':'');
 try{if(shown!==n.measureIndex){if(score.verifiedPractice)renderer.showVisit(n.measureIndex);else renderer.showMeasure(n.measureIndex+1);shown=n.measureIndex;}
 if(!n.releaseOnly)$('warnings').textContent=score.fourStringStudy?'四弦标准调弦 C2/G2/D3/A3 · 低音谱号显示不移调 · 拇指候选未经教师逐句审定':!fingeringsAllowed?'五弦指法未验：网格仅为普通四弦参考，无按指/和弦推荐；揉弦比较禁用':n.unsupportedTechniques?.length?'特殊奏法未模拟 · 试听仅按书写音高，未必等于泛音实响':'电子试听 · 有限常规指法模型，未标记不等于普通奏法 · 未经教师审核';
 if(n.releaseOnly){renderer.hideCursor();$('warnings').textContent=n.rest?'休止 / 无新起音 · 游标暂隐':'延音保持 · 无新起音 · 游标暂隐';}else if(score.sourceIdentityRequired)renderer.seekIdentities(n.notes.filter(x=>!x.rest&&!x.cue).map(x=>x.sourceIdentity));else renderer.seekQuarter(score.verifiedPractice?(n.notes[0]?.sourceQuarter??sourcePosition(score,n.time).sourceQuarter):n.time);}catch(e){fail(Error('当前谱面游标未能定位：'+e.message));}
}
function selectPiece(id){
 selectedPiece=id;selectedRequest=request;syncManualReturn();
 let selectedLabel=null;
 $('demo').classList.remove('primary');
 for(const [button,piece] of [['piatti1','piatti1'],['suite5Prelude','suite5Prelude'],['suite5Allemande','suite5Allemande'],['suite5Courante','suite5Courante'],['suite5Sarabande','suite5Sarabande'],['suite5GavotteI','suite5GavotteI'],['suite5GavotteII','suite5GavotteII'],['suite5Gique','suite5Gique'],['suite6allemande','suite6allemande'],['suite6prelude','suite6prelude'],['suite6courante','suite6courante'],['suite6gigue','suite6gigue'],['suite6gavotte1','suite6gavotte1'],['suite6gavotte2','suite6gavotte2'],['suite6sarabande','suite6sarabande'],['suite4courante','suite4courante'],['suite4prelude','suite4prelude'],['suite4sarabande','suite4sarabande'],['suite4allemande','suite4allemande'],['suite2sarabande','suite2sarabande'],['suite1allemande','suite1allemande'],['suite3prelude','suite3prelude'],['suite3allemande','suite3allemande'],['suite3bourree2','suite3bourree2'],['suite3courante','suite3courante'],['suite2courante','suite2courante'],['suite1gigue','suite1gigue'],['suite1menuet1','suite1menuet1'],['suite1menuet2','suite1menuet2'],['suite1courante','suite1courante'],['suite1sarabande','suite1sarabande'],['suite1prelude','suite1prelude'],['suite2gigue','suite2gigue'],['suite2allemande','suite2allemande'],['suite2prelude','suite2prelude'],['suite2menuet1','suite2menuet1'],['suite2menuet2','suite2menuet2'],['suite3bourree1','suite3bourree1'],['suite3sarabande','suite3sarabande'],['suite3gigue','suite3gigue'],['suite4bourree1','suite4bourree1'],['suite4bourree2','suite4bourree2'],['suite4gigue','suite4gigue']]){
  const active=id===piece;$(button).classList.toggle('primary',active);$(button).setAttribute('aria-pressed',String(active));if(active){selectedLabel=$(button).dataset?.pieceLabel||$(button).textContent;const group=$(button).closest?.('details.suite-group');if(group)group.open=true;}
 }
 const summary=$('pieceMenuSummary');if(summary){summary.textContent=selectedLabel?'已选：'+selectedLabel:'曲目 / 导入 · 合成示例或本机导入';summary.classList.toggle('has-selection',!!selectedLabel);}
}
selectPiece(null);
async function load(xml,source,verified=false,displayTitle=null,pieceId=null,{piatti=false}={}){
 const token=++request;renderer.cancelPending();stop();try{const next=parseMusicXML(xml,{maxLength:4000000});rejectExternalAssets(next.sourceTree);if(next.notes.length>3000)throw Error('本手机原型最多3000个书写音/休止，请分段导入。');const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:next.measures.length});if(token!==request)return;
 sourceVibrato=verified&&!/vib|wavy-line|harmonic/i.test(xml)?'unmarked':'uncertain';
 if(piatti){next.fourStringStudy=true;next.compactStudy=true;}score=next;$('verifiedScope').hidden=true;$('trillScope').hidden=true;$('bowPractice').disabled=piatti;if(piatti)$('bowPractice').checked=false;state={notes,path,index:0,locks:{}};selectPiece(pieceId);shown=-1;plan=null;if(url)URL.revokeObjectURL(url);url=null;player.removeAttribute('src');
 $('title').textContent=displayTitle||next.title;$('title').title=next.title;$('source').textContent=piatti?'按 Simrock 初版手工转录：起音、节拍及终止双音练习。未转录原版延音层、弓法或力度。':verified?'完整Bach谱 · 音高/时值与同源MIDI一致':'本机导入谱 · 未外部校对';$('license').textContent=source;$('warnings').textContent='原谱保留全部音/连线；和弦仅提供有限共用手位候选，未经教师审核；弓段及真实弓法音色尚未支持。';$('error').hidden=true;render();
 }catch(e){if(token===request)fail(e);}
}
async function builtin(id){const token=++request;renderer.cancelPending();stop();try{const [xml,meta]=await Promise.all([fetch('data/'+id+'-prelude-complete.musicxml').then(r=>{if(!r.ok)throw Error('曲谱加载失败');return r.text();}),fetch('data/'+id+'-prelude-complete.json').then(r=>r.json())]);if(token!==request)return;await load(xml,`${meta.sourceVersion} · ${meta.license} · ${meta.attribution} · 转制完整XML，非大师指法版`,true,id==='bwv1007'?'巴赫第1组曲 · 前奏曲（全曲）':'巴赫第2组曲 · 前奏曲（全曲）',id);}catch(e){if(token===request)fail(e);}}
$('suite4gigue').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const fetchText=async name=>{const r=await fetch('data/suite4gigue/'+name);if(!r.ok)throw Error('内置曲谱加载失败');return r.text();};
 const [xml,raw]=await Promise.all([fetchText('display.musicxml'),fetchText('practice-plan.json')]);
 const next=await adaptGigue4(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:44,route:next.displayRoute,sourceLabels:Array.from({length:44},(_,i)=>String(i+296))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite4gigue');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第四套 · Gigue（独立完整乐章）';$('source').textContent='PDMX真实源296–339；88次小节访问 · 非整套导航 · 非同源MIDI验收';
 $('license').textContent='PDMX v9 / MuseScore4508871，归档上传者Public Domain Mark声明（不是CC0授权），非独立版权核验。原XML与出处见下方。';$('tempo').value=180;$('bpm').textContent='180';$('error').hidden=true;$('verifiedScope').hidden=false;$('trillScope').hidden=true;$('verifiedText').textContent='第四套Gigue独立完整乐章，88访问；无装饰替代；源起点Coda保留，不执行跨曲导航；四分音符180=附点四分音符120，源296明示，独立结尾停止，不返回Gigue。不是完整组曲，有限指法未经教师审核。';$('bowPractice').disabled=false;$('bowPractice').checked=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite4bourree2').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const fetchText=async name=>{const r=await fetch('data/suite4bourree2/'+name);if(!r.ok)throw Error('内置曲谱加载失败');return r.text();};
 const [xml,raw]=await Promise.all([fetchText('display.musicxml'),fetchText('practice-plan.json')]);
 const next=await adaptBourree42(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:14,route:next.displayRoute,sourceLabels:Array.from({length:14},(_,i)=>String(i+282))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite4bourree2');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第四套 · Bourrée II（独立完整乐章）';$('source').textContent='PDMX真实源282–295；28次小节访问 · 非整套导航 · 非同源MIDI验收';
 $('license').textContent='PDMX v9 / MuseScore4508871，归档上传者Public Domain Mark声明（不是CC0授权），非独立版权核验。原XML与出处见下方。';$('tempo').value=120;$('bpm').textContent='120';$('error').hidden=true;$('verifiedScope').hidden=false;$('trillScope').hidden=true;$('verifiedText').textContent='第四套Bourrée II独立完整乐章，28访问；无装饰替代；源文字da Capo与sound D.S.保留但不执行；速度120继承源232（本乐章无独立速度），独立结尾停止，不返回Bourrée II。不是完整组曲，有限指法未经教师审核。';$('bowPractice').disabled=false;$('bowPractice').checked=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite4bourree1').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const fetchText=async name=>{const r=await fetch('data/suite4bourree1/'+name);if(!r.ok)throw Error('内置曲谱加载失败');return r.text();};
 const [xml,raw]=await Promise.all([fetchText('display.musicxml'),fetchText('practice-plan.json')]);
 const next=await adaptBourree4(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:50,route:next.displayRoute,sourceLabels:Array.from({length:50},(_,i)=>String(i+232))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite4bourree1');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第四套 · Bourrée I（独立完整乐章）';$('source').textContent='PDMX真实源232–281；100次小节访问 · 非整套导航 · 非同源MIDI验收';
 $('license').textContent='PDMX v9 / MuseScore4508871，归档上传者Public Domain Mark声明（不是CC0授权），非独立版权核验。原XML与出处见下方。';$('tempo').value=120;$('bpm').textContent='120';$('error').hidden=true;$('verifiedScope').hidden=false;$('trillScope').hidden=true;$('verifiedText').textContent='第四套Bourrée I独立完整乐章，100访问；无装饰替代；源Segno/To Coda保留但不执行，独立结尾停止，不连接Bourrée II。不是完整组曲，有限指法未经教师审核。';$('bowPractice').disabled=false;$('bowPractice').checked=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite6gavotte1').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite6gavotte1/'+name);if(!r.ok)throw Error('第六套Gavotte I加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptGavotte16(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=[];await renderer.load(bassClefView(xml),{measureCount:30,identitySource:parsePinnedAllemande1(xml),mergeCoincidentVoices:true,route:next.displayRoute,sourceLabels:Array.from({length:30},(_,i)=>String(i+233))});if(token!==request)return;
 next.fourStringStudy=true;score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite6gavotte1');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第六套 · Gavotte I（独立乐章；四弦高把位练习）';$('source').textContent='PDMX真实源233–262，60访问224拍；全部声部、音符及反复保留。';$('license').textContent='PDMX v9 索引记录 MuseScore 4601476 上传声明 CC0；非官方授权、非独立权属保证。';$('tempo').value=120;$('bpm').textContent='120';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='Gavotte I 单曲练习：两段各反复两次后停止；原 To Coda 及 I–II 回返暂不自动执行。源254 F♯4小音采用短倚音建议：借后续E4的1/4拍，E4延后并保留7/4拍，伴奏A3仍原起点2拍；不是原谱规定时值。仅阅谱和按MusicXML编码音高电子试听；四弦高把位练习，已提供四弦音高落点与A/D弦拇指手型候选；候选来自规则模型，不是原谱或大师指定指法。多音落点不等于可同时按弦，揉弦比较保持禁用。谱面统一低音谱号，音高不变；切回其他已支持曲目恢复其有限模型。';$('trillScope').hidden=true;$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite6gavotte2').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite6gavotte2/'+name);if(!r.ok)throw Error('第六套Gavotte II加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptGavotte26(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=[];await renderer.load(bassClefView(xml),{measureCount:26,mergeCoincidentVoices:true,route:next.displayRoute,sourceLabels:Array.from({length:26},(_,i)=>String(i+263))});if(token!==request)return;
 next.fourStringStudy=true;score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite6gavotte2');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第六套 · Gavotte II（独立乐章；四弦高把位练习）';$('source').textContent='PDMX真实源263–288，52访问192拍；全部声部、音符及反复保留。';$('license').textContent='PDMX v9 索引记录 MuseScore 4601476 上传声明 CC0；非官方授权、非独立权属保证。';$('tempo').value=120;$('bpm').textContent='120';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='Gavotte II 单曲练习：两段各反复两次后停止；原谱要求返回 Gavotte I，本练习暂不自动执行该跳转。仅阅谱和按MusicXML编码音高电子试听；四弦高把位练习，已提供四弦音高落点与A/D弦拇指手型候选；候选来自规则模型，不是原谱或大师指定指法。多音落点不等于可同时按弦，揉弦比较保持禁用。谱面统一低音谱号，音高不变；切回其他已支持曲目恢复其有限模型。';$('trillScope').hidden=true;$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite6allemande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite6allemande/'+name);if(!r.ok)throw Error('第六套Allemande加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptAllemande6(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=[];await renderer.load(bassClefView(xml),{measureCount:22,mergeCoincidentVoices:true,measureAnnotations:{"2": "原谱括号：(    )（保留原文，不解释附着对象或可省略）", "3": "原谱括号：(    )（保留原文，不解释附着对象或可省略）", "4": "原谱括号：(    )（保留原文，不解释附着对象或可省略）", "12": "原谱括号：(    )（保留原文，不解释附着对象或可省略）", "13": "原谱括号：(    )（保留原文，不解释附着对象或可省略）", "17": "原谱括号：(    )（保留原文，不解释附着对象或可省略）", "9": "源113上方F谱号形文字，意图未定，不据此改变音高；源114本来就有独立的正式换谱号。"},route:next.displayRoute,sourceLabels:Array.from({length:22},(_,i)=>String(i+105))});if(token!==request)return;
 next.fourStringStudy=true;score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite6allemande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第六套 · Allemande（独立乐章；四弦高把位练习）';$('source').textContent='PDMX真实源105–126，44访问160拍；全部声部、音符及反复保留。';$('license').textContent='PDMX v9 索引记录 MuseScore 4601476 上传声明 CC0；非官方授权、非独立权属保证。';$('tempo').value=30;$('bpm').textContent='30';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第六套Allemande独立练习：六处原括号保留并明确显示，不推断附着或可省略；源113 F谱号形只是含义未定的上方文字，不据此改音高，源114实际换谱号照原谱保留。仅阅谱和按MusicXML编码音高电子试听；四弦高把位练习，已提供四弦音高落点与A/D弦拇指手型候选；候选来自规则模型，不是原谱或大师指定指法。多音落点不等于可同时按弦，揉弦比较保持禁用。谱面统一低音谱号，音高不变；切回其他已支持曲目恢复其有限模型。';$('trillScope').hidden=false;$('trillDetails').textContent='13处原颤音均采用主音/上邻/主音/上邻四等分原时值，两遍共104个建议子击；源121两个独立颤音分别保留。上邻按调号及当前小节变音核定，时值精确分数；这是练习建议，不是原谱规定或唯一演绎。';$('trillContext').textContent='原括号、连线、变音及正式谱号保留；声音不模拟完整弓法，颤音子击游标停各自母音，四弦高把位练习。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite6gigue').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite6gigue/'+name);if(!r.ok)throw Error('第六套Gigue加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptGigue6(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=[];await renderer.load(bassClefView(xml),{measureCount:70,mergeCoincidentVoices:true,route:next.displayRoute,sourceLabels:Array.from({length:70},(_,i)=>String(i+289))});if(token!==request)return;
 next.fourStringStudy=true;score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite6gigue');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第六套 · Gigue（独立乐章；四弦高把位练习）';$('source').textContent='PDMX真实源289–358，140访问408拍；全部声部、音符及反复保留。';$('license').textContent='PDMX v9 索引记录 MuseScore 4601476 上传声明 CC0；非官方授权、非独立权属保证。';$('tempo').value=90;$('bpm').textContent='90';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第六套Gigue独立节拍练习：原Coda落点保留，不连接Gavotte I或整套导航；源319三处断奏保留，声音按记谱时值，不模拟断奏缩短/完整发音法。仅阅谱和按MusicXML编码音高电子试听；四弦高把位练习，已提供四弦音高落点与A/D弦拇指手型候选；候选来自规则模型，不是原谱或大师指定指法。多音落点不等于可同时按弦，揉弦比较保持禁用。谱面统一低音谱号，音高不变；切回其他已支持曲目恢复其有限模型。';$('trillScope').hidden=false;$('trillDetails').textContent='源342 A3/B3/A3/B3四等分，覆盖原1拍，每击1/4拍，两遍反复均保留。明确练习建议，不是原谱规定时值或唯一演绎。';$('trillContext').textContent='原断奏记号和弓法显示保留，声音不模拟完整发音法；颤音子击游标停母音，四弦高把位练习。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite6courante').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite6courante/'+name);if(!r.ok)throw Error('第六套Courante加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptCourante6(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=[];await renderer.load(bassClefView(xml),{measureCount:74,mergeCoincidentVoices:true,measureAnnotations:{29:'源155原谱上方文字为C谱号形，含义尚未确定；不是换谱号事件，不据此改音高。'},route:next.displayRoute,sourceLabels:Array.from({length:74},(_,i)=>String(i+127))});if(token!==request)return;
 next.fourStringStudy=true;score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite6courante');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第六套 · Courante（独立乐章；四弦高把位练习）';$('source').textContent='PDMX真实源127–200，148访问432拍；全部声部、音符及反复保留。';$('license').textContent='PDMX v9 索引记录 MuseScore 4601476 上传声明 CC0；非官方授权、非独立权属保证。';$('tempo').value=100;$('bpm').textContent='100';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第六套Courante独立乐章；源155上方文字为C谱号形，含义尚未确定。它不是attributes/clef事件，本练习不据此改变音高；保留图形与文字旁注。仅阅谱和按MusicXML编码音高电子试听；四弦高把位练习，已提供四弦音高落点与A/D弦拇指手型候选；候选来自规则模型，不是原谱或大师指定指法。多音落点不等于可同时按弦，揉弦比较保持禁用。谱面统一低音谱号，音高不变；切回其他已支持曲目恢复其有限模型。';$('trillScope').hidden=true;$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite6prelude').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite6prelude/'+name);if(!r.ok)throw Error('第六套Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptPrelude6(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=[];await renderer.load(bassClefView(xml),{measureCount:104,mergeCoincidentVoices:true,measureAnnotations:{"1": "原谱力度文字：(forte)（补充显示，原位置未精确还原；试听不模拟力度变化）", "2": "原谱力度文字：piano（补充显示，原位置未精确还原；试听不模拟力度变化）", "3": "原谱力度文字：forte（补充显示，原位置未精确还原；试听不模拟力度变化）", "4": "原谱力度文字：piano（补充显示，原位置未精确还原；试听不模拟力度变化）", "5": "原谱力度文字：forte（补充显示，原位置未精确还原；试听不模拟力度变化）", "13": "原谱力度文字：(piano)（补充显示，原位置未精确还原；试听不模拟力度变化）", "14": "原谱力度文字：(forte)（补充显示，原位置未精确还原；试听不模拟力度变化）", "15": "原谱力度文字：piano（补充显示，原位置未精确还原；试听不模拟力度变化）", "16": "原谱力度文字：(forte)（补充显示，原位置未精确还原；试听不模拟力度变化）", "53": "原谱力度文字：(piano)（补充显示，原位置未精确还原；试听不模拟力度变化）", "54": "原谱力度文字：forte（补充显示，原位置未精确还原；试听不模拟力度变化）", "55": "原谱力度文字：(piano)（补充显示，原位置未精确还原；试听不模拟力度变化）", "56": "原谱力度文字：(forte)（补充显示，原位置未精确还原；试听不模拟力度变化）"},route:next.displayRoute,sourceLabels:Array.from({length:104},(_,i)=>String(i+1))});if(token!==request)return;
 next.fourStringStudy=true;next.compactStudy=true;score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite6prelude');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第六套 · Prelude（独立乐章；四弦高把位练习）';$('source').textContent='PDMX真实源1–104，104访问624拍；全部声部、音符及反复保留。';$('license').textContent='PDMX v9 索引记录 MuseScore 4601476 上传声明 CC0；非官方授权、非独立权属保证。';$('tempo').value=150;$('bpm').textContent='150';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第六套Prelude记谱节拍练习：谱面力度、括号及七处延长记号保留，音频暂不模拟自由延长、力度变化和完整弓法；可手动暂停。力度原文字同时作非原位补充显示，不解释括号为可省略。仅阅谱和按MusicXML编码音高电子试听；四弦高把位练习，已提供四弦音高落点与A/D弦拇指手型候选；候选来自规则模型，不是原谱或大师指定指法。多音落点不等于可同时按弦，揉弦比较保持禁用。谱面统一低音谱号，音高不变；切回其他已支持曲目恢复其有限模型。';$('trillScope').hidden=true;$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite6sarabande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite6sarabande/'+name);if(!r.ok)throw Error('第六套Sarabande加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptSarabande6(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=[];await renderer.load(bassClefView(xml),{measureCount:32,mergeCoincidentVoices:true,route:next.displayRoute,sourceLabels:Array.from({length:32},(_,i)=>String(i+201))});if(token!==request)return;
 next.fourStringStudy=true;score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite6sarabande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第六套 · Sarabande（独立乐章；四弦高把位练习）';$('source').textContent='PDMX真实源201–232，64访问384拍；全部声部、音符及反复保留。';$('license').textContent='PDMX v9 索引记录 MuseScore 4601476 上传声明 CC0；非官方授权、非独立权属保证。';$('tempo').value=80;$('bpm').textContent='80';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第六套Sarabande独立乐章，仅阅谱和按MusicXML编码音高电子试听；四弦高把位练习，已提供四弦音高落点与A/D弦拇指手型候选；候选来自规则模型，不是原谱或大师指定指法。多音落点不等于可同时按弦，揉弦比较保持禁用。谱面统一低音谱号，音高不变；切回其他已支持曲目恢复其有限模型。';$('trillScope').hidden=true;$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite4sarabande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite4sarabande/'+name);if(!r.ok)throw Error('Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptSarabande4(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:32,mergeCoincidentVoices:true,measureAnnotations:{19:'原谱上方标注：(    )（补充显示，原位置未精确还原，不解释为可省略）'},route:next.displayRoute,sourceLabels:Array.from({length:32},(_,i)=>String(i+200))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite4sarabande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第四套 · Sarabande（完整独立乐章，颤音练习建议）';$('source').textContent='PDMX真实源200–231，64访问192拍；全部原音、声部、延音、两处颤音和反复保留。';$('license').textContent='PDMX v9 / MuseScore4508871，上传者Public Domain Mark声明，非CC0，非独立版权核验。';$('tempo').value=56;$('bpm').textContent='56';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第四套Sarabande独立完整乐章。按原反复与延音演奏；源218括号保留并作原文补充显示，不声称精确还原原附着或可省略。有限指法不支持处保留原谱与声音。';$('trillScope').hidden=false;$('trillDetails').textContent='源211 B♭2/C3/B♭2/C3覆盖原3拍，每击3/4拍；源218 D4/E♭4/D4/E♭4覆盖原1.5拍，每击3/8拍。两处均是明确练习建议，不是原谱规定时值；关闭建议演绎即停播，不忽略装饰。';$('trillContext').textContent='建议子击期间游标停原颤音母音，音名表示建议演绎；全部声部、源延音和临时变音不删。速度按源四分音符56，电子声音不模拟真实弓法。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite4courante').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite4courante/'+name);if(!r.ok)throw Error('Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptCourante4(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:66,mergeCoincidentVoices:true,measureAnnotations:{36:'♭原注含义尚未独立判定；本练习按XML D自然音，不擅自降音'},route:next.displayRoute,sourceLabels:Array.from({length:66},(_,i)=>String(i+134))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite4courante');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第四套 · Courante（完整独立乐章，装饰练习建议）';$('source').textContent='PDMX真实源134–199，132访问384拍；全部原音、延音、三连音、颤音与反复保留。';$('license').textContent='PDMX v9 / MuseScore4508871，上传者Public Domain Mark声明，非CC0，非独立版权核验。';$('tempo').value=90;$('bpm').textContent='90';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='源169上方降号文字与编码D自然音并存；此练习按MusicXML D自然音播放，保留降号原注，附注含义尚未独立判定。不是已证实的版本异文结论。谱面连线保留，声音不模拟连弓，不推断运弓。';$('trillScope').hidden=false;$('trillDetails').textContent='源138 A♭2/B♭2、163 D3/E♭3、165 E♭3/F3各四等分；源191 D3延音1+1/3拍先合4/3拍，再D3/E♭3/D3/E♭3每击1/3拍，不重复发响延续音。均为明确练习建议，不是原谱规定时值；关闭即停播，不跳过装饰。';$('trillContext').textContent='三连音按MusicXML duration/divisions实际时值，不再次乘比例；建议子击游标停原母音。速度按源四分音符90，有限指法不支持处保留谱面与声音。源169不把上方文字自动套到编码音高。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite4prelude').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite4prelude/'+name);if(!r.ok)throw Error('Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptPrelude4(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:91,mergeCoincidentVoices:true,route:next.displayRoute,sourceLabels:Array.from({length:91},(_,i)=>String(i+1))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite4prelude');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第四套 · Prelude（完整独立乐章，记谱时值练习）';$('source').textContent='PDMX真实源1–91，91访问364拍，无反复；全部原音、延音、颤音与延长记号保留。';$('license').textContent='PDMX v9 / MuseScore4508871，上传者Public Domain Mark声明，非CC0，非独立版权核验。';$('tempo').value=88;$('bpm').textContent='88';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第四套Prelude采用记谱时值练习：源49延长记号保留，不模拟自由延长；可手动暂停。谱面连线保留，声音不模拟连弓，不推断运弓。有限指法不支持处保留谱面与声音。';$('trillScope').hidden=false;$('trillDetails').textContent='源61 F♯3/G3四等分；源90 D4延音合并为5/4拍后，采用D4/E♭4/D4/E♭4各5/16拍，不重复发响延续音。均为明确练习建议，不是原谱规定时值；关闭建议演绎即停播，不忽略颤音。';$('trillContext').textContent='源49 C♯2延长记号按名义1拍练习，想自由延长可手动暂停；不把记号删除或冒称已模拟。建议子击游标停原母音，全部声部保留，速度按源四分音符88。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite4allemande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite4allemande/'+name);if(!r.ok)throw Error('Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptAllemande4(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:42,mergeCoincidentVoices:true,route:next.displayRoute,sourceLabels:Array.from({length:42},(_,i)=>String(i+92))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite4allemande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第四套 · Allemande（完整独立乐章，颤音练习建议）';$('source').textContent='PDMX真实源92–133，84访问320拍；全部原音、声部、延音与反复保留。';$('license').textContent='PDMX v9 / MuseScore4508871，上传者Public Domain Mark声明，非CC0，非独立版权核验。';$('tempo').value=72;$('bpm').textContent='72';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第四套Allemande独立完整乐章。反复按原两段各两遍，原延音连续，有限指法不支持处保留原谱与声音，不猜手型。';$('trillScope').hidden=false;$('trillDetails').textContent='源94的B♭2半拍颤音，采用B♭2/C3/B♭2/C3四等分，每击1/8拍，两次反复相同；这是明确练习建议，不是原谱指定时值或专业演绎。关闭建议演绎即停播，不忽略颤音。';$('trillContext').textContent='建议子击期间游标停原颤音母音，音名表示建议演绎；降E调号及临时变音保留，速度按源四分音符72。持续复音无可靠指法时仅留网格，电子声音不模拟真实弓法。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite2sarabande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite2sarabande/'+name);if(!r.ok)throw Error('Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptSarabande2(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:28,mergeCoincidentVoices:true,measureAnnotations:{3:'原谱上方标注：(    )（补充显示，原位置未精确还原，不解释为可省略）',5:'原谱上方标注：(    )（补充显示，原位置未精确还原，不解释为可省略）'},route:next.displayRoute,sourceLabels:Array.from({length:28},(_,i)=>String(i+124))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite2sarabande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第二套 · Sarabande（完整独立乐章，装饰练习建议）';$('source').textContent='PDMX真实源124–151，56访问168拍；全部原音、8处颤音、1处波音及括号保留。';$('license').textContent='PDMX v9 / MuseScore4430776，上传者CC0声明，非独立版权核验。';$('tempo').value=60;$('bpm').textContent='60';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第二套Sarabande独立完整乐章。保留全部原谱符号；源126无竖线波音明确采用上邻练习建议，不从inverted英文名称猜方向。括号另作原文补充显示，不声称精确还原原位置或可省略。';$('trillScope').hidden=false;$('trillDetails').textContent='源126原F3的1/2拍采用F3/G3/F3各1/6拍，两次反复相同；其余8处颤音采用主/调内上邻/主/上邻四等分。均是明确练习建议，不是MusicXML默认比例或原谱规定；关闭建议演绎即停播，不忽略装饰。';$('trillContext').textContent='建议子击期间游标停原装饰母音；音名表示正在演奏的建议音，原谱音符和所有声部不删。速度按源四分音符60。持续复音无可靠指法时保留网格，电子声音不模拟真实弓法。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite3prelude').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite3prelude/'+name);if(!r.ok)throw Error('Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptPrelude3(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:88,mergeCoincidentVoices:true,measureAnnotations:{86:'原谱下方标注：(    )（原位置未精确还原，不解释为可省略）'},route:next.displayRoute,sourceLabels:Array.from({length:88},(_,i)=>String(i+1))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite3prelude');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第三套 · Prelude（完整独立乐章，双声部颤音练习）';$('source').textContent='PDMX真实源1–88，88访问264拍；全部原声部、延音与双颤音括号保留，无反复。';$('license').textContent='PDMX v9 / MuseScore4470891，上传者CC0声明，非独立版权核验。';$('tempo').value=72;$('bpm').textContent='72';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第三套Prelude独立完整乐章。源86两声部颤音与原括号均保留，采用明示双声部练习演绎，不删低声部、不声称原谱规定或专业演绎；有限指法不支持处保留声音与谱面，不猜手型。';$('trillScope').hidden=false;$('trillDetails').textContent='源86同时演奏B3/C4/B3/C4与D3/E3/D3/E3，各覆盖原3拍，四击等分每击3/4拍，两声部同步。这是练习建议，不是原谱指定时值；关闭建议演绎即停播，不忽略任何颤音。';$('trillContext').textContent='建议子击期间游标停原同拍的两个颤音母音，不把建议子击画成原谱新音。全部原延音保持连续，无新造反复；速度按源四分音符72。电子声音不模拟真实运弓，持续复音不推断不可靠指法。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite1allemande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/allemande1/'+name);if(!r.ok)throw Error('Allemande加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptAllemande1(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:34,identitySource:parsePinnedAllemande1(xml),route:next.displayRoute,sourceLabels:Array.from({length:34},(_,i)=>String(i+43))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite1allemande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第一套 · Allemande（完整独立乐章，装饰练习建议）';$('source').textContent='PDMX真实源43–76，68访问256拍；保留全部原音、装饰小音符、连线和反复。';$('license').textContent='PDMX v9 / MuseScore4395821，上传者CC0声明，非独立版权核验。';$('tempo').value=66;$('bpm').textContent='66';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第一套Allemande独立完整乐章。装饰小音符与主音按原谱音符身份分别标亮，不用同拍游标混指；原谱连线保留，仅显示，不推断运弓或模拟连奏。有限指法不支持处保谱保声。';$('trillScope').hidden=false;$('trillDetails').textContent='源63装饰小音符D3借用随后C3的1/2拍：D3演奏1/8拍，C3延后1/8拍演奏3/8拍，两次反复均采用此练习建议；不是原谱规定时值。其余8处颤音采用主/调内上邻/主/上邻四等分，F♯/E/F♯波音三等分；全部装饰保留，不跳过。关闭建议演绎即停播。';$('trillContext').textContent='建议子击指向各自原音符，装饰D3与主音C3即使原谱同起音也分别高亮直接音头；原延音连续播放，不把连线当延音。速度按源四分音符66。电子声音不模拟真实弓法；音名和指法不是专业演奏认证。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite3allemande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite3allemande/'+name);if(!r.ok)throw Error('Allemande加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptAllemande3(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:26,route:next.displayRoute,sourceLabels:Array.from({length:26},(_,i)=>String(i+89))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite3allemande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第三套 · Allemande（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源89–114，52访问192拍；原谱所有声部与连线保留，独立乐章结束。';$('license').textContent='PDMX v9 / MuseScore4470891，上传者CC0声明，非独立版权核验。';$('tempo').value=56;$('bpm').textContent='56';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第三套Allemande独立完整乐章。源107声部2到108声部1的连线保留显示；本曲不推断运弓，声音未模拟连弓或连奏，不把连线当延音合并。有限指法未经教师审核。';$('trillScope').hidden=false;$('trillDetails').textContent='源91、94颤音A2/B2，源108颤音A3/B♭3，采用主/上邻/主/上邻四等分练习建议，非原谱指定时值或专业演绎。关闭建议演绎即停播，不略过颤音。';$('trillContext').textContent='建议子击期间谱面停原颤音音符；持续复音无可靠指法时保留谱面与声音而不猜指法。速度按源四分音符56。所有原谱连线保持显示，仅不推断运弓或模拟连奏。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite3bourree2').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite3bourree2/'+name);if(!r.ok)throw Error('Bourrée II加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptBourree32(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:26,route:next.displayRoute,sourceLabels:Array.from({length:26},(_,i)=>String(i+255))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite3bourree2');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第三套 · Bourrée II（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源255–280，52访问；跨小节延音274–275保留；D.S.保留但独立结束不执行，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4470891，上传者CC0声明，非独立版权核验。';$('tempo').value=136;$('bpm').textContent='136';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第三套Bourrée II独立完整乐章，52访问；采用已开启的练习颤音设置（可在后置设置关闭）。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第三套Bourrée II源263颤音E♭3/F3以主/上邻/主/上邻四等分，覆盖MusicXML默认3击/whole/12%/24%，不是原谱指定时值或专业演绎。关闭即停播禁播，不略过颤音。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；本曲持续复音较多，无可靠指法处只保留网格，全部声部不删；速度按源四分音符136（半音符68）计；B♭/E♭两个降号及临时记号保留，不重复叠加调号。';$('verifiedText').textContent+=' '+JSON.parse(raw).notationVariantPolicy.note;$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite3courante').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const fetchText=async name=>{const r=await fetch('data/suite3courante/'+name);if(!r.ok)throw Error('内置曲谱加载失败');return r.text();};
 const [xml,raw]=await Promise.all([fetchText('display.musicxml'),fetchText('practice-plan.json')]);
 const next=await adaptCourante3(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:86,route:next.displayRoute,sourceLabels:Array.from({length:86},(_,i)=>String(i+115))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite3courante');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第三套 · Courante（独立完整乐章）';$('source').textContent='PDMX真实源115–200；172次小节访问 · 非整套导航 · 非同源MIDI验收';
 $('license').textContent='PDMX v9 / MuseScore4470891，归档上传者CC0声明，非独立版权核验。原XML与出处见下方。';$('tempo').value=108;$('bpm').textContent='108';$('error').hidden=true;$('verifiedScope').hidden=false;$('trillScope').hidden=true;$('verifiedText').textContent='第三套Courante独立完整乐章，源115–200，172次访问504拍；无装饰替代。练习速度固定108 BPM，包括源115弱起；原谱首次本地108在源116，此处不是执行源速度变化图。反复按源两段各两遍，独立结束；有限指法未经教师审核。';$('bowPractice').disabled=false;$('bowPractice').checked=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite3bourree1').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const fetchText=async name=>{const r=await fetch('data/suite3bourree1/'+name);if(!r.ok)throw Error('内置曲谱加载失败');return r.text();};
 const [xml,raw]=await Promise.all([fetchText('display.musicxml'),fetchText('practice-plan.json')]);
 const next=await adaptBourree3(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:30,route:next.displayRoute,sourceLabels:Array.from({length:30},(_,i)=>String(i+225))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite3bourree1');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第三套 · Bourrée I（独立完整乐章）';$('source').textContent='PDMX真实源225–254；60次小节访问 · 非整套导航 · 非同源MIDI验收';
 $('license').textContent='PDMX v9 / MuseScore4470891，归档上传者CC0声明，非独立版权核验。原XML与出处见下方。';$('tempo').value=180;$('bpm').textContent='180';$('error').hidden=true;$('verifiedScope').hidden=false;$('trillScope').hidden=true;$('verifiedText').textContent='第三套Bourrée I独立完整乐章，60访问；无装饰替代；源Segno/To Coda保留但不执行，独立结尾停止，不连接Bourrée II。不是完整组曲，有限指法未经教师审核。';$('bowPractice').disabled=false;$('bowPractice').checked=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite2courante').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const fetchText=async name=>{const r=await fetch('data/suite2courante/'+name);if(!r.ok)throw Error('内置曲谱加载失败');return r.text();};
 const [xml,raw]=await Promise.all([fetchText('display.musicxml'),fetchText('practice-plan.json')]);
 const next=await adaptCourante(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:34,route:next.displayRoute,sourceLabels:Array.from({length:34},(_,i)=>String(i+90))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite2courante');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第二套 · Courante（独立完整乐章）';$('source').textContent='PDMX真实源90–123；68次小节访问 · 非整套导航 · 非同源MIDI验收';
 $('license').textContent='PDMX v9 / MuseScore4430776，归档上传者CC0声明，非独立版权核验。原XML与出处见下方。';$('tempo').value=90;$('bpm').textContent='90';$('error').hidden=true;$('verifiedScope').hidden=false;$('trillScope').hidden=true;$('verifiedText').textContent='第二套Courante独立完整乐章，68访问；无装饰替代。不是完整组曲，有限指法未经教师审核。';$('bowPractice').disabled=false;$('bowPractice').checked=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite1gigue').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite1gigue/'+name);if(!r.ok)throw Error('Gigue加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptGigue(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:36,route:next.displayRoute,sourceLabels:Array.from({length:36},(_,i)=>String(i+185))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite1gigue');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第一套 · Gigue（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源185–220，72访问；入站coda保留，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4395821，上传者CC0声明，非独立版权核验。';$('tempo').value=144;$('bpm').textContent='144';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第一套Gigue独立完整乐章，72访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第一套Gigue源189颤音B3/C4/B3/C4四等分，覆盖MusicXML默认3击/whole/12%/24%，不是原谱指定时值或专业演绎。关闭即停播禁播，不略过颤音。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；源189持续G2/D3，指板只留网格，不猜持续复音指法。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite2menuet2').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite2menuet2/'+name);if(!r.ok)throw Error('Menuet II加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptMenuet22(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:24,route:next.displayRoute,sourceLabels:Array.from({length:24},(_,i)=>String(i+176))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite2menuet2');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第二套 · Menuet II（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源176–199，48访问；Dal Segno保留但不执行跨曲跳转，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4430776，上传者CC0声明，非独立版权核验。';$('tempo').value=120;$('bpm').textContent='120';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第二套Menuet II独立完整乐章，48访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第二套Menuet II源176/183/196颤音F♯3/G3、E3/F♯3、C♯3/D3以主/上邻/主/上邻四等分，覆盖MusicXML默认3击/whole/12%/24%，不是原谱指定时值或专业演绎。关闭即停播禁播，不略过颤音。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；独立练习结尾停止，不执行Dal Segno、不返回Menuet I，无可靠指法处只保留网格，全部声部不删；速度沿用原源152的四分音符120（本乐章无单独速度标记）；两个升号的调号与临时记号保留，不重复叠加调号。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite2menuet1').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite2menuet1/'+name);if(!r.ok)throw Error('Menuet I加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptMenuet21(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:24,route:next.displayRoute,sourceLabels:Array.from({length:24},(_,i)=>String(i+152))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite2menuet1');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第二套 · Menuet I（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源152–175，48访问；Segno及To Coda保留但不执行跨曲跳转，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4430776，上传者CC0声明，非独立版权核验。';$('tempo').value=120;$('bpm').textContent='120';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第二套Menuet I独立完整乐章，48访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第二套Menuet I源168/169/174颤音A3/B♭3、F♯3/G3、E3/F3以主/上邻/主/上邻四等分，覆盖MusicXML默认3击/whole/12%/24%，不是原谱指定时值或专业演绎。关闭即停播禁播，不略过颤音。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；独立练习结尾停止，不执行To Coda、不连接Menuet II，无可靠指法处只保留网格，全部声部不删；速度按源四分音符120计；B♭与临时记号保留，不重复叠加调号。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite2allemande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite2allemande/'+name);if(!r.ok)throw Error('Allemande加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptAllemande2(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:26,route:next.displayRoute,sourceLabels:Array.from({length:26},(_,i)=>String(i+64))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite2allemande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第二套 · Allemande（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源64–89，52访问；反复和延音保留，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4430776，上传者CC0声明，非独立版权核验。';$('tempo').value=66;$('bpm').textContent='66';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第二套Allemande独立完整乐章，52访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第二套Allemande源72/78/82/84颤音G♯3/A3、A2/B♭2、F♯3/G3、E3/F3以主/上邻/主/上邻四等分，覆盖MusicXML默认3击/whole/12%/24%，不是原谱指定时值或专业演绎。关闭即停播禁播，不略过颤音。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；本曲持续复音较多，无可靠指法处只保留网格，全部声部不删；速度按源四分音符66计；B♭与临时记号保留，不重复叠加调号。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite2gigue').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite2gigue/'+name);if(!r.ok)throw Error('Gigue加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptGigue2(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:78,route:next.displayRoute,sourceLabels:Array.from({length:78},(_,i)=>String(i+200))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite2gigue');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第二套 · Gigue（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源200–277，156访问；入站coda保留，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4430776，上传者CC0声明，非独立版权核验。';$('tempo').value=99;$('bpm').textContent='99';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第二套Gigue独立完整乐章，156访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第二套Gigue源208颤音F3/G3/F3/G3四等分，覆盖MusicXML默认3击/whole/12%/24%，不是原谱指定时值或专业演绎。关闭即停播禁播，不略过颤音。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；本曲持续复音较多，无可靠指法处只保留网格，全部声部不删；速度按四分音符99（原附点四分音符66）计。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite1courante').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite1courante/'+name);if(!r.ok)throw Error('Courante加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptCourante1(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:44,route:next.displayRoute,sourceLabels:Array.from({length:44},(_,i)=>String(i+77))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite1courante');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第一套 · Courante（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源77–120，88访问；反复与延音保留，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4395821，上传者CC0声明，非独立版权核验。';$('tempo').value=80;$('bpm').textContent='80';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第一套Courante独立完整乐章，88访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第一套Courante源87/93/116颤音：C♯4/D4、F♯3/G3、B3/C4各以主/上邻/主/上邻四等分。覆盖MusicXML默认3击/whole/12%/24%，不是源谱指定或专业演绎；关闭即停播禁播。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；指板仅显示可验证有限候选，持续复音不猜指法。原104延音保持连续，不重复起音。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite3gigue').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite3gigue/'+name);if(!r.ok)throw Error('Gigue加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptGigue3(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:110,route:next.displayRoute,sourceLabels:Array.from({length:110},(_,i)=>String(i+281))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite3gigue');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第三套 · Gigue（完整独立乐章，断奏/颤音建议可选）';$('source').textContent='PDMX真实源281–390，220访问；反复保留，无跨曲跳转，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4470891，上传者CC0声明，非独立版权核验。';$('tempo').value=105;$('bpm').textContent='105';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第三套Gigue独立完整乐章，220访问；必须另外主动选择明示断奏与颤音建议。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第三套Gigue源338颤音：E3/F3以主/上邻/主/上邻四等分；另将315/319/376/380各前三个带断奏点音的发声缩为原记谱时值50%，起音、小节、其余声部不变。覆盖MusicXML默认3击/whole/12%/24%，不是源谱指定或专业演绎；关闭即停播禁播。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；本曲持续复音较多；指板无可靠共框时仅留网格，不猜手位，声音和原谱不删。本曲无源延音；断奏只缩被标音，不截断其他声部；空隙状态游标隐藏。速度按源四分音符105（附点四分音符70）计。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite3sarabande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite3sarabande/'+name);if(!r.ok)throw Error('Sarabande加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptSarabande3(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:24,route:next.displayRoute,sourceLabels:Array.from({length:24},(_,i)=>String(i+201))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite3sarabande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第三套 · Sarabande（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源201–224，48访问；反复保留，无跨曲跳转，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4470891，上传者CC0声明，非独立版权核验。';$('tempo').value=42;$('bpm').textContent='42';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第三套Sarabande独立完整乐章，48访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第三套Sarabande源212颤音：D3/E3各以主/上邻/主/上邻四等分。覆盖MusicXML默认3击/whole/12%/24%，不是源谱指定或专业演绎；关闭即停播禁播。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；本曲持续复音较多；指板无可靠共框时仅留网格，不猜手位，声音和原谱不删。本曲无源延音；速度按源四分音符42计。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite1sarabande').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite1sarabande/'+name);if(!r.ok)throw Error('Sarabande加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptSarabande(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:16,route:next.displayRoute,sourceLabels:Array.from({length:16},(_,i)=>String(i+121))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite1sarabande');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第一套 · Sarabande（完整独立乐章，建议颤音可选）';$('source').textContent='PDMX真实源121–136，32访问；反复与延音保留，非整套跳转。建议颤音非原谱指定。';$('license').textContent='PDMX v9 / MuseScore4395821，上传者CC0声明，非独立版权核验。';$('tempo').value=44;$('bpm').textContent='44';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第一套Sarabande独立完整乐章，32访问；必须另外主动选择建议颤音。不是完整组曲；指法仅有限模型，未验浏览器/听觉。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择第一套Sarabande源122/124/126/130/131颤音：B3/C4、F♯3/G3、C♯3/D3、D♯3/E3、B3/C4各以主/上邻/主/上邻四等分。覆盖MusicXML默认3击/whole/12%/24%，不是源谱指定或专业演绎；关闭即停播禁播。';$('trillContext').textContent='建议子击期间谱面停原颤音音符，音名标建议演绎；本曲持续复音较多；指板无可靠共框时仅留网格，不猜手位，声音和原谱不删。原135延音保持连续，不重复起音。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite2prelude').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite2prelude/'+name);if(!r.ok)throw Error('PDMX Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptPrelude2(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:63,route:next.displayRoute,sourceLabels:Array.from({length:63},(_,i)=>String(i+1))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite2prelude');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='第二套Prelude · PDMX谱本（完整独立乐章，延长建议可选）';$('source').textContent='PDMX源1–63，无反复；原189拍，建议延长后190基准拍。与原前奏曲按钮为不同来源入口。';$('license').textContent='PDMX v9 / MuseScore4430776，上传者CC0声明，非独立版权核验；不是既有CC BY-SA改编谱入口。';$('tempo').value=54;$('bpm').textContent='54';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='PDMX第二套Prelude完整独立乐章。原谱不指定2倍延长，此处只是主动选择的练习建议；不是专业演绎。有限指法不支持时保谱/保声，不画假点。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择源48 C♯4延长记号对应区间由1拍变2拍，同起G2/E3也随全局区间一起延长，后续音符同步顺移；其余源延音保持连续。不是标准默认或原谱指定时长。关闭即停止并禁播，不忽略记号。';$('trillContext').textContent='原189拍记谱保持不变；建议时序190拍。谱面游标按原始起音定位，音名标“建议延长”；复音无可靠指法时只留网格。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite1prelude').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite1prelude/'+name);if(!r.ok)throw Error('PDMX Prelude加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptPrelude(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:42,route:next.displayRoute,sourceLabels:Array.from({length:42},(_,i)=>String(i+1))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite1prelude');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='第一套Prelude · PDMX谱本（完整独立乐章，延长建议可选）';$('source').textContent='PDMX源1–42，无反复；原168拍，建议延长后172.5基准拍。与原前奏曲按钮为不同来源入口。';$('license').textContent='PDMX v9 / MuseScore4395821，上传者CC0声明，非独立版权核验；不是既有同源MIDI核验版本。';$('tempo').value=80;$('bpm').textContent='80';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='PDMX第一套Prelude完整独立乐章。原谱不指定2倍延长，此处只是主动选择的练习建议；不是专业演绎。有限指法不支持时保谱/保声，不画假点。';$('trillScope').hidden=false;$('trillDetails').textContent='主动选择源22 D4和42末和弦延长记号对应区间2倍时值；后续音符同步顺移，22延音仍连续，42三和弦音一起延长。不是标准默认或原谱指定时长。关闭即停止并禁播，不忽略记号。';$('trillContext').textContent='原168拍记谱保持不变；建议时序172.5拍。谱面游标按原始起音定位，音名标“建议延长”；复音无可靠指法时只留网格。';$('bowPractice').checked=false;$('bowPractice').disabled=true;render();
 }catch(e){if(token===request)fail(e);}
};
$('trillChoice').onchange=()=>{stop();if(score)render();};
$('suite1menuet1').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite1menuet1/'+name);if(!r.ok)throw Error('Menuet I加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptMenuet(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:24,route:next.displayRoute,sourceLabels:Array.from({length:24},(_,i)=>String(i+137))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite1menuet1');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第一套 · Menuet I（独立完整乐章）';$('source').textContent='PDMX源137–160全部24节点，48次访问；To Coda保留但在独立练习边界不执行，非双舞曲/组曲演奏。';$('license').textContent='PDMX v9 / MuseScore4395821，归档上传者CC0声明，非独立版权核验。';$('tempo').value=98;$('bpm').textContent='98';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第一套Menuet I独立完整乐章，48访问144拍；原To Coda不在本独立练习执行，不进入Menuet II或Gigue。多声部保留，持续复音无可靠指法即不画候选；不是完整组曲。';$('trillScope').hidden=true;$('bowPractice').checked=false;$('bowPractice').disabled=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('suite1menuet2').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{const get=async name=>{const r=await fetch('data/suite1menuet2/'+name);if(!r.ok)throw Error('Menuet II加载失败');return r.text();};const [xml,raw]=await Promise.all([get('display.musicxml'),get('practice-plan.json')]);const next=await adaptMenuet2(xml,raw);if(token!==request)return;
 const notes=buildTimeline(next),path=solve(notes);await renderer.load(xml,{measureCount:24,route:next.displayRoute,sourceLabels:Array.from({length:24},(_,i)=>String(i+161))});if(token!==request)return;
 score=next;state={notes,path,index:0,locks:{}};sourceVibrato='uncertain';shown=-1;selectPiece('suite1menuet2');if(url)URL.revokeObjectURL(url);url=null;
 $('title').textContent='巴赫第一套 · Menuet II（独立完整乐章）';$('source').textContent='PDMX源161–184全部24节点，48次访问；D.C.保留但在独立练习边界不执行，非双舞曲/组曲演奏。';$('license').textContent='PDMX v9 / MuseScore4395821，归档上传者CC0声明，非独立版权核验。';$('tempo').value=90;$('bpm').textContent='90';$('error').hidden=true;$('verifiedScope').hidden=false;$('verifiedText').textContent='第一套Menuet II独立完整乐章，48访问144拍；原D.C.不在本独立练习执行，不返回Menuet I或进入Gigue。全部原音保留；超出有限指法范围即不画候选；不是完整组曲。';$('trillScope').hidden=true;$('bowPractice').checked=false;$('bowPractice').disabled=false;render();
 }catch(e){if(token===request)fail(e);}
};
$('verifiedAck').onchange=()=>{stop();if(score)render();};

$('piatti1').onclick=async()=>{
 const token=++request;renderer.cancelPending();stop();
 try{
  const r=await fetch('data/piatti/no1.musicxml');
  if(!r.ok)throw Error('皮亚蒂练习谱加载失败');
  const xml=await r.text();if(token!==request)return;
  $('tempo').value='72';syncTempoControls();
  await load(xml,'N. Simrock 初版版号 7496，第 2–3 页，Sibley Music Library 公版收藏。第 17 小节第 5 音按初版疑似升号 E♯3 暂读；是起音练习版，不是原版重刻。',false,'皮亚蒂 · 第 1 首 · 逐音练习','piatti1',{piatti:true});
 }catch(e){if(token===request)fail(e);}
};
$('file').onchange=async e=>{const token=++request,f=e.target.files[0];renderer.cancelPending();stop();if(!f)return;try{if(f.size>4000000)throw Error('文件超过4 MB，请分段导入。');const xml=await f.text();if(token===request)await load(xml,'本机导入，不上传；谱面标注来源由文件提供，未教师审核。');}catch(err){if(token===request)fail(err);}};
$('seek').oninput=()=>{stop();state.index=Number($('seek').value);render();};
$('prev').onclick=()=>{stop();state.index=Math.max(0,state.index-1);render();};$('next').onclick=()=>{stop();state.index=Math.min(state.notes.length-1,state.index+1);render();};
$('reset').onclick=()=>{if(score?.fingeringEnabled===false)return;delete state.locks[state.index];state.path=solve(state.notes,state.locks);render();};
// iPhone range input/change and explicit controls use the same stopped, beat-preserving path.
function changeTempo(raw){
 const min=Number($('tempo').min)||30,max=Number($('tempo').max)||180,bpm=Number(raw);
 if(!Number.isFinite(bpm)||bpm<min||bpm>max||!Number.isInteger(bpm)){$('tempo').value=String(acceptedTempo);syncTempoControls();$('audioStatus').textContent=`请输入 ${min}–${max} 之间的整数 BPM；速度未改变。`;return;}
 let beat=resumeBeat??state.notes[state.index]?.time??0;
 if(plan&&Number.isFinite(player.currentTime))beat=plan.startBeat+Math.max(0,Math.min(player.currentTime,plan.duration))*plan.bpm/60;
 if(score&&beat>=score.totalBeats-1e-8)beat=state.notes[state.index]?.time??0;
 stop();$('tempo').value=String(bpm);syncTempoControls();
 if(score){resumeBeat=beat;let i=state.notes.findIndex(n=>n.time>beat+1e-8);state.index=i<0?state.notes.length-1:Math.max(0,i-1);render();}
 $('audioStatus').textContent=`速度已设为 ${bpm} BPM，试听已停止；点播放将按新速度从当前位置继续，音高不变。`;
}
$('tempo').oninput=()=>changeTempo($('tempo').value);
$('tempo').onchange=()=>changeTempo($('tempo').value);
if($('tempoNumber'))$('tempoNumber').onchange=()=>changeTempo($('tempoNumber').value);
if($('tempoDown'))$('tempoDown').onclick=()=>changeTempo(Math.max(Number($('tempo').min)||30,Number($('tempo').value)-5));
if($('tempoUp'))$('tempoUp').onclick=()=>changeTempo(Math.min(Number($('tempo').max)||180,Number($('tempo').value)+5));
$('play').onclick=async()=>{if(!score){$('audioStatus').textContent='曲谱尚未加载完成，请等待曲目名称和音符出现后再点播放。';return;}if(!lifecycle.canPlay()){$('audioStatus').textContent='页面不在前台，未启动试听；返回本页后请重新点播放。';return;}if(score.verifiedPractice){const missing=!$('verifiedAck').checked?'verifiedAck':((score.suggestedTrill||score.suggestedFermata)&&!$('trillChoice').checked?'trillChoice':null);if(missing){$('audioStatus').textContent=missing==='verifiedAck'?'练习试听已在设置中关闭；重新启用后可播放。':'建议演绎已在设置中关闭；此乐章尚无不含该演绎的试听模式，重新启用后可播放。';const box=$(missing);for(let parent=box.parentElement;parent;parent=parent.parentElement)if(parent.tagName==='DETAILS')parent.open=true;box.focus({preventScroll:true});box.scrollIntoView?.({block:'center',behavior:'smooth'});return;}}if(playbackIntent||!player.paused){stop();return;}const nextBeat=resumeBeat??state.notes[state.index].time;stop();playbackIntent=true;await startSegment(nextBeat,false);};
async function startSegment(startBeat,automatic){
 const token=++audioRequest, selected=score, selection=request;
 const valid=()=>token===audioRequest&&selected===score&&selection===request&&playbackIntent&&lifecycle.canPlay();
 segmentBusy=true;
 try{
  if(!valid())return;
  plan=slicePlan(selected,startBeat,Number($('tempo').value));
  const bytes=makePolyWav(plan);
  if(!valid())return;
  if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(new Blob([bytes],{type:'audio/wav'}));player.src=url;
  resumeBeat=null;$('play').textContent='停止';$('audioStatus').textContent=automatic?'正在接续下一段；分段生成可能有短暂停顿。':'启动电子试听；前台自然段尾将尝试自动接续，停止或切后台即取消。';
  if(!lifecycle.arm()){stop();return;}
  await player.play();
  if(!valid()||!lifecycle.isAllowed())return;
 }catch(e){
  if(!valid())return;
  stop();resumeBeat=startBeat;
  $('play').textContent='▶ 手动继续';
  $('audioStatus').textContent=(automatic?'自动接续未成功':'启动未成功')+' ['+(e.name||'Error')+']；已停止自动尝试，请点手动继续从断点播放。未确认设备有声。';
 }finally{if(token===audioRequest)segmentBusy=false;}
}

player.onplaying=()=>{if(!plan||player.paused||player.ended)return;$('audioStatus').textContent='播放器报告正在播放 · 尚未确认设备有声 · 电子合成，非真实大提琴';$('play').textContent='停止';};
player.onended=async()=>{
 if(segmentBusy||!playbackIntent||!lifecycle.isAllowed()||!plan||!player.ended||Math.abs(player.currentTime-plan.duration)>.25)return;
 const end=plan.startBeat+plan.duration*plan.bpm/60;
 if(end<score.totalBeats-1e-6){resumeBeat=end;await startSegment(end,true);}
 else{stop();state.index=state.notes.length-1;render();$('play').textContent='▶ 重播当前音';$('audioStatus').textContent='已到曲谱结尾；不会自动循环。';}
};
player.onerror=()=>{if(!plan)return;audioFailure('播放器失败 [媒体代码 '+(player.error?.code??'未知')+']，已停止');};
player.ontimeupdate=()=>{if(!plan||player.paused||player.ended)return;const beat=plan.startBeat+player.currentTime*plan.bpm/60;let i=state.notes.findIndex(n=>n.time>beat+1e-6);i=i<0?state.notes.length-1:Math.max(0,i-1);if(i!==state.index){state.index=i;render();}};
$('stop').onclick=()=>{stop();player.currentTime=0;};$('stop').disabled=false;
$('bowPractice').onchange=render;$('demo').hidden=true;
$('suite1prelude').click();
let resizeTimer;
globalThis.addEventListener?.('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(!score)return;try{renderer.resize();shown=-1;render();}catch(e){fail(Error('窗口变化后谱面重排失败：'+e.message));}},150);});

// Enter the separate silent reader only after stopping current practice, including modifier/auxiliary openings.
for(const eventName of ['pointerdown','click','auxclick','contextmenu'])$('suite5Reader').addEventListener(eventName,()=>stop());

for(const name of ['Prelude','Allemande','Courante','Sarabande','GavotteI','GavotteII','Gique']){
 $('suite5'+name).onclick=async()=>{
  const token=++request;renderer.cancelPending();stop();
  try{
   const get=async ext=>{const r=await fetch('data/suite5/'+name+ext);if(!r.ok)throw Error('第五组曲加载失败');return r.text();};
   const [xml,raw]=await Promise.all([get('.musicxml'),get('.json')]);const next=await adaptSuite5(xml,raw);if(token!==request)return;
   const notes=buildTimeline(next),path=solve(notes);
   const writtenIdentity=parsePinnedAllemande1(xml);
   await renderer.load(xml,{measureCount:next.writtenMeasureCount,identitySource:writtenIdentity,sourceLabels:writtenIdentity.measures.map(m=>String(m.number)),mergeCoincidentVoices:true,route:next.displayRoute});if(token!==request)return;
   score=next;state={notes,path,index:0,locks:{}};sourceVibrato='unmarked';shown=-1;selectPiece('suite5'+name);if(url)URL.revokeObjectURL(url);url=null;
   $('title').textContent='巴赫第五组曲 · '+name+'（标准定弦改编）';
   $('source').textContent='DCMLab 真实标准定弦语料转录 · 全部音高、时值、声部；不是原始降弦记谱';
   $('license').textContent='DCMLab bach_solo / Hentschel、Rammos、Neuwirth、Rohrmeier (2025) · CC BY-NC-SA 4.0；此转制谱同许可，限非商业；来源及可编辑文件见下方链接。';
   $('tempo').value=72;$('bpm').textContent='72';$('error').hidden=true;$('verifiedScope').hidden=false;$('trillScope').hidden=true;
   $('verifiedText').textContent='标准四弦 C/G/D/A 练习版。逐项对照源语料音高、时值、声部与延音，按语料编码展开反复；速度72为练习默认值。简化转录未保留原版装饰、连弓和排版；Allemande 1处、Courante 2处倚音采用从后主音借1/4拍的建议，不是原谱规定时值。Gavotte I/II 尚不自动跨曲返回；指法是算法候选，未经教师审核。';
   $('bowPractice').checked=false;$('bowPractice').disabled=false;render();
  }catch(e){if(token===request)fail(e);}
 };
}
