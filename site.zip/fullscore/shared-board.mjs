// Presentation-only normalization; does not select fingerings, pitches or alter an audio controller.
export const VIEW=Object.freeze({width:378,height:105,left:61,right:345,firstRow:29,rowGap:18});
export const STANDARD=Object.freeze([{name:'A',open:57},{name:'D',open:50},{name:'G',open:43},{name:'C',open:36}].map(Object.freeze));
export const MARKS=Object.freeze([0,2,5,7,9,12,17,19,24,29]);
export const pointX=n=>61+329*(1-2**(-n/12));
export function boardModel({stops=[],tuning=STANDARD,rest=false,special=false,unverifiedTogether=false,showScale=true}={}){
 if(tuning.length!==4||tuning.some((r,i)=>r.name!==STANDARD[i].name||!Number.isInteger(r.open)))throw Error('Four string identities A/D/G/C required');
 if(rest&&special)throw Error('Ambiguous board mode');
 const rows=tuning.map((s,i)=>({...s,y:VIEW.firstRow+VIEW.rowGap*i}));
 const marks=MARKS.map(n=>({offset:n,x:pointX(n),label:showScale?(n===0?'0':'+'+n):null}));
 const points=rest||special?[]:stops.map(s=>{
   const row=rows.find(r=>r.name===s.name);
   if(!row||!Number.isInteger(s.pitch)||s.pitch-row.open!==s.offset||s.offset<0||s.offset>31)throw Error('Inconsistent pitch/stop/tuning');
   if(s.finger===0&&s.offset!==0)throw Error('0 refers only to open string; thumb requires explicit evidence');
   if(s.offset===0&&s.finger!=null&&s.finger!==0)throw Error('Open string is not fingered');
   const finger=s.offset===0?'空弦（不按指）':s.finger==='拇'?'拇指':[1,2,3,4].includes(s.finger)?s.finger+' 指':'未指定';
   const pos=s.offset===0?'不适用':s.position||'未指定';
   const marker=s.offset===0?'空':s.finger==='拇'?'拇':[1,2,3,4].includes(s.finger)?String(s.finger):'';
   return {...s,x:pointX(s.offset),y:row.y,marker,finger,pos,detail:`${s.name} 弦 · 指法：${finger} · 把位：${pos}`};
 });
 return {rows,marks,points,scaleText:showScale?'距空弦（半音）':null,
   status:rest?'休止 · 不按弦':special?'特殊奏法 · 不推测实响落点':!points.length?'当前音未标已核落点':
   unverifiedTogether?'分别显示当前各音，不代表已核同时按法':points.map(x=>x.detail).join('；')};
}
export function drawTrialBoard(svg,details,config,documentObject=globalThis.document){
 const model=boardModel(config), ns='http://www.w3.org/2000/svg';
 function shape(tag,attrs,text){const el=documentObject.createElementNS(ns,tag);
  for(const [k,v] of Object.entries(attrs))el.setAttribute(k,v);
  if(text!=null)el.textContent=text; svg.append(el);}
 svg.replaceChildren();svg.setAttribute('viewBox',`0 0 ${VIEW.width} ${VIEW.height}`);
 svg.setAttribute('role','img');svg.setAttribute('aria-label','四弦指板；刻度是离空弦的半音，不是指法或把位');
 if(model.scaleText)shape('text',{x:5,y:11,'font-size':10,fill:'#365b47'},model.scaleText);
 for(const mark of model.marks){
   shape('line',{x1:mark.x,x2:mark.x,y1:21,y2:91,stroke:'#bdc9c0','stroke-dasharray':'2 3','data-offset':mark.offset});
   if(mark.label)shape('text',{x:mark.x,y:20,'text-anchor':'middle','font-size':9,fill:'#365b47'},mark.label);
 }
 for(const row of model.rows){
   shape('line',{x1:VIEW.left,x2:VIEW.right,y1:row.y,y2:row.y,stroke:'#708d78','data-string-row':row.name});
   shape('text',{x:8,y:row.y+4,'font-size':12,fill:'#234a38'},row.name+' 弦');
 }
 for(const p of model.points){
   shape('circle',{cx:p.x,cy:p.y,r:7,fill:'#285b46','data-current-pitch':p.pitch,'data-string':p.name});
   if(p.marker)shape('text',{x:p.x,y:p.y+3,'font-size':9,'text-anchor':'middle',fill:'white','data-finger-marker':true},p.marker);
 }
 details.textContent=model.status;
 return model;
}
