import {buildIdentityMap,selectMotherNoteheads} from './grace-identity.mjs';
/* Integration seam: host must vendor a pinned, license-preserved OSMD build.
 * Uses official load/render/setOptions API. No network or dynamic dependencies. */
export function createScoreRenderer({container,OpenSheetMusicDisplay,documentObject=globalThis.document}){
 if(!container||!OpenSheetMusicDisplay||!documentObject)throw Error('Renderer dependency/container unavailable');
 let generation=0,current=null,total=0,lastCursor=null,windowFrom=null,windowTo=null,identityWritten=null;
 // OSMD 2.3.0 measure-number options shift ranges when the first measure is implicit.
 // Application windows are source ordinals: use explicit index rules, not printed numbers.
 const setWindow=(renderer,from,to)=>{const rules=renderer.EngravingRules;rules.MinMeasureToDrawNumber=0;rules.MaxMeasureToDrawNumber=Number.MAX_VALUE;rules.MinMeasureToDrawIndex=from-1;rules.MaxMeasureToDrawIndex=to-1;};
 const destroy=x=>{if(x?.dispose)x.dispose();else x?.clear?.();};
 return {
  async load(xml,{measureCount,identitySource=null}={}){
   if(typeof xml!=='string'||!/^\s*(?:<\?xml[\s\S]*?\?>\s*)?</.test(xml)||/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('Provide validated MusicXML text, not a URL');
   if(!Number.isInteger(measureCount)||measureCount<1)throw Error('measureCount required');
   const request=++generation,host=documentObject.createElement('div');
   const renderer=new OpenSheetMusicDisplay(host,{backend:'svg',drawingParameters:'compacttight',followCursor:false,pageFormat:'Endless',autoResize:false,drawTitle:false,drawComposer:false,drawCredits:false,drawSubtitle:false,drawSlurs:true,drawTimeSignatures:true,drawMeasureNumbers:true,autoBeam:true,newSystemFromXML:false,newPageFromXML:false});
   // OSMD ignores MusicXML lyric font-size; size note-name annotations explicitly.
   renderer.EngravingRules.LyricsHeight=0.9;
   try{await renderer.load(xml);if(request!==generation){destroy(renderer);return {stale:true};}
    // Attach before layout: OSMD needs the actual available width.
    const previousNodes=Array.from(container.childNodes);container.replaceChildren(host);try{setWindow(renderer,1,1);renderer.render();}catch(error){container.replaceChildren(...previousNodes);throw error;}destroy(current);current=renderer;total=measureCount;windowFrom=windowTo=1;lastCursor=null;identityWritten=identitySource;
    return {stale:false,measureCount,renderedOrdinal:1};
   }catch(error){destroy(renderer);throw error;}
  },
  showMeasure(ordinal){this.showWindow(ordinal,ordinal);return {ordinal};},
  showWindow(from,to=from){if(!current)throw Error('Score not loaded');if(!Number.isInteger(from)||!Number.isInteger(to)||from<1||to<from||to>total||to-from>1)throw Error('Choose a valid one- or two-measure window');if(windowFrom!==from||windowTo!==to){setWindow(current,from,to);current.render();windowFrom=from;windowTo=to;lastCursor=null;}return {from,to};},
  seekQuarter(onset){if(!current?.cursor)throw Error('Cursor unavailable');if(!Number.isFinite(onset)||onset<0)throw Error('Invalid quarter-note onset');const cursor=current.cursor;cursor.hide();if(lastCursor===null||onset<lastCursor-1e-8)cursor.reset();let steps=0;while(!cursor.Iterator.EndReached&&cursor.Iterator.CurrentSourceTimestamp.RealValue*4<onset-1e-8){cursor.next();if(++steps>30000){lastCursor=null;throw Error('Cursor traversal limit');}}const actual=cursor.Iterator.CurrentSourceTimestamp?.RealValue*4;if(cursor.Iterator.EndReached||Math.abs(actual-onset)>1e-8){lastCursor=null;throw Error('No score entry at requested onset: '+JSON.stringify({onset,actual,end:cursor.Iterator.EndReached,mi:cursor.Iterator.CurrentMeasureIndex,windowFrom,windowTo}));}lastCursor=actual;cursor.show();return {quarter:actual,measureIndex:cursor.Iterator.CurrentMeasureIndex,noteCount:cursor.NotesUnderCursor().length};},
  seekIdentities(identities){if(!identityWritten||!current)throw Error('Pinned source identity not loaded');current.cursor?.hide();const ord=new Set(identities.map(x=>x.measureOrdinal-1));
    const scoped={...identityWritten,measures:identityWritten.measures.filter(x=>ord.has(x.index)),notes:identityWritten.notes.filter(x=>ord.has(x.measureIndex))};
    const map=buildIdentityMap(current,scoped);return selectMotherNoteheads(current,map,identities,container);},
  cancelPending(){generation++;},
  hideCursor(){current?.cursor?.hide();for(const p of container.querySelectorAll('[data-mother-active]')){p.style.fill=p.getAttribute('data-original-fill')||'';p.removeAttribute('data-original-fill');p.removeAttribute('data-mother-active');}},
  resize(){if(current){current.render();lastCursor=null;}},
  dispose(){generation++;destroy(current);current=null;total=0;container.replaceChildren();}
 };
}
