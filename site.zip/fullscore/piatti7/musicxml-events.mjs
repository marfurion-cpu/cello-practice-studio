/* Standalone MusicXML timeline adapter. No I/O, storage, UI or dependency. */
const children=(n,name)=>(n.children||[]).filter(x=>!name||x.name===name);
const first=(n,name)=>children(n,name)[0];
const value=(n,name)=>first(n,name)?.text?.trim()||'';
const attrs=n=>({...n?.attrs});
function integer(x,label,{min=0}={}){if(!/^-?\d+$/.test(String(x)))throw Error(label+' must be an integer');const n=Number(x);if(!Number.isSafeInteger(n)||n<min)throw Error(label+' is out of range');return n;}
const gcd=(a,b)=>b?gcd(b,a%b):a;
function frac(n,d=1){if(!Number.isSafeInteger(n)||!Number.isSafeInteger(d)||d<=0)throw Error('Timing exceeds safe exact range');const g=gcd(Math.abs(n),d);return {n:n/g,d:d/g};}
const add=(a,b)=>frac(a.n*b.d+b.n*a.d,a.d*b.d);
const neg=a=>({n:-a.n,d:a.d});
const cmp=(a,b)=>a.n*b.d-b.n*a.d;
const key=a=>`${a.n}/${a.d}`;
const decimal=a=>a.n/a.d;
const walk=(n,name)=>[...(n.name===name?[n]:[]),...(n.children||[]).flatMap(x=>walk(x,name))];
const zero=()=>frac(0);
export function normalizeDOM(node){return {name:node.localName,attrs:Object.fromEntries(Array.from(node.attributes||[]).map(a=>[a.name,a.value])),text:node.textContent||'',children:Array.from(node.childNodes||[]).filter(n=>n.nodeType===1).map(normalizeDOM)};}
export function parseMusicXML(xml,{DOMParserClass=globalThis.DOMParser,maxLength=8_000_000}={}){
 if(typeof xml!=='string'||xml.length>maxLength)throw Error('MusicXML exceeds input size limit');
 if(/<!DOCTYPE|<!ENTITY/i.test(xml))throw Error('DTD/entities not supported; export plain MusicXML');
 if(!DOMParserClass)throw Error('DOMParser unavailable');
 const doc=new DOMParserClass().parseFromString(xml,'application/xml');
 if(!doc.documentElement||doc.getElementsByTagName('parsererror').length)throw Error('Invalid XML');
 const result=parseMusicXMLTree(normalizeDOM(doc.documentElement));return {...result,originalXML:xml};
}
// Isolated one-part / at-most-two-staves fallback. Never reinterpret unlabeled grand staff as cello.
function validateLayout(root,part){
 const measures=children(part,'measure');
 const staves=measures.flatMap(m=>children(m,'attributes').flatMap(x=>children(x,'staves')));
 const declarations=staves.map(x=>integer(x.text?.trim(),'staves',{min:1}));
 const count=declarations[0]??1;
 if(count>2||declarations.some(x=>x!==count))throw Error('Expected one or two fixed staves; no notes imported');
 const firstAttributes=measures.length?children(measures[0],'attributes')[0]:null;
 if(count===2&&(children(firstAttributes||{},'staves').length!==1
  ||children(measures[0]).slice(0,children(measures[0]).indexOf(firstAttributes)).some(x=>['note','backup','forward','direction'].includes(x.name))))
  throw Error('Two staves must be declared in the opening attributes before timed or staff-specific events');
 const declarationsByPart=children(root,'part-list').flatMap(x=>children(x,'score-part'));
 const sid=part.attrs?.id;
 if(declarationsByPart.length>1||(declarationsByPart.length&&sid!==declarationsByPart[0].attrs?.id))
  throw Error('Part list must name exactly this single cello part');
 const listed=declarationsByPart[0]||{};
 const scoreInst=children(listed,'score-instrument'), midiInst=children(listed,'midi-instrument'), devices=children(listed,'midi-device').filter(x=>x.attrs?.id);
 const referenced=walk(part,'note').flatMap(n=>children(n,'instrument'));
 if(scoreInst.length>1||midiInst.length>1||devices.length>1||walk(part,'sound').some(x=>children(x,'midi-instrument').length||children(x,'midi-device').length))
  throw Error('Multiple instruments or in-score instrument changes are not supported');
 const instIds=new Set([...scoreInst,...midiInst,...devices,...referenced].map(x=>x.attrs?.id));
 if(instIds.has(undefined)||instIds.has('')||instIds.size>1||referenced.length&&(!scoreInst.length||walk(part,'note').some(n=>children(n,'instrument').length>1)))
  throw Error('Missing, multiple or unbound instrument IDs; no notes imported');
 if(count===2){
  const cello=s=>/^(?:(?:solo\s+)?(?:cello|violoncello|violoncelle)|大提琴)$/iu.test(s);
  const role=value(scoreInst[0]||{},'instrument-name'), sound=value(scoreInst[0]||{},'instrument-sound');
  const program=value(midiInst[0]||{},'midi-program');
  if(!sid||!declarationsByPart.length||(!cello(value(listed,'part-name'))&&!cello(role)&&sound!=='strings.cello'&&program!=='43')||
     (role&&!cello(role))||(sound&&sound!=='strings.cello')||(program&&program!=='43'))
   throw Error('A two-staff score must explicitly identify one standard cello instrument');
 }
 for(const tag of ['note','direction','forward'])for(const e of walk(part,tag))if(children(e,'staff').length>1)
  throw Error('Conflicting staff references; no notes imported');
 for(const x of walk(part,'staff'))if(!['1',...(count===2?['2']:[])].includes(x.text?.trim()))
  throw Error('Staff reference outside declared range; no notes imported');
 for(const tag of ['clef','staff-details','key','time'])for(const x of walk(part,tag))if(x.attrs?.number!==undefined&&integer(x.attrs.number,'numbered '+tag,{min:1})>count)
  throw Error('Numbered '+tag+' outside declared staff range; no notes imported');
 return count;
}

export function parseMusicXMLTree(root){
 if(root.name!=='score-partwise')throw Error('Only score-partwise is supported');
 const parts=children(root,'part');if(parts.length!==1)throw Error('Select a single cello part; multiple voices within that part are supported');
 const staffCount=validateLayout(root,parts[0]);
 for(const tag of ['scordatura','staff-tuning','capo','transpose','unpitched','grace'])if(walk(root,tag).length)throw Error(`Unsupported ${tag}; no notes imported`);
 const notes=[],measures=[],attributeEvents=[],directions=[],warnings=[];let divisions=null,absolute=zero(),order=0;
 let context={key:null,time:null,clefs:[],staves:1};
 for(const [mi,m]of children(parts[0],'measure').entries()){
  let cursor=zero(),extent=zero(),anchor=null;const measureNotes=[];const offset=absolute;
  for(const e of children(m)){
   if(e.name==='attributes'){
    if(first(e,'divisions'))divisions=integer(value(e,'divisions'),'divisions',{min:1});
    if(first(e,'staves'))context.staves=integer(value(e,'staves'),'staves',{min:1});
    if(context.staves!==staffCount)throw Error('Changing staff count is unsupported; no notes imported');
    if(first(e,'key'))context.key=first(e,'key');if(first(e,'time'))context.time=first(e,'time');
    if(children(e,'clef').length)context.clefs=children(e,'clef');
    attributeEvents.push({measureIndex:mi,onset:add(offset,cursor),context:structuredClone(context),source:e});continue;
   }
   if(e.name==='backup'||e.name==='forward'){
    if(!divisions)throw Error('divisions required before timing');
    const duration=frac(integer(value(e,'duration'),e.name+' duration',{min:1}),divisions);
    cursor=add(cursor,e.name==='backup'?neg(duration):duration);if(cursor.n<0)throw Error('backup precedes measure start');
    if(cmp(cursor,extent)>0)extent=cursor;anchor=null;continue;
   }
   if(e.name==='direction'){directions.push({measureIndex:mi,cursor:add(offset,cursor),divisions,source:e});continue;}
   if(e.name!=='note'){if(e.name==='barline')directions.push({measureIndex:mi,cursor:add(offset,cursor),divisions,source:e});continue;}
   if(!divisions)throw Error('divisions required before first note');
   const duration=frac(integer(value(e,'duration'),'note duration',{min:1}),divisions),voice=value(e,'voice')||'1',staff=value(e,'staff')||'1';
   if(staff!=='1'&&!(staff==='2'&&context.staves===2))throw Error('Note staff outside declared range; no notes imported');
   const chord=!!first(e,'chord'),rest=!!first(e,'rest');
   if(chord&&(!anchor||anchor.voice!==voice||anchor.staff!==staff||anchor.rest||rest))throw Error('Chord note has no preceding pitched anchor in the same voice and staff');
   if(chord&&cmp(duration,anchor.duration)>0)throw Error('Chord member duration exceeds anchor duration');
   const onsetInMeasure=chord?anchor.onsetInMeasure:cursor;
   let pitch=null,midi=null;
   if(!rest){const p=first(e,'pitch');if(!p)throw Error('Pitched note missing pitch');
    const step=value(p,'step'),octave=integer(value(p,'octave'),'octave'),alter=Number(value(p,'alter')||0),base={C:0,D:2,E:4,F:5,G:7,A:9,B:11}[step];
    if(base===undefined||!Number.isInteger(alter)||Math.abs(alter)>2)throw Error('Unsupported pitch spelling or microtone');midi=(octave+1)*12+base+alter;if(midi<0||midi>127)throw Error('MIDI pitch out of range');pitch={step,octave,alter};
   }
   const notation=first(e,'notations');
   const n={id:`p0-m${mi}-n${order}`,sourceId:e.attrs?.id||null,order:order++,measureIndex:mi,measureNumber:m.attrs?.number||String(mi+1),voice,staff,chord,rest,cue:!!first(e,'cue'),pitch,midi,onsetInMeasure,onset:add(offset,onsetInMeasure),duration,beats:decimal(duration),type:value(e,'type')||null,dots:children(e,'dot').length,accidental:first(e,'accidental')||null,stem:value(e,'stem')||null,beams:children(e,'beam'),ties:children(e,'tie').map(attrs),tied:notation?children(notation,'tied').map(attrs):[],slurs:notation?children(notation,'slur').map(attrs):[],timeModification:first(e,'time-modification')||null,notations:notation||null,source:e,context:structuredClone(context)};
   notes.push(n);measureNotes.push(n);
   if(!chord){anchor=n;cursor=add(cursor,duration);}const end=add(onsetInMeasure,duration);if(cmp(end,extent)>0)extent=end;
   if(notes.length>30000)throw Error('Note limit exceeded');
  }
  measures.push({index:mi,number:m.attrs?.number||String(mi+1),implicit:m.attrs?.implicit==='yes',onset:offset,duration:extent,noteIds:measureNotes.map(n=>n.id),source:m});absolute=add(absolute,extent);
 }
 if(!notes.length)throw Error('No notes');
 if(walk(root,'repeat').length||walk(root,'ending').length||walk(root,'sound').some(n=>['dacapo','dalsegno','tocoda','fine'].some(k=>k in(n.attrs||{}))))warnings.push('Playback uses written order; repeats/navigation are preserved, not expanded');
 if(walk(root,'fermata').length)warnings.push('Fermata is preserved; extra duration needs interpretation');
 if(staffCount===2)warnings.push('Both staves belong to one cello; preview uses a shared written timeline. Engraving, slurs, bowing and fingering require separate review.');
 warnings.push('Timing uses MusicXML duration/divisions; all voices retained. Fingering and bowing are not inferred.');
 const groups=new Map();for(const n of notes){const k=key(n.onset);if(!groups.has(k))groups.set(k,{onset:n.onset,notes:[]});groups.get(k).notes.push(n);}
 const events=[...groups.values()].sort((a,b)=>cmp(a.onset,b.onset)).map((e,i)=>({...e,index:i,onsetBeats:decimal(e.onset),noteIds:e.notes.map(n=>n.id)}));
 return {schema:'cello-polyphony/0.1',staffCount,title:value(root,'movement-title')||value(first(root,'work')||{},'work-title')||'Imported score',notes,events,measures,attributeEvents,directions,totalDuration:absolute,totalBeats:decimal(absolute),sourceTree:root,warnings};
}
// One playback record per source note, including every chord/voice. Tie merging is deliberately separate.
export function rawPlaybackPlan(score,bpm=72){if(!Number.isFinite(bpm)||bpm<=0)throw Error('Invalid tempo');return {duration:score.totalBeats*60/bpm,notes:score.notes.filter(n=>!n.rest&&!n.cue).map(n=>({id:n.id,voice:n.voice,staff:n.staff,midi:n.midi,time:decimal(n.onset)*60/bpm,duration:decimal(n.duration)*60/bpm,ties:n.ties,tied:n.tied}))};}
export function tiedPlaybackPlan(score,bpm=72){
 const base=rawPlaybackPlan(score,bpm),out=[],active=new Map();
 for(const n of [...score.notes].sort((a,b)=>cmp(a.onset,b.onset)||a.order-b.order)){
  if(n.rest||n.cue)continue;
  // MusicXML tie controls sound; notations/tied controls engraving only.
  const types=new Set((n.ties||[]).map(t=>t.type));
  const k=`${n.voice}/${n.staff}/${n.midi}`;let item;
  if(types.has('stop')){item=active.get(k);if(!item||cmp(item.end,n.onset)!==0)throw Error(`Unmatched/noncontiguous tie at ${n.id}`);item.end=add(n.onset,n.duration);item.noteIds.push(n.id);active.delete(k);}
  else {if(active.has(k))throw Error(`Unclosed tie before ${n.id}`);item={midi:n.midi,voice:n.voice,staff:n.staff,onset:n.onset,end:add(n.onset,n.duration),noteIds:[n.id]};out.push(item);}
  if(types.has('start'))active.set(k,item);
 }
 if(active.size)throw Error('Open ties at end of imported score');
 return {duration:base.duration,notes:out.map(n=>({midi:n.midi,voice:n.voice,staff:n.staff,noteIds:n.noteIds,time:decimal(n.onset)*60/bpm,duration:decimal(add(n.end,neg(n.onset)))*60/bpm}))};
}
