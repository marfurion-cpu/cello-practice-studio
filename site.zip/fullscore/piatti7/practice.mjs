import {parseMusicXML,tiedPlaybackPlan} from './musicxml-events.mjs';
import {buildTimeline} from './timeline.mjs';
import {createScoreRenderer} from './osmd-identity-renderer.mjs';
import {createKtvRenderer} from '../ktv-renderer.mjs';
const files=[
 ['simrock-no7-full-m01-m96-parser2.musicxml','1c23aee8d8249957b3727451c663d521857b43764626de402ed2091250945e83'],
 ['display-single-m01-m86.musicxml','85d21393e1a55559268cf753466b84404e2f74677bf61e2255ab9045a344ea3a'],
 ['display-dual-m87-m91.musicxml','6346188071943d61c422fcc9efccaf98d7897b6f31c6ca26940a3e04a466155c'],
 ['display-single-m92-m96.musicxml','b4a96847d9c0080c131994865ee956d2a0e58eca97a4411098b355728238c536']
];
const abs=(q)=>q.n/q.d;
const signature=n=>[n.measureNumber,n.staff,n.voice,n.rest,n.midi,abs(n.duration)].join('/');
async function fetchScore([name,hash]){
 const res=await fetch(new URL(name,import.meta.url));if(!res.ok)throw Error('冻结谱料未加载');
 const bytes=await res.arrayBuffer(), sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
 if(sha!==hash)throw Error('皮亚蒂第7首谱料校验失败');
 const xml=new TextDecoder('utf-8',{fatal:true}).decode(bytes), score=parseMusicXML(xml);
 return {xml,score,byId:new Map(score.notes.map(n=>[n.sourceId,n]))};
}
let prepared;
export async function loadPiatti7(){
 if(!prepared)prepared=(async()=>{
  const [full,...views]=await Promise.all(files.map(fetchScore));
  const s=full.score;
  if(s.measures.length!==96||s.totalBeats!==282||s.notes.length!==1687||s.staffCount!==2||tiedPlaybackPlan(s,60).notes.length!==1683)throw Error('皮亚蒂第7首冻结时值不符');
  const ids=new Set(), offsets=[0,255,270];
  for(const [i,x] of views.entries()){
   if(x.score.staffCount!==[1,2,1][i]||x.score.measures.length!==[86,5,5][i])throw Error('原谱显示段边界不符');
   for(const n of x.score.notes){
    const t=full.byId.get(n.sourceId);
    if(!t||ids.has(n.sourceId)||signature(t)!==signature(n)||Math.abs(abs(t.onset)-abs(n.onset)-offsets[i])>1e-9)throw Error('原谱与音频音头身份不符');
    ids.add(n.sourceId);
   }
  }
  if(ids.size!==1687)throw Error('缺失书写音头');
  return {score:{...s,piatti7:true,verifiedPractice:true,fingeringEnabled:false},frames:buildTimeline(s),views};
 })().catch(e=>{prepared=null;throw e;});
 return prepared;
}
export function createPiatti7View({container,OpenSheetMusicDisplay,views}){
 const scoreView=createKtvRenderer({container,OpenSheetMusicDisplay,rendererFactory:createScoreRenderer});
 let active=-1,pending=null,epoch=0,viewRequest=0;
 const idx=m=>m<87?0:m<92?1:2;
 async function paint(frame){
  const m=Number(frame.measure), i=idx(m), req=++viewRequest, life=epoch,v=views[i];
  if(pending&&pending.index!==i){scoreView.cancelPending();pending=null;}
  if(active!==i){
   if(pending?.index!==i){
    const task=scoreView.load(v.xml,{measureCount:v.score.measures.length,identitySource:v.score,sourceLabels:v.score.measures.map(x=>x.number)});
    pending={index:i,task};
   }
   const result=await pending.task;
   if(life!==epoch||req!==viewRequest||result.stale)return false;
   active=i;pending=null;
  }
  if(life!==epoch||req!==viewRequest)return false;
  const local=v.score.measures.findIndex(x=>x.number===frame.measure);
  if(local<0)throw Error('谱面小节身份不符');
  scoreView.showMeasure(local+1);
  const ids=frame.notes.filter(n=>!n.rest&&!n.cue).map(n=>{
   const a=v.byId.get(n.sourceId),ord=v.score.measures[local].noteIds.indexOf(a?.id);
   if(!a||ord<0||signature(a)!==signature(n))throw Error('本音符未在原布局中定位');
   return {measureOrdinal:local+1,noteOrdinal:ord+1,noteId:a.id,sourceId:a.sourceId,voice:a.voice,staff:a.staff,grace:Boolean(a.grace),pitch:a.pitch};
  });
  for(const node of container.querySelectorAll("[data-piatti7-source]"))delete node.dataset.piatti7Source;
  if(ids.length)scoreView.seekIdentities(ids).forEach((h,j)=>{h.dataset.piatti7Source=ids[j].sourceId;});else scoreView.hideCursor();
  if(container.firstElementChild)container.firstElementChild.dataset.piatti7Owned='true';
  container.dataset.piatti7Layout=String(v.score.staffCount);
  container.dataset.piatti7Measure=frame.measure;
  return true;
 }
 function cancel(){epoch++;viewRequest++;pending=null;scoreView.cancelPending();}
 function dispose(keepForeign=false){
  cancel();
  const foreign=keepForeign?[...container.childNodes].filter(n=>n.dataset?.piatti7Owned!=='true'):[];
  delete container.dataset.piatti7Measure;delete container.dataset.piatti7Layout;
  scoreView.dispose();
  if(foreign.length)container.replaceChildren(...foreign);
 }
 return {paint,cancel,dispose,resize:()=>active>=0&&scoreView.resize()};
}
export function chunkSeconds(score,startQ,bpm){
 if(!Number.isFinite(startQ)||!Number.isFinite(bpm)||bpm<=0)throw Error('试听位置或速度无效');
 const max=startQ+50*bpm/60;
 if(score.totalBeats<=max)return (score.totalBeats-startQ)*60/bpm;
 const head=score.measures.findLast(m=>abs(m.onset)>startQ&&abs(m.onset)<=max);
 return head?(abs(head.onset)-startQ)*60/bpm:50;
}
