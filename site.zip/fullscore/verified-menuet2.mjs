import {parseMusicXML,tiedPlaybackPlan} from './musicxml-events.mjs';
import {verifyBytes} from './verified-courante.mjs';
const num=f=>f.n/f.d,frac=x=>({n:Math.round(x*24),d:24}),rat=x=>String(x).split('/').map(Number).reduce((a,b)=>a/b),midi=p=>12*(Number(p.octave)+1)+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[p.step])+Number(p.alter||0);
export async function adaptMenuet2(xml,planText,options={}){
 await verifyBytes(xml,'a9d2676583734b54bd46969faf7a5ca410fb9c14b3aec157cd4f5011acd12026');await verifyBytes(planText,'ec1a4b886f7ecf308fbe35613f681860ee6d35cedfef4ad8bfb03dae24689822');
 const plan=JSON.parse(planText),written=parseMusicXML(xml,options),route=plan.sourceRoute.map(x=>x-160);
 if(written.measures.length!==24||written.notes.length!==126||plan.events.length!==252||route.length!==48)throw Error('Menuet II范围不一致');
 const bySource=new Map();for(const m of written.measures){const ns=written.notes.filter(n=>n.measureIndex===m.index);ns.forEach((n,i)=>bySource.set(`${m.index+161}/${i+1}`,n));if(num(m.duration)!==3)throw Error('Menuet小节长度');}
 const notes=plan.events.map((e,i)=>{const n=bySource.get(`${e.sourceMeasure}/${e.sourceNote}`),vi=e.visit-1;
 if(!n||n.voice!==e.voice||n.beats!==rat(e.duration)||num(n.onsetInMeasure)!==rat(e.onset)||JSON.stringify(n.pitch&&[n.pitch.step,n.pitch.alter,n.pitch.octave])!==JSON.stringify(e.pitch&&[e.pitch.step,Number(e.pitch.alter||0),Number(e.pitch.octave)])||n.ties.length)throw Error('Menuet真实音符不一致');
 if(rat(e.performedOnset)!==vi*3+num(n.onsetInMeasure)||route[vi]!==n.measureIndex+1)throw Error('Menuet访问不一致');
 return {...n,id:`v${vi}:${n.id}`,order:i,measureIndex:vi,measureNumber:String(e.sourceMeasure),onset:frac(rat(e.performedOnset)),sourceQuarter:num(n.onset),sourceNoteId:n.id,sourceMeasure:e.sourceMeasure,visit:vi};});
 const measures=route.map((ordinal,vi)=>{const source=written.measures[ordinal-1];return {...source,index:vi,number:String(ordinal+160),onset:frac(vi*3),noteIds:notes.filter(n=>n.measureIndex===vi).map(n=>n.id),sourceQuarter:num(source.onset),sourceOrdinal:ordinal};});
 const groups=new Map();for(const n of notes){const t=num(n.onset);if(!groups.has(t))groups.set(t,[]);groups.get(t).push(n);}const events=[...groups].sort((a,b)=>a[0]-b[0]).map(([t,ns],index)=>({index,onset:frac(t),onsetBeats:t,notes:ns,noteIds:ns.map(n=>n.id)}));
 const score={...written,notes,measures,events,totalBeats:144,totalDuration:frac(144),verifiedPractice:true,displayRoute:route,writtenMeasureCount:24};
 const actual=tiedPlaybackPlan(score,60).notes,expected=plan.events.filter(n=>n.pitch).map(n=>({midi:midi(n.pitch),voice:n.voice,time:rat(n.performedOnset),duration:rat(n.duration)})),sort=xs=>xs.map(n=>[n.time,n.duration,n.midi,n.voice]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
 if(JSON.stringify(sort(actual))!==JSON.stringify(sort(expected)))throw Error('Menuet声音计划不一致');return score;
}
