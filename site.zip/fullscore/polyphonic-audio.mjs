import { tiedPlaybackPlan } from './musicxml-events.mjs';
// A bounded, local electronic audition. No claim of realistic bow acoustics.
export function slicePlan(score,startBeat,bpm,maxSeconds=60){
 if(!Number.isFinite(startBeat)||startBeat<0||!Number.isFinite(bpm)||bpm<20||bpm>240)throw Error('无效的播放起点或速度');
 if(!Number.isFinite(maxSeconds)||maxSeconds<=0||maxSeconds>60)throw Error('试听时长须为0到60秒');
 const full=tiedPlaybackPlan(score,bpm), start=startBeat*60/bpm;
 const duration=Math.min(60,maxSeconds,full.duration-start);
 if(!Number.isFinite(duration)||duration<=0)throw Error('当前起点没有可播放时值');
 const events=full.notes.filter(n=>n.time<start+duration-1e-9&&n.time+n.duration>start+1e-9).map(n=>{
  const a=Math.max(start,n.time), b=Math.min(start+duration,n.time+n.duration);
  return {...n,time:a-start,duration:b-a,phaseOffset:a-n.time,continued:a>n.time};
 }).filter(n=>Math.round((n.time+n.duration)*16000)>Math.round(n.time*16000));
 validateWork(events,duration);
 return {events,duration,startBeat,bpm};
}
export function validateWork(events,duration){
 if(events.length>10000)throw Error('试听声音事件过多');
 let work=0;const boundaries=[];
 for(const e of events){if(!Number.isFinite(e.time)||!Number.isFinite(e.duration)||e.duration<=0||e.time<0)throw Error('无效声音事件');
 const a=Math.max(0,e.time),b=Math.min(duration,e.time+e.duration);work+=Math.max(0,Math.ceil((b-a)*16000));boundaries.push([a,1],[b,-1]);}
 boundaries.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);let count=0;for(const [,delta]of boundaries){count+=delta;if(count>8)throw Error('当前试听最多8个同时音，请简化导入声部');}
 if(work>8000000)throw Error('试听计算量超出安全范围，请缩短片段');
}
export function makePolyWav(plan){
 validateWork(plan.events,plan.duration);
 const rate=16000,length=Math.ceil(plan.duration*rate);
 if(!Number.isFinite(length)||length<1||length>960000)throw Error('试听最长60秒');
 const mix=new Float32Array(length);
 for(const e of plan.events){
  if(!Number.isFinite(e.midi)||!Number.isFinite(e.time)||!Number.isFinite(e.duration)||e.duration<=0)throw Error('无效声音事件');
  const f=440*2**((e.midi-69)/12),a=Math.max(0,Math.round(e.time*rate)),b=Math.min(length,Math.round((e.time+e.duration)*rate));
  for(let i=a;i<b;i++){
   const t=(i-a)/rate,phase=t+(e.phaseOffset||0),env=Math.max(0,Math.min(1,t/.012,(e.duration-t)/.025));
   mix[i]+=.16*env*(Math.sin(2*Math.PI*f*phase)+.3*Math.sin(4*Math.PI*f*phase)+.12*Math.sin(6*Math.PI*f*phase));
  }
 }
 let peak=0;for(const x of mix)peak=Math.max(peak,Math.abs(x));const gain=peak>.85?.85/peak:1;
 const buffer=new ArrayBuffer(44+length*2),v=new DataView(buffer),str=(o,s)=>[...s].forEach((c,i)=>v.setUint8(o+i,c.charCodeAt(0)));
 str(0,'RIFF');v.setUint32(4,36+length*2,true);str(8,'WAVE');str(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,rate,true);v.setUint32(28,rate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);str(36,'data');v.setUint32(40,length*2,true);
 for(let i=0;i<length;i++)v.setInt16(44+i*2,Math.round(mix[i]*gain*32767),true);
 return buffer;
}
