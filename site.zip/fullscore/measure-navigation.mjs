// Measure numbers are source labels, not offsets or unfolded visit numbers.
export function measureEntries(score){
 const counts=new Map();
 for(const m of score.measures){const key=String(m.sourceOrdinal??m.number);counts.set(key,(counts.get(key)||0)+1);}
 const seen=new Map();
 return score.measures.map((m,index)=>{
  const key=String(m.sourceOrdinal??m.number),occurrence=(seen.get(key)||0)+1;seen.set(key,occurrence);
  return {index,measureIndex:m.index,startBeat:m.onset.n/m.onset.d,label:`原谱第 ${m.number} 小节`+(counts.get(key)>1?` · 第 ${occurrence} 次`:'' )};
 });
}
export function measureTarget(score,notes,index){
 if(!Number.isInteger(index)||index<0||index>=score.measures.length)return null;
 const entry=measureEntries(score)[index];
 const noteIndex=notes.findIndex(n=>n.measureIndex===entry.measureIndex&&Math.abs(n.time-entry.startBeat)<1e-8);
 return noteIndex<0?null:{...entry,noteIndex};
}
