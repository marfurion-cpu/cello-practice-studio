import {parseMusicXML,tiedPlaybackPlan} from '../musicxml-events.mjs';
import {buildTimeline} from '../timeline.mjs';
import {pinnedSha,groups,known,verifyPair,probeXml} from './known-pairs.mjs';
import {buildIdentityMap,selectMotherNoteheads} from './pinned-heads.mjs';

function pinHeads(osmd,written,ids,container){
 if(!written.no9FrozenWitness)throw Error('仅接受冻结的第9首谱头证据');
 const ord=new Set(ids.map(x=>x.measureOrdinal-1));
 const scoped={...written,measures:written.measures.filter(m=>ord.has(m.index)),notes:written.notes.filter(n=>ord.has(n.measureIndex))};
 const heads=selectMotherNoteheads(osmd,buildIdentityMap(osmd,scoped),ids,container);
 heads.forEach((h,i)=>h.dataset.piatti9SourceId=ids[i].sourceId);
 return heads;
}
export function preparePiatti9(written){
 const frames=buildTimeline(written), original=tiedPlaybackPlan(written,60);
 if(written.measures.length!==53||written.totalBeats!==318||written.notes.length!==877||original.notes.length!==872)
  throw Error('第9首冻结谱节点或时值不符');
 const bySource=new Map(written.notes.map(n=>[n.sourceId,n]));
 const references=new Set();
 const entries=new Map();
 for(const [a,b,t] of groups){
  const notes=[bySource.get(a),bySource.get(b)];
  if(!verifyPair(notes.filter(Boolean),known.get(a)))throw Error('同音双头身份不符');
  const noteIds=notes.map(n=>n.id), f=frames.find(n=>n.time===t);
  if(!f||JSON.stringify(f.notes.map(n=>n.id))!==JSON.stringify(noteIds))throw Error('原谱同音双头丢失或混入其它音');
  const matching=original.notes.filter(e=>noteIds.includes(e.noteIds[0]));
  if(matching.length!==2||matching.some(e=>e.noteIds.length!==1||e.midi!==57||e.time!==t||e.duration!==.5))
   throw Error('同音双头的时间不一致');
  const actual={noteIds,sourceIds:[a,b]};
  references.add(t);for(const id of noteIds)entries.set(id,actual);
 }
 function frameIdentities(frame){
  const m=written.measures[frame.measureIndex];
  if(!m||m.number!==frame.measure)throw Error('第9首小节身份不符');
  return frame.notes.filter(n=>!n.rest&&!n.cue).map(n=>{
   const found=bySource.get(n.sourceId), index=m.noteIds.indexOf(n.id);
   if(!found||index<0||found.id!==n.id||found.measureIndex!==m.index||found.staff!==n.staff||found.voice!==n.voice||found.midi!==n.midi)
    throw Error('第9首起音身份不符');
   return {measureOrdinal:m.index+1,noteOrdinal:index+1,noteId:n.id,sourceId:n.sourceId,voice:n.voice,staff:n.staff,grace:Boolean(n.grace),pitch:n.pitch};
  });
 }
 function adaptAudio(normal,optIn){
  const seen=new Map(), events=[];
  for(const e of normal.events){
   const entry=e.noteIds.length===1?entries.get(e.noteIds[0]):null;
   if(!entry){events.push(e);continue;}
   const prev=seen.get(entry);
   if(prev){
    if(e.time!==prev.time||e.duration!==prev.duration||e.continued!==prev.continued||e.phaseOffset!==prev.phaseOffset||e.midi!==prev.midi)
     throw Error('成对音频切点不一致');
    prev.count++;
   }else{
    seen.set(entry,{...e,count:1});
    if(optIn===true)events.push({...e,noteIds:entry.noteIds.slice(),sourceIds:entry.sourceIds.slice(),pitchReferenceOnly:true});
   }
  }
  if([...seen.values()].some(e=>e.count!==2))throw Error('仅出现一笔同音组声音事件');
  return {...normal,events}; // Keeps all original offsets, plan duration, clock and tail.
 }
 return {frames,score:{...written,verifiedPractice:true,fingeringEnabled:false,no9FrozenWitness:true,
   piatti9PinnedHeadResolver:pinHeads,piatti9:{references,frameIdentities,adaptAudio}}};
}

let loaded;
export function loadPiatti9(){
 if(!loaded)loaded=(async()=>{
  const res=await fetch(new URL('simrock-no9-full-m01-m53.musicxml',import.meta.url));
  if(!res.ok)throw Error('第9首冻结谱暂不可用');
  const bytes=await res.arrayBuffer();
  const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
  if(sha!==pinnedSha)throw Error('第9首谱指纹校验失败');
  const xml=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  return {...preparePiatti9(parseMusicXML(xml)),displayXML:probeXml(xml)};
 })().catch(e=>{loaded=null;throw e;});
 return loaded;
}
