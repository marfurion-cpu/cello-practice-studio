import {known,verifyPair,markerRgb} from './known-pairs.mjs';
// Isolated renderer capability: caller must rebuild after each real render.
// Never persist OSMD object IDs; never color whole SVG parent groups.
export function buildIdentityMap(osmd,written){
 const multiStaff=written.staffCount===2;
 const out=new Map(),used=new Set(),acc={0:1,1:-1,2:0,3:0,4:2,5:-2};
 for(const m of written.measures){const ns=osmd.Sheet.SourceMeasures[m.index].VerticalSourceStaffEntryContainers.flatMap(en=>en.StaffEntries.flatMap((s,i)=>s?s.VoiceEntries.flatMap(v=>v.Notes.map(note=>({note,staff:String(i+1)}))):[]));
  const source=written.notes.filter(n=>n.measureIndex===m.index);if(ns.length!==source.length)throw Error('OSMD/source note count differs '+m.index);
  source.forEach((n,i)=>{let matches=ns.filter(entry=>!multiStaff||entry.staff===n.staff).map(entry=>entry.note).filter(x=>!used.has(x)&&!!x.IsGraceNote===!!n.grace&&String(x.ParentVoiceEntry.ParentVoice.VoiceId)===n.voice&&Math.abs(x.ParentVoiceEntry.Timestamp.RealValue*4-n.onsetInMeasure.n/n.onsetInMeasure.d)<1e-8&&(n.rest?x.isRest():x.Pitch&&x.Pitch.FundamentalNote===({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[n.pitch.step])&&x.Pitch.Octave===n.pitch.octave-3&&acc[x.Pitch.Accidental]===n.pitch.alter));const entry=known.get(n.sourceId);
 if(entry&&written.no9FrozenWitness){
  const same=source.filter(x=>entry.ids.includes(x.sourceId));
  if(!verifyPair(same,entry))throw Error('No.9 source duplicate no longer matches review');
  const ordered=ns.filter(obj=>obj.staff===n.staff).map(x=>x.note).filter(x=>String(x.ParentVoiceEntry.ParentVoice.VoiceId)===n.voice&&Math.abs(x.ParentVoiceEntry.Timestamp.RealValue*4-n.onsetInMeasure.n/n.onsetInMeasure.d)<1e-8&&x.Pitch?.FundamentalNote===9&&x.Pitch.Octave===0&&acc[x.Pitch.Accidental]===0);
  if(ordered.length!==2||ordered[0]===ordered[1]||ordered[0].ParentVoiceEntry!==ordered[1].ParentVoiceEntry)
   throw Error('No.9 duplicate chord did not preserve two ordered source objects: '+n.sourceId);
  const actual=ordered[entry.rank]; if(!matches.includes(actual))throw Error('No.9 ordered head conflicts with renderer source identity');
  matches=[actual];
 }
 if(matches.length!==1)throw Error('Ambiguous source identity '+m.index+'/'+i+'/'+matches.length);used.add(matches[0]);out.set(`${m.index+1}/${i+1}`,{note:matches[0],original:n,no9Frozen:written.no9FrozenWitness===true});});
 }return out;
}
export function selectMotherNoteheads(osmd,map,identities,container){
 for(const p of container.querySelectorAll('[data-mother-active]')){p.removeAttribute('data-mother-active');p.style.fill=p.getAttribute('data-original-fill')||'';p.removeAttribute('data-original-fill');}
 const heads=[];for(const id of identities){const target=map.get(`${id.measureOrdinal}/${id.noteOrdinal}`);if(!target||target.original.voice!==id.voice||target.original.staff!==id.staff||(id.noteId!=null&&target.original.id!==id.noteId)||(id.sourceId!=null&&target.original.sourceId!==id.sourceId)||Boolean(target.original.grace)!==Boolean(id.grace)||JSON.stringify(target.original.pitch)!==JSON.stringify(id.pitch))throw Error('Mother identity mismatch');const engraved=osmd.EngravingRules.GNote(target.note),group=engraved?.getSVGGElement();const own=[...(group?.children||[])].find(e=>e.classList.contains('vf-note'));const hs=[...(own?.children||[])].filter(e=>e.tagName==='path'&&e.classList.contains('vf-notehead'));// OSMD 2.3.0 and its pinned VexFlow draw note_heads in order inside one chord group.
 const vfHeads=engraved?.vfnote?.[0]?.note_heads, index=engraved?.vfnoteIndex;
 const chordIndex=Array.isArray(vfHeads)&&vfHeads.length===hs.length&&Number.isInteger(index)?index:-1;
 const head=hs.length===1?hs[0]:hs[chordIndex];
 if(!head?.isConnected||!container.contains(head))throw Error('Mother notehead absent/stale');
 if(heads.includes(head))throw Error('Duplicate mother head');
 const pinned=known.get(id.sourceId);
 if(pinned&&target.no9Frozen){
  if(hs.length!==2)throw Error('No.9 SVG head count '+hs.length+' for '+id.sourceId);
  const boxes=hs.map(x=>x.getBBox()), [a,b]=boxes, diff=Math.abs(a.x-b.x)+Math.abs(a.y-b.y);
  const diagnostic=' (VF array '+vfHeads?.length+', gfx index '+index+', expected source rank '+pinned.rank+', delta '+diff.toFixed(2)+' px)';
  if(diff<.1)throw Error('No.9 engine drew two overlapping SVG heads; physical distinction unavailable '+id.sourceId+diagnostic);
  const fills=hs.map(x=>getComputedStyle(x).fill);
  if(fills.filter(v=>v===markerRgb[pinned.rank]).length!==1||fills[chordIndex]!==markerRgb[pinned.rank])
    throw Error('No.9 chord path source probe did not verify '+id.sourceId+diagnostic+' fills '+fills.join('/'));
  head.dataset.qaOriginalRank=String(pinned.rank);
  head.dataset.qaVfIndex=String(chordIndex);
 }
 heads.push(head);}
 for(const p of heads){p.setAttribute('data-original-fill',p.style.fill||'');p.setAttribute('data-mother-active','true');p.style.fill='#e97721';}return heads;
}
