export const pinnedSha='1523925f86986cc19e94b080c74e8eee3bf800388fc3411161f023be41d0f481';
export const groups=[
 ['piatti9-m007-n02','piatti9-m007-n02b',36.5],
 ['piatti9-m008-n08','piatti9-m008-n08b',45.5],
 ['piatti9-m039-n05','piatti9-m039-n05b',230],
 ['piatti9-m039-n08','piatti9-m039-n08b',231.5],
 ['piatti9-m045-n08','piatti9-m045-n08b',267.5]
];
export const known=new Map(groups.flatMap(([a,b,t])=>[[a,{rank:0,ids:[a,b],time:t}],[b,{rank:1,ids:[a,b],time:t}]]));
const val=x=>x.n/x.d;
export function verifyPair(notes,entry){
 return notes.length===2&&notes.every((n,i)=>n.sourceId===entry.ids[i]&&n.midi===57&&n.voice==='1'&&n.staff==='1'&&val(n.duration)===.5&&val(n.onset)===entry.time&&n.chord===Boolean(i)&&!n.ties.length);
}
// QA-only visible signature, applied to exact XML IDs after hash verification.
export const COLORS=['#962413','#1758ae'];
export const markerRgb=['rgb(150, 36, 19)','rgb(23, 88, 174)'];
export function probeXml(xml){
 const doc=new DOMParser().parseFromString(xml,'application/xml');
 for(const note of doc.getElementsByTagName('note')){
  const exact=known.get(note.getAttribute('id'));if(!exact)continue;
  const color=COLORS[exact.rank];note.setAttribute('color',color);
  const head=doc.createElement('notehead');head.setAttribute('color',color);head.textContent='normal';
  const before=Array.from(note.children).find(x=>['notehead','staff','beam','notations','lyric'].includes(x.localName));
  if(before?.localName==='notehead')before.replaceWith(head);else note.insertBefore(head,before??null);
 }
 return new XMLSerializer().serializeToString(doc);
}
