// Native select only; no key-event trap, custom modal, or numeric input.
export const COMMON_TEMPOS=Object.freeze([...new Set([...Array.from({length:27},(_,i)=>30+5*i),72,80,144])].sort((a,b)=>a-b));
export function connectTempoSelect(select,{initial=72,min=30,max=160,readCurrent,onChoose,documentObject=select.ownerDocument}){
 const list=new Map();
 function option(n,extra=false){
  const el=documentObject.createElement('option');
  el.value=String(n);el.disabled=n<min||n>max;
  el.textContent=extra?`${n}（本曲预设）`:el.disabled?`${n}（此曲不支持）`:String(n);
  list.set(n,el);
  return el;
 }
 select.replaceChildren(...COMMON_TEMPOS.map(n=>option(n)));
 function sync(n){
  if(!Number.isInteger(n)||n<min||n>max)return false;
  if(!list.has(n)){
   const before=[...list.keys()].filter(x=>x>n).sort((a,b)=>a-b)[0];
   select.insertBefore(option(n,true),list.get(before)||null);
  }
  if(select.value!==String(n))select.value=String(n);
  return true;
 }
 sync(initial);
 select.addEventListener('change',()=>{
  if(select.disabled)return;
  const n=Number(select.value);
  if(!Number.isInteger(n)||!list.has(n)||n<min||n>max){sync(readCurrent());return;}
  if(n!==readCurrent())onChoose(n);
 });
 return {sync};
}
