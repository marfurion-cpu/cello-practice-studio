/** Offline two-track event planner. Quarter beats are authoritative; time in seconds
 * is projected once for a playback slice. No source score, UI or audio renderer. */
const EPS=1e-8;
const TRACKS={cello:['cello'],piano:['piano'],duet:['cello','piano']};
const finite=v=>typeof v==='number'&&Number.isFinite(v);
const positive=v=>finite(v)&&v>EPS;
const fail=message=>{throw new RangeError(message);};

export function makeTimeline({measures,tracks,allowMissingTracks=false}={}){
 if(!Array.isArray(measures)||!measures.length)fail('Measure map required');
 if(!tracks||Object.keys(tracks).some(k=>k!=='cello'&&k!=='piano'))fail('Expected cello/piano tracks');
 let beat=0;
 const bars=measures.map((m,i)=>{
  const label=m.label??i+1;
  if(!positive(m.beats))fail('Invalid measure length: '+(i+1));
  const result={visit:i+1,label,startBeat:beat,endBeat:beat+m.beats};
  beat=result.endBeat;return Object.freeze(result);
 });
 const totalBeats=beat;
 const compiled={};
 for(const track of TRACKS.duet){
  const input=tracks[track];
  if(input===undefined&&allowMissingTracks)continue;
  if(!Array.isArray(input))fail('Missing track: '+track);
  const starts=new Set(),events=input.map((e,i)=>{
   const bar=bars[e.visit-1],voice=String(e.voice??1);
   if(!Number.isInteger(e.visit)||!bar||!finite(e.offset)||e.offset<0||!positive(e.beats)||e.offset+e.beats>bar.endBeat-bar.startBeat+EPS)fail('Invalid beat/measure bounds: '+track+'/'+i);
   if(!Number.isInteger(e.midi)||e.midi<0||e.midi>127)fail('Invalid MIDI: '+track+'/'+i);
   const tie=e.tie??null;
   if(![null,'start','continue','stop'].includes(tie))fail('Invalid tie: '+track+'/'+i);
   const startBeat=bar.startBeat+e.offset,endBeat=startBeat+e.beats;
   const key=JSON.stringify([voice,e.midi,startBeat]);
   if(starts.has(key))fail('Duplicate track/voice/pitch/onset: '+track+'/'+i);
   starts.add(key);
   return {track,voice,midi:e.midi,startBeat,endBeat,tie,id:e.id??track+':'+i,visit:e.visit};
  }).sort((a,b)=>a.startBeat-b.startBeat||a.midi-b.midi);
  const open=new Map(),played=[];
  for(const e of events){
   const key=JSON.stringify([e.voice,e.midi]),prev=open.get(key);
   if(e.tie==='stop'||e.tie==='continue'){
    if(!prev||Math.abs(prev.endBeat-e.startBeat)>EPS)fail('Noncontiguous/missing tie start: '+e.id);
    prev.endBeat=e.endBeat;prev.sourceIds.push(e.id);
    if(e.tie==='stop')open.delete(key);
   }else{
    if(prev)fail('Open tie interrupted: '+e.id);
    const n={track,voice:e.voice,midi:e.midi,startBeat:e.startBeat,endBeat:e.endBeat,sourceIds:[e.id]};
    played.push(n);if(e.tie==='start')open.set(key,n);
   }
  }
  if(open.size)fail('Unclosed '+track+' tie');
  compiled[track]=Object.freeze(played.map(n=>Object.freeze({...n,sourceIds:Object.freeze(n.sourceIds)})));
 }
 return Object.freeze({bars:Object.freeze(bars),totalBeats,tracks:Object.freeze(compiled)});
}

export function measureAt(timeline,beat){
 if(!finite(beat)||beat<0||beat>timeline.totalBeats)fail('Seek outside score');
 if(beat===timeline.totalBeats)return null;
 let lo=0,hi=timeline.bars.length;
 while(lo<hi){const i=(lo+hi)>>1;if(timeline.bars[i].endBeat<=beat)lo=i+1;else hi=i;}
 return timeline.bars[lo];
}

export function playbackSlice(timeline,{mode='duet',startBeat=0,endBeat=timeline.totalBeats,bpm=72,gains={}}={}){
 const tracks=Object.hasOwn(TRACKS,mode)?TRACKS[mode]:null;
 if(!tracks||!positive(bpm)||!finite(startBeat)||!finite(endBeat)||startBeat<0||endBeat<startBeat||endBeat>timeline.totalBeats)fail('Invalid playback options');
 const sec=60/bpm;
 const active=tracks.flatMap(track=>{
  if(!Object.hasOwn(timeline.tracks,track))fail('Track not available: '+track);
  const gain=gains[track]??(mode==='duet'?0.5:1);
  if(!finite(gain)||gain<0||gain>1)fail('Invalid gain: '+track);
  return timeline.tracks[track].filter(n=>n.startBeat<endBeat-EPS&&n.endBeat>startBeat+EPS&&endBeat>startBeat+EPS).map(n=>{
   const from=Math.max(startBeat,n.startBeat),to=Math.min(endBeat,n.endBeat);
   return {...n,gain,time:(from-startBeat)*sec,duration:(to-from)*sec,phaseOffset:(from-n.startBeat)*sec,continuation:n.startBeat<from-EPS};
  });
 }).sort((a,b)=>a.time-b.time||a.track.localeCompare(b.track)||a.midi-b.midi);
 return {mode,bpm,startBeat,endBeat,duration:(endBeat-startBeat)*sec,events:active};
}

export function seekMeasure(timeline,visit,options={}){
 if(!Number.isInteger(visit)||!timeline.bars[visit-1])fail('Invalid measure visit');
 return playbackSlice(timeline,{...options,startBeat:timeline.bars[visit-1].startBeat});
}
