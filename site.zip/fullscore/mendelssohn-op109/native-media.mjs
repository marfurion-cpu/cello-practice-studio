export const FILES=Object.freeze({cello:'audio/cello.mp3',piano:'audio/piano.mp3',duet:'audio/duet.mp3'});
const ASSET_BPM=72,EPS=1e-4;
export function mediaTransport({audio,totalBeats,emit=()=>{},visible=()=>true,timeoutMs=6000}){
 let position=0,mode='duet',bpm=72,state='paused',error='',serial=0,timer=null,wanted=false,pendingSeek=false;
 const snapshot=()=>({position,mode,bpm,state,error});
 const notify=()=>emit(snapshot());
 const directTime=()=>Math.min(totalBeats,Math.max(0,audio.currentTime*ASSET_BPM/60));
 function setRate(){
  audio.playbackRate=bpm/ASSET_BPM;
  if('preservesPitch' in audio)audio.preservesPitch=true;
  if('webkitPreservesPitch' in audio)audio.webkitPreservesPitch=true;
 }
 function seekMedia(){
  if(audio.readyState<1)return false;
  try{audio.currentTime=position*60/ASSET_BPM;pendingSeek=false;return true;}catch{return false;}
 }
 function reset(s,note=''){
  if(!pendingSeek&&['playing','loading'].includes(state)&&!audio.seeking)position=directTime();
  serial++;wanted=false;clearTimeout(timer);timer=null;state=s;error=note;audio.pause();notify();
 }
 function source(){
  pendingSeek=true;
  audio.src=FILES[mode];
  setRate();audio.load();
 }
 audio.addEventListener('loadedmetadata',()=>{
  setRate();
  if(!Number.isFinite(audio.duration)||Math.abs(audio.duration-totalBeats*60/ASSET_BPM)>.20){reset('error','音轨长度与谱面不符。');return;}
  if(!wanted)seekMedia();
 });
 audio.addEventListener('playing',()=>{
  if(!wanted||!visible()){audio.pause();return;}
  clearTimeout(timer);timer=null;state='playing';error='';notify();
 });
 audio.addEventListener('pause',()=>{if(wanted&&audio.paused&&!audio.ended)reset('paused');});
 audio.addEventListener('timeupdate',()=>{if(wanted&&!pendingSeek&&!audio.seeking&&Number.isFinite(audio.currentTime))position=directTime();});
 audio.addEventListener('ended',()=>{if(wanted){reset('ended');position=totalBeats;notify();}});
 audio.addEventListener('error',()=>{if(audio.error&&!audio.seeking)reset('error','音轨加载失败（'+audio.error.code+'）。');});
 function play(){
  if(wanted||!visible())return;
  if(position>=totalBeats-EPS){position=0;pendingSeek=true;}
  if(pendingSeek&&!seekMedia()){
   if(position>EPS){error='音轨仍在准备，载入后点播放。';notify();return;}
   // At opening the resource itself starts at zero.
   pendingSeek=false;
  }
  setRate();wanted=true;state='loading';error='';
  const token=++serial;notify();
  try{
   // Intentionally synchronous with the button's click, not after an await or worker.
   const request=audio.play();
   timer=setTimeout(()=>{if(token===serial&&state==='loading')reset('error','播放未能开始。可尝试直接打开同一音轨。');},timeoutMs);
   Promise.resolve(request).catch(e=>{if(token===serial)reset('error','播放未开始（'+(e?.name??'Error')+'）。');});
  }catch(e){if(token===serial)reset('error','播放未开始（'+(e?.name??'Error')+'）。');}
 }
 source();
 return {snapshot(){if(wanted&&!pendingSeek&&!audio.seeking&&Number.isFinite(audio.currentTime))position=directTime();return snapshot();},play,
  pause:()=>reset('paused'),interrupt:why=>reset('paused',why),
  seek(to){if(!Number.isFinite(to)||to<0||to>totalBeats)throw new RangeError('Invalid seek');reset('paused');position=to;pendingSeek=true;seekMedia();notify();},
  configure(next){
   const m=next.mode??mode,b=next.bpm??bpm;
   if(!Object.hasOwn(FILES,m)||!Number.isInteger(b)||b<30||b>144)throw new RangeError('Invalid mode or tempo');
   if(m!==mode){reset('paused');mode=m;bpm=b;source();notify();}
   else if(b!==bpm){bpm=b;setRate();notify();}
  }
 };
}
