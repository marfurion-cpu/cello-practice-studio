import {playbackSlice} from './mix.mjs';

// Backend contract: clock(), resume(), schedule(payload, when, ended)->cancel.
// Prepare contract: (slice, AbortSignal)->Promise<{duration,payload}>.
// The scheduler never relies on a manufacturer's media ended event to *start* the next slice.
export function makeTransport({timeline,backend,prepare,visible=()=>true,emit=()=>{},seconds=8,lead=.06}){
 if(!(seconds>=1&&seconds<=20)||!(lead>=0&&lead<=.4))throw new RangeError('Invalid transport bounds');
 let beat=0,mode='cello',bpm=72,state='paused',error='',run=null;
 const pos=()=>run?.when!=null?Math.min(timeline.totalBeats,run.scheduledBeat,run.origin+Math.max(0,backend.clock()-run.when)*run.bpm/60):beat;
 const snapshot=()=>({position:pos(),mode,bpm,state,error});
 const report=()=>emit(snapshot());
 function clear(next,why=''){
  beat=pos();const prior=run;run=null;
  if(prior){prior.abort.abort();for(const cancel of prior.scheduled.values())cancel();prior.scheduled.clear();}
  state=next;error=why;report();
 }
 const valid=r=>run===r&&!r.abort.signal.aborted;
 async function pump(r){
  if(r.busy||!valid(r)||r.scheduled.size>=2||r.scheduledBeat>=timeline.totalBeats)return;
  r.busy=true;
  try{
   const start=r.scheduledBeat,end=Math.min(timeline.totalBeats,start+seconds*r.bpm/60);
   const slice=playbackSlice(timeline,{mode:r.mode,bpm:r.bpm,startBeat:start,endBeat:end});
   const packet=await prepare(slice,r.abort.signal);
   if(!valid(r))return;
   if(!visible()){clear('paused','已切出页面，返回后手动继续。');return;}
   if(!packet||!(packet.duration>0)||Math.abs(packet.duration-slice.duration)>.002)throw Error('Invalid rendered duration');
   const now=backend.clock(), first=r.when===null;
   if(r.nextWhen!==null&&r.nextWhen<now+.008){
    // Pause at the actual buffered limit, never skip ahead over missing audio.
    clear('paused','下一段未及时生成，已暂停；点播放从断点继续。');return;
   }
   const when=r.nextWhen??now+lead;
   const id=++r.id;
   const cancel=backend.schedule(packet.payload,when,()=>{
    if(!valid(r))return;
    r.scheduled.delete(id);
    if(end>=timeline.totalBeats){r.when=null;beat=timeline.totalBeats;clear('ended');}
    else void pump(r);
   });
   if(first)r.when=when;
   r.nextWhen=when+packet.duration;r.scheduled.set(id,cancel);
   r.scheduledBeat=end;state='playing';report();
  }catch(e){if(valid(r))clear('error',String(e?.message??e));}
  finally{
   r.busy=false;
   if(valid(r)&&r.scheduled.size<2&&r.scheduledBeat<timeline.totalBeats)void pump(r);
  }
 }
 async function play(){
  if(run||!visible())return;
  if(beat>=timeline.totalBeats-1e-8)beat=0;
  const r={origin:beat,scheduledBeat:beat,mode,bpm,abort:new AbortController(),scheduled:new Map(),id:0,busy:false,when:null,nextWhen:null};
  run=r;state='loading';error='';report();
  try{
   await backend.resume(); // Call from the user gesture, not from a delayed prefetch.
   if(!valid(r))return;
   if(!visible()){clear('paused','已切出页面，返回后手动继续。');return;}
   await pump(r);
  }catch(e){if(valid(r))clear('error',String(e?.message??e));}
 }
 return {snapshot,play,pause:()=>clear('paused'),interrupt:(why)=>clear('paused',why),
  seek(to){if(!Number.isFinite(to)||to<0||to>timeline.totalBeats)throw new RangeError('Invalid seek');clear('paused');beat=to;report();},
  configure(next){const m=next.mode??mode,b=next.bpm??bpm;if(!['cello','piano','duet'].includes(m)||!Number.isInteger(b)||b<30||b>144)throw new RangeError('Invalid mode or tempo');clear('paused');mode=m;bpm=b;report();}
 };
}

export function createWebAudioBackend({AudioContext=globalThis.AudioContext??globalThis.webkitAudioContext}={}){
 if(!AudioContext)throw Error('浏览器不支持 Web Audio');
 let ctx,onSuspend;
 return {
  clock:()=>ctx?.currentTime??0,
  resume(){if(!ctx){ctx=new AudioContext();ctx.addEventListener('statechange',()=>{if(ctx.state!=='running')onSuspend?.();});}return ctx.resume();},
  schedule(bytes,when,ended){
   const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),n=view.getUint32(40,true)/2,rate=view.getUint32(24,true);
   const buffer=ctx.createBuffer(1,n,rate),samples=buffer.getChannelData(0);
   for(let i=0;i<n;i++)samples[i]=view.getInt16(44+2*i,true)/32768;
   const node=ctx.createBufferSource();node.buffer=buffer;node.connect(ctx.destination);
   node.onended=()=>{node.disconnect();ended();};node.start(when);
   return ()=>{node.onended=null;try{node.stop();}catch{}node.disconnect();};
  },
  observeSuspension(cb){onSuspend=cb;}
 };
}
