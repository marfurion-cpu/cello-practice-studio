import {makeMixWav} from './mix-wav.mjs';
self.onmessage=({data:{slice}})=>{
 try{const bytes=makeMixWav(slice);self.postMessage({bytes,duration:(bytes.length-44)/48000},[bytes.buffer]);}
 catch(e){self.postMessage({error:e.message});}
};
