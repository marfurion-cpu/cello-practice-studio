export function prepareWav(slice,signal){
 return new Promise((resolve,reject)=>{
  if(signal.aborted){reject(new DOMException('Cancelled','AbortError'));return;}
  const worker=new Worker(new URL('./wav-worker.mjs',import.meta.url),{type:'module'});
  const finish=()=>{worker.terminate();signal.removeEventListener('abort',abort);};
  const abort=()=>{finish();reject(new DOMException('Cancelled','AbortError'));};
  signal.addEventListener('abort',abort,{once:true});
  worker.onerror=()=>{finish();reject(Error('音频生成未启动'));};
  worker.onmessage=({data})=>{finish();if(data.error)reject(Error(data.error));else resolve({payload:data.bytes,duration:data.duration});};
  worker.postMessage({slice});
 });
}
