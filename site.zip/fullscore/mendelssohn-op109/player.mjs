import {createKtvRenderer} from '../ktv-renderer.mjs';
import {renderFourStringStudy} from '../four-string-study.mjs';
import {makeTimeline,measureAt} from './mix.mjs';
import {makeTransport,createWebAudioBackend} from './transport.mjs';
import {prepareWav} from './prepare-wav.mjs';
const $=id=>document.getElementById(id);
const modes=[...document.querySelectorAll('[data-mode]')];
const pitchName=m=>['C','C♯','D','E♭','E','F','F♯','G','G♯','A','B♭','B'][m%12]+(Math.floor(m/12)-1);
let score,renderer,transport,position=0,ready=false,displayed=-1,anchors=[],cursorSelection=null,raf=null,lastPaint=-1,pianoRenderer=null,pianoPending=false,pianoShown=-1,boardKey=null,spellings=new Map();
const status=t=>{$('status').textContent=t;};
function tick(){
 raf=null;
 const s=transport.snapshot();if(s.state!=='playing')return;
 position=s.position;
 if(Math.abs(position-lastPaint)>.025){redraw();lastPaint=position;}
 raf=requestAnimationFrame(tick);
}
function onTransport(s){
 position=s.position;
 const active=s.state==='loading'||s.state==='playing';
 $('play').textContent=active?'暂停':'播放';$('stop').disabled=!active;
 if(s.state==='playing'){status('正在电子试听 · '+modes.find(b=>b.dataset.mode===s.mode).textContent);if(raf===null)raf=requestAnimationFrame(tick);}
 else if(raf!==null){cancelAnimationFrame(raf);raf=null;}
 if(s.error)status(s.error);
 else if(s.state==='ended')status('本曲目练习范围播放完毕。');
 else if(s.state==='loading')status('正在准备声音…');
 redraw();
}
function redraw(){
 if(!ready)return;
 const bar=measureAt(score,Math.min(position,score.totalBeats-1e-8));
 if(!bar)return;
 if(bar.visit!==displayed){renderer.showMeasure(bar.visit);displayed=bar.visit;cursorSelection=null;}
 if(pianoRenderer&&$('pianoScore').open&&pianoShown!==bar.visit){pianoRenderer.showMeasure(bar.visit);pianoShown=bar.visit;}
 $('bar').value=String(bar.visit);
 const pitches=[...new Set(score.tracks.cello.filter(n=>n.startBeat<=position+1e-7&&n.endBeat>position+1e-7).map(n=>n.midi))];
 const event={midi:pitches.length===1?pitches[0]:null,rest:!pitches.length,sounding:pitches.map(midi=>({midi}))};
 const active=score.tracks.cello.filter(n=>n.startBeat<=position+1e-7&&n.endBeat>position+1e-7);
 const labels=active.map(n=>(spellings.get(n.sourceIds[0])||pitchName(n.midi)).replace('#','♯').replace('b','♭'));
 const label=pitches.length?labels.join(' + '):'大提琴休止';$('note').textContent=label;
 const bkey=pitches.join(',');if(bkey!==boardKey){boardKey=bkey;renderFourStringStudy(event,{compact:true,board:$('board'),recommendation:$('recommendation'),candidates:$('candidates'),documentObject:document,onSelect:()=>{}});}
 if(!pitches.length)renderer.hideCursor();
 else {
  const key=anchors.findLast(t=>t<=position+1e-7&&t>=bar.startBeat);
  if(key!==undefined&&key!==cursorSelection){try{renderer.seekQuarter(key);cursorSelection=key;}catch{renderer.hideCursor();cursorSelection=key;}}
 }
 $('prev').disabled=!anchors.some(t=>t<position-1e-7);
 $('next').disabled=!anchors.some(t=>t>position+1e-7);
}
function jump(to,message){transport.seek(to);status(message);}
$('bar').onchange=()=>{const bar=score.bars[Number($('bar').value)-1];jump(bar.startBeat,'已选第 '+bar.label+' 小节');};
$('prev').onclick=()=>{const t=anchors.findLast(a=>a<position-1e-7);if(t!==undefined)jump(t,'已定位大提琴前音');};
$('next').onclick=()=>{const t=anchors.find(a=>a>position+1e-7);if(t!==undefined)jump(t,'已定位大提琴后音');};
for(const b of modes)b.onclick=()=>{if(!ready)return;transport.configure({mode:b.dataset.mode});for(const bb of modes)bb.setAttribute('aria-pressed',String(bb===b));status('已切换：'+b.textContent+'。点播放开始。');};
$('bpm').onchange=()=>{if(!ready)return;try{transport.configure({bpm:Number($('bpm').value)});status('速度已调整。点播放继续。');}catch{$('bpm').value=transport.snapshot().bpm;status('速度请输入 30–144。');}};
$('stop').onclick=()=>{if(!ready)return;transport.pause();status('已停止。');};
$('play').onclick=()=>{if(!ready)return;const s=transport.snapshot();if(s.state==='loading'||s.state==='playing'){transport.pause();status('已暂停。');}else void transport.play();};
function interrupt(){if(ready&&['loading','playing'].includes(transport.snapshot().state))transport.interrupt('已暂停。返回后请手动播放。');}
document.addEventListener('visibilitychange',()=>{if(document.hidden)interrupt();});globalThis.addEventListener('pagehide',interrupt);
try{
 const get=async file=>{const r=await fetch(file);if(!r.ok)throw Error('读取失败');return r;};
 const [source,xml]=await Promise.all([get('practice.json').then(r=>r.json()),get('cello.musicxml').then(r=>r.text())]);
 score=makeTimeline(source);spellings=new Map(source.tracks.cello.map(n=>[n.id,n.written]));
 const backend=createWebAudioBackend();
 transport=makeTransport({timeline:score,backend,prepare:prepareWav,visible:()=>!document.hidden,emit:onTransport});
 backend.observeSuspension(interrupt);
 anchors=[...new Set(score.tracks.cello.map(n=>n.startBeat))];
 if(!anchors.length||anchors[0]!==4)throw Error('大提琴开头休止或首音对齐失败');
 renderer=createKtvRenderer({container:$('engraving'),OpenSheetMusicDisplay:opensheetmusicdisplay.OpenSheetMusicDisplay});
 await renderer.load(xml,{measureCount:score.bars.length});
 $('bar').replaceChildren(...score.bars.map(bar=>new Option(bar.label+'小节',bar.visit)));
 $('coverage').textContent='全曲练习 · '+score.bars.length+'小节';
 $('bar').disabled=false;$('play').disabled=false;ready=true; redraw();status('第一小节只有钢琴。');
}catch(err){status('未加载练习：'+err.message);}

$('pianoScore').ontoggle=async()=>{
 if(!ready||!$('pianoScore').open||pianoPending)return;
 if(pianoRenderer){redraw();return;}
 pianoPending=true;$('pianoStatus').textContent='正在载入钢琴谱…';let p;
 try{
  const r=await fetch('piano.musicxml');if(!r.ok)throw Error('钢琴谱读取失败');
  p=createKtvRenderer({container:$('pianoEngraving'),OpenSheetMusicDisplay:opensheetmusicdisplay.OpenSheetMusicDisplay});
  await p.load(await r.text(),{measureCount:score.bars.length});
  pianoRenderer=p;$('pianoStatus').textContent='';redraw();
 }catch(e){p?.dispose();$('pianoStatus').textContent='钢琴谱未显示；可折叠后重试。不影响音轨。';}finally{pianoPending=false;}
};
