// Synthetic rehearsal timbres, not instrument recordings.
// Writes mono signed PCM16, no browser, samples or assets required.
const TAU=2*Math.PI, MAX_SECONDS=30,MAX_EVENTS=4096,MAX_WORK=8_000_000;
const linear=(x,lo,hi)=>Math.max(0,Math.min(1,(x-lo)/(hi-lo)));
const dec=(x,t)=>Math.exp(-x/t);
export function instrumentSample(track,midi,age){
 if(!['cello','piano'].includes(track)||!Number.isInteger(midi)||midi<0||midi>127||!Number.isFinite(age)||age<0)throw new RangeError('Invalid instrument sample');
 return sample(track,440*2**((midi-69)/12),age);
}
function sample(track,f,t){
 const p=TAU*f*t;
 if(track==='piano'){
  // Fast hammer onset. Upper partials decay faster and have slight inharmonicity.
  const e=linear(t,0,.006);
  return e*(.60*dec(t,1.20)*Math.sin(p)+.21*dec(t,.67)*Math.sin(2.002*p)+.11*dec(t,.32)*Math.sin(3.009*p)+.045*dec(t,.19)*Math.sin(4.022*p));
 }
 // Sustained bow envelope and bounded frequency modulation using absolute age.
 const v=.23*(1-Math.cos(TAU*4.8*t))*linear(t,.10,.45);
 const q=p+v;
 return linear(t,0,.055)*(.61*Math.sin(q)+.23*Math.sin(2*q)+.12*Math.sin(3*q)+.045*Math.sin(4*q));
}
export function makeMixWav(slice,{sampleRate=24000,muted=[]}={}){
 const {duration,events,bpm}=slice??{};
 if(!Number.isFinite(duration)||duration<0||duration>MAX_SECONDS||!Number.isInteger(sampleRate)||sampleRate<8000||sampleRate>48000||!Array.isArray(events)||events.length>MAX_EVENTS||!Array.isArray(muted)||muted.some(x=>x!=='cello'&&x!=='piano'))throw new RangeError('Invalid WAV render bounds');
 const n=Math.ceil(duration*sampleRate), jobs=[];
 let work=0;
 for(const e of events){
  const {track,midi,time,duration:segments,phaseOffset=0,gain=1}=e;
  if((track!=='cello'&&track!=='piano')||!Number.isInteger(midi)||midi<0||midi>127||![time,segments,phaseOffset,gain].every(Number.isFinite)||time<0||segments<=0||time+segments>duration+1e-8||phaseOffset<0||phaseOffset>3600||gain<0||gain>1)throw new RangeError('Invalid WAV event');
  if(muted.includes(track)||gain===0)continue;
  const lo=Math.min(n,Math.ceil(time*sampleRate-1e-8)),hi=Math.min(n,Math.ceil((time+segments)*sampleRate-1e-8));
  work+=hi-lo;if(work>MAX_WORK)throw new RangeError('WAV render work limit');
  const originalSeconds=Number.isFinite(e.startBeat)&&Number.isFinite(e.endBeat)&&Number.isFinite(bpm)&&bpm>0 ? (e.endBeat-e.startBeat)*60/bpm : phaseOffset+segments;
  if(originalSeconds+1e-8<phaseOffset+segments)throw new RangeError('WAV clip exceeds note duration');
  jobs.push({track,f:440*2**((midi-69)/12),time,phaseOffset,gain,lo,hi,originalSeconds});
 }
 const acc=new Float64Array(n);
 for(const {track,f,time,phaseOffset,gain,lo,hi,originalSeconds} of jobs)for(let i=lo;i<hi;i++){
  const age=Math.max(0,phaseOffset+i/sampleRate-time);
  // Release belongs to the original note, not the clip edge.
  const release=linear(originalSeconds-age,0,Math.min(track==='cello'?.025:.035,originalSeconds/2));
  acc[i]+=gain*release*sample(track,f,age);
 }
 const bytes=new Uint8Array(44+n*2),v=new DataView(bytes.buffer);
 const word=(i,s)=>{for(let k=0;k<s.length;k++)bytes[i+k]=s.charCodeAt(k);};
 word(0,'RIFF');v.setUint32(4,36+n*2,true);word(8,'WAVE');word(12,'fmt ');
 v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,sampleRate,true);
 v.setUint32(28,sampleRate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);
 word(36,'data');v.setUint32(40,n*2,true);
 // Fixed soft saturation: bounded output without changing gain at clip boundaries.
 for(let i=0;i<n;i++)v.setInt16(44+i*2,Math.round(32767*Math.tanh(.84*acc[i])),true);
 return bytes;
}
