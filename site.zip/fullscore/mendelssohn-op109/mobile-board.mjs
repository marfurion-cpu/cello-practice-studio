import {compactStudyStops} from '../four-string-study.mjs';
import {drawTrialBoard} from '../shared-board.mjs';
export function drawBoard(note,{board,details,documentObject=globalThis.document}){
 const {stops,special}=compactStudyStops(note);
 drawTrialBoard(board,details,{stops,rest:!!note.rest,special,unverifiedTogether:stops.length>1},documentObject);
}
