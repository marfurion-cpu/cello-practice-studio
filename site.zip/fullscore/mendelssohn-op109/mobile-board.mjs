import {compactStudyStops,tuning,pitchName} from '../four-string-study.mjs';
export function drawBoard(note,{board,details,documentObject=globalThis.document}){
 const ns='http://www.w3.org/2000/svg',x=n=>61+329*(1-2**(-n/12));
 const {stops,missing,special}=compactStudyStops(note);
 const shape=(tag,attrs,text)=>{const e=documentObject.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(text!=null)e.textContent=text;board.append(e);};
 board.replaceChildren();board.setAttribute('viewBox','0 0 378 88');
 // No unlabelled semitone numerals; the selected dot carries the finger, if known.
 for(const ref of [2,5,7,9,12,17,19,24,29])shape('line',{x1:x(ref),x2:x(ref),y1:9,y2:76,stroke:'#bdc9c0','stroke-dasharray':'2 3'});
 tuning.forEach((s,i)=>{const y=16+i*18,cs=stops.filter(c=>c.name===s.name);
  shape('text',{x:5,y:y+4,'font-size':13,fill:'#285b46'},s.name+' 弦');
  shape('line',{x1:61,x2:345,y1:y,y2:y,stroke:cs.length?'#285b46':'#92a79a','stroke-width':cs.length?2:1});
  for(const c of cs){shape('circle',{cx:x(c.offset),cy:y,r:8,fill:'#285b46','data-string':c.name,'data-current-pitch':c.pitch});
   if(c.finger!==undefined)shape('text',{x:x(c.offset),y:y+4,'text-anchor':'middle','font-size':11,fill:'#fff'},c.finger===0?'空':String(c.finger));}
 });
 const statement=c=>c.offset===0?c.name+' 弦 · 空弦（不按指）':c.name+' 弦 · 指法：'+(c.finger===undefined?'未指定':c.finger==='拇'?'拇指':c.finger+' 指')+' · 把位：'+c.position;
 details.textContent=special?'特殊奏法未标按法':note.rest?'休止 · 不按弦':stops.length>1?'两音分别标位置，不代表已核同时按法':stops[0]?statement(stops[0])+'（练习参考）':missing?'此音未标位置':'无当前音';
}
