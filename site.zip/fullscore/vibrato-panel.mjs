import {eligibility,renderNote,wav} from './vibrato.mjs';
// Isolated, explicitly chosen current-note comparison, never applied to whole-score audio.
export function comparisonNote(event,fingering,{sourceVibrato='uncertain',doubleStop=false,unsupported=false,offset=0}={}){
 return {midi:event?.midi,duration:event?.duration,finger:unsupported?null:fingering?.finger,sourceVibrato,doubleStop,offset,
 fingeringKey:fingering?.key,string:fingering?.name,position:fingering?.pos,thumbPosition:!!(fingering?.thumbPosition||event?.thumbPosition),harmonic:!!(fingering?.harmonic||event?.harmonic),
 sourceIds:event?.noteIds||event?.sourceNoteIds||[],rest:!event||fingering?.rest};
}
export function canCompare(n){const s=eligibility(n,'on');if(!s.available)return s;if(!Number.isFinite(n.duration)||n.duration<=0||n.duration>60||n.offset<0||n.offset>=n.duration)return {...s,available:false,reason:'当前持续音时值不在支持范围'};return s;}
export function mountVibrato(host,beforePlay){
 host.innerHTML=`<details><summary>当前音揉弦 A/B · 默认关闭</summary><button data-close style="float:right">收起 ×</button><p style="font-size:12px">仅本音独立电子对比，不改变整曲播放或谱面；B 为用户选择，不代表这里必须揉弦。5 Hz / ±15 音分是工程预设，非教师建议；颤音不等于揉弦。刷新、换音不保留。2026-11-12 · v0.1</p><p data-info role="status"></p><div style="display:flex;gap:6px"><button data-dry>A 无揉弦</button><button data-wet>B 揉弦对比</button><button data-stop>停止</button></div><audio data-audio controls playsinline style="width:100%"></audio></details>`;
 const find=s=>host.querySelector(s),audio=find('[data-audio]'),info=find('[data-info]'),dry=find('[data-dry]'),wet=find('[data-wet]');let note=null,key='',url=null,serial=0;
 function stop(){serial++;audio.pause();audio.removeAttribute('src');if(url)URL.revokeObjectURL(url);url=null;if(note)info.textContent='对比已停止 · 未开启';}
 function update(n){const k=JSON.stringify(n);if(k===key)return;stop();key=k;note=n;const s=canCompare(n);dry.disabled=wet.disabled=!s.available;info.textContent=`来源音 ${n.sourceIds.join(', ')||'暂无'} · ${s.available?s.provenance:s.reason} · 未开启`;}
 async function play(mode){if(!note||!canCompare(note).available)return;beforePlay();stop();const token=serial;try{const result=renderNote(note,{mode,offsetSeconds:note.offset||0,duration:note.duration-(note.offset||0)});url=URL.createObjectURL(new Blob([wav(result.pcm)],{type:'audio/wav'}));audio.src=url;info.textContent=`${mode==='on'?'B ~ 揉弦对比（用户选择）':'A 无揉弦'} · 来源音 ${note.sourceIds.join(', ')} · ${(note.duration-(note.offset||0)).toFixed(2)} 秒 · 正在请求播放`;await audio.play();if(token!==serial)return;}catch(e){if(token===serial)info.textContent='未能启动对比：'+e.message;}}
 find('[data-close]').onclick=()=>{stop();host.querySelector('details').open=false;};
 dry.onclick=()=>play('off');wet.onclick=()=>play('on');find('[data-stop]').onclick=()=>{stop();info.textContent='对比已停止 · 未开启';};audio.onerror=()=>{stop();info.textContent='媒体播放失败，未确认声音可听。';};audio.onended=()=>{info.textContent+=' · 对比结束';};
 return {update,stop};
}
