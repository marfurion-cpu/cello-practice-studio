import {candidates,label} from './fingering.mjs';
// Conservative geometric feasibility only, not a teacher-approved performance edition.
// No barre, extension, thumb position, harmonics or non-adjacent string stops.
export function hasSustainedVoices(event){
 const time=event?.time, end=time+event?.beats;
 return (event?.sounding||[]).some(n=>{
  // Tie continuations may carry a fresh local onset despite an older sound.
  if(n.ties?.length||n.tied?.length)return true;
  const onset=n.onset? n.onset.n/n.onset.d:undefined;
  if(Number.isFinite(time)&&Number.isFinite(onset)&&onset<time-1e-9)return true;
  // A chord recommendation cannot constrain a subsequent monophonic segment.
  if(Number.isFinite(end)&&Number.isFinite(onset)&&Number.isFinite(n.beats)&&onset+n.beats>end+1e-9)return true;
  return false;
 });
}
export function chordOptions(event){
 if(!event?.polyphonic||event.unsupportedTechniques?.length||hasSustainedVoices(event))return [];
 const pitches=[...new Set((event.sounding||[]).map(n=>n.midi))].sort((a,b)=>a-b);
 if(pitches.length<2||pitches.length>4||pitches.some(x=>!Number.isInteger(x)))return [];
 const rows=pitches.map(midi=>candidates({midi}));const results=[];
 function visit(i,stops){
  if(i===rows.length){
   const nums=stops.map(c=>c.num).sort((a,b)=>a-b);
   if(nums.at(-1)-nums[0]!==nums.length-1)return;
   const frames=[...new Set(stops.filter(c=>c.finger>0).map(c=>c.start))];
   if(frames.length>1)return;
   results.push({stops:stops.map(c=>({...c})),start:frames[0]||0});return;
  }
  for(const c of rows[i]){
   if(stops.some(p=>p.name===c.name||(c.finger>0&&p.finger===c.finger)))continue;
   // Low-to-high pitch must follow low-to-high strings.
   if(stops.length&&stops.at(-1).num<=c.num)continue;
   visit(i+1,[...stops,c]);
  }
 }
 visit(0,[]);return results.sort((a,b)=>a.start-b.start);
}
export function chordAdvice(event){
 if(hasSustainedVoices(event))return {option:null,text:'多音含跨事件持续声部或延音线 · 尚未实现持续音的固定弦指约束，不给独立重分配指法；原谱与声音保留。'};
 const option=chordOptions(event)[0];
 if(!option)return {option:null,text:'多音原谱保留 · 当前保守模型未找到可验证的共用手位，不猜测指法；需教师核实。'};
 const bow=option.stops.length>2?'三/四弦和弦通常需分组滚奏，不表示一弓同时持续全部音。':'相邻弦双音；仍需核实换把衔接与音色。';
 return {option,text:option.stops.map(label).join('；')+'。'+bow+' 仅几何候选，未经教师审核；不含横按、伸张或拇指把位。'};
}
