// Electronic pitch modulation, not a cello performance or a pedagogical prescription.
export function eligibility(note, request='off') {
 if(!['off','on'].includes(request))throw Error('Unknown comparison mode');
 const mark=note.sourceVibrato??'unmarked';
 if(!['unmarked','vibrato','non-vibrato','uncertain'].includes(mark))throw Error('Unknown source marking');
 const provenance=mark==='unmarked'?'原谱未标：用户可选练习对比':mark==='vibrato'?'原谱明确揉弦标记':mark==='non-vibrato'?'原谱 non vib：保留原意':'原谱标记含义或范围未确认';
 let reason='';
 if(note.rest)reason='休止符不发声';
 else if(mark==='non-vibrato')reason='原谱禁止揉弦，不自动覆盖';
 else if(mark==='uncertain')reason='先确认原谱标记含义与作用范围';
 else if(note.thumbPosition)reason='拇指把位的揉弦尚未建模';
 else if(note.harmonic||note.doubleStop)reason='泛音或双音的揉弦尚未建模';
 else if(note.finger===0)reason='空弦不模拟普通左手按弦揉弦；特殊演奏法未建模';
 else if(!Number.isInteger(note.finger)||note.finger<1||note.finger>4)reason='需要已确认的按弦指法';
 return {enabled:request==='on'&&!reason,available:!reason,reason,provenance};
}
export function frequencyAt(midi,t,{rateHz=5,depthCents=15,fadeSeconds=.08}={}) {
 if(!Number.isFinite(midi)||midi<24||midi>96||!Number.isFinite(t)||t<0||!Number.isFinite(rateHz)||rateHz<1||rateHz>9||!Number.isFinite(depthCents)||depthCents<0||depthCents>50||!Number.isFinite(fadeSeconds)||fadeSeconds<=0)throw Error('Invalid vibrato parameters');
 const envelope=Math.min(1,t/fadeSeconds);
 return 440*2**((midi-69)/12)*2**(depthCents*envelope*Math.sin(2*Math.PI*rateHz*t)/1200);
}
export function renderNote(note,options={}) {
 const {mode='off',sampleRate=16000,offsetSeconds=0,duration=note.duration,rateHz=5,depthCents=15}=options;
 const state=eligibility(note,mode);
 if(!Number.isFinite(note.duration)||note.duration<=0||note.duration>60||!Number.isFinite(duration)||duration<=0||!Number.isFinite(offsetSeconds)||offsetSeconds<0||offsetSeconds+duration>note.duration+1e-9||sampleRate!==16000)throw Error('Invalid bounded note duration');
 frequencyAt(note.midi??60,0,{rateHz,depthCents});
 const count=Math.round(duration*sampleRate),start=Math.round(offsetSeconds*sampleRate);
 if(count<1)throw Error('Note duration produces no audio samples');
 const pcm=new Float32Array(count);
 if(note.rest)return {pcm,state,sampleRate};
 let phase=0; const base=frequencyAt(note.midi,0,{rateHz,depthCents:0});
 for(let i=0;i<start+count;i++){
  const t=i/sampleRate;
  // Integrate instantaneous frequency: multiplying f(t)*t produces wrong pitch.
  const f=state.enabled?frequencyAt(note.midi,t,{rateHz,depthCents}):base;
  if(i>=start){const env=Math.max(0,Math.min(1,t/.012,(note.duration-t)/.025));pcm[i-start]=.16*env*(Math.sin(phase)+.3*Math.sin(2*phase)+.12*Math.sin(3*phase));}
  phase+=2*Math.PI*f/sampleRate;
 }
 return {pcm,state,sampleRate};
}
export function wav(pcm,sampleRate=16000){
 const buffer=new ArrayBuffer(44+pcm.length*2),v=new DataView(buffer),str=(o,s)=>[...s].forEach((c,i)=>v.setUint8(o+i,c.charCodeAt(0)));
 str(0,'RIFF');v.setUint32(4,36+pcm.length*2,true);str(8,'WAVE');str(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,sampleRate,true);v.setUint32(28,sampleRate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);str(36,'data');v.setUint32(40,pcm.length*2,true);for(let i=0;i<pcm.length;i++)v.setInt16(44+i*2,Math.round(Math.max(-1,Math.min(1,pcm[i]))*32767),true);return buffer;
}
