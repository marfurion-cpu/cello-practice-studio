import {positions} from './fingering.mjs';
import {drawTrialBoard,pointX} from './shared-board.mjs';
const $=id=>document.getElementById(id);
// Fixed coordinate system: equal-tempered stopped-string distance, never a
// viewport re-centred around the selected hand. Position labels are references
// to a first-finger stop, not frets or universal position boundaries.
export function fingerX(offset){return pointX(offset);}
const shortLabels=['半','I','低II','高II','III','IV'];
// Fifth-position reference follows Davidoff/Wilson: A/D/G/C string first finger F♯4/B3/E3/A2.
// Reference only: do not add V to the four-finger low-position candidate solver.
export const positionReferences=[...positions.map(([name,offset],i)=>({name,offset,label:shortLabels[i],x:fingerX(offset)})),{name:'第五把位（一指参考）',offset:9,label:'V',x:fingerX(9),referenceOnly:true}];
const normalize=c=>({name:c.name,offset:c.offset,pitch:c.midi+c.offset,finger:c.finger,position:c.pos});
export function drawHandframe(c){ drawTrialBoard($('board'),{}, {rest:!!c?.rest,stops:c&&!c.rest?[normalize(c)]:[]}); }
export function drawChordHandframe(option){drawTrialBoard($('board'),{},{stops:option.stops.map(normalize)});}
