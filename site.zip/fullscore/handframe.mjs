import {strings,positions} from './fingering.mjs';
const $=id=>document.getElementById(id);
const TOP=25,ROW=16;
// Fixed coordinate system: equal-tempered stopped-string distance, never a
// viewport re-centred around the selected hand. Position labels are references
// to a first-finger stop, not frets or universal position boundaries.
export function fingerX(offset){return 65+640*(1-2**(-offset/12));}
const shortLabels=['半','I','低II','高II','III','IV'];
// Fifth-position reference follows Davidoff/Wilson: A/D/G/C string first finger F♯4/B3/E3/A2.
// Reference only: do not add V to the four-finger low-position candidate solver.
export const positionReferences=[...positions.map(([name,offset],i)=>({name,offset,label:shortLabels[i],x:fingerX(offset)})),{name:'第五把位（一指参考）',offset:9,label:'V',x:fingerX(9),referenceOnly:true}];
function priorHandFrame(index,path){for(let i=index-1;i>=0;i--){if(path[i]&&!path[i].rest&&path[i].finger>0)return path[i];}return null;}
function canvas(){
 const svg=$('board'),ns='http://www.w3.org/2000/svg';
 svg.setAttribute('viewBox','0 0 380 108');svg.setAttribute('role','img');
 svg.setAttribute('aria-label','固定把位参考网格：从上到下 A、D、G、C 弦；竖虚线为有限窄手型一指落点参考，不是琴品');svg.replaceChildren();
 function shape(tag,attrs,text){const e=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(text)e.textContent=text;svg.append(e);return e;}
 shape('title',{},'固定把位参考 · 半把位至第五把位');
 shape('desc',{},'虚线始终固定；半、I、低II、高II、III、IV、V 标记一指参考落点。V按Davidoff命名为距空弦九半音：A弦F♯4、D弦B3、G弦E3、C弦A2；只标参考，不生成第五把位演奏指法。按弦点按半音与有效弦长计算；这些线不是琴品或把位边界。这里只支持有限闭合手型，自动指法不支持一指后伸、伸张及第五把位以上；不推测未知指法。');
 for(let offset=1;offset<=10;offset++){
  const ref=positionReferences.find(p=>p.offset===offset),x=fingerX(offset);
  shape('line',{x1:x,x2:x,y1:18,y2:82,stroke:ref?'#8a9c8f':'#dce4dc','stroke-width':ref?1:0.7,'stroke-dasharray':ref?'3 3':'1 4','data-grid-offset':offset,'data-reference':ref?.name||'半音参考'});
 }
 for(const ref of positionReferences)shape('text',{x:ref.x,y:12,'text-anchor':'middle','font-size':14,fill:'#4b6655','data-position-label':ref.name},ref.label);
 shape('line',{x1:65,x2:65,y1:18,y2:82,stroke:'#859a88','stroke-width':3});
 return shape;
}
function stringRow(shape,st,i,active){const y=TOP+i*ROW;shape('line',{x1:65,x2:350,y1:y,y2:y,stroke:active?'#285b46':'#c6d0c5','stroke-width':active?3:1});shape('text',{x:10,y:y+5,'font-size':15,fill:'#234a38'},st.name+'弦');return y;}
function stop(shape,c,y){const x=fingerX(c.offset);shape('circle',{cx:x,cy:y,r:9,fill:c.finger===0?'white':'#285b46',stroke:'#285b46','stroke-width':2});shape('text',{x,y:y+4,'text-anchor':'middle',fill:c.finger===0?'#285b46':'white','font-size':13},String(c.finger));}
function legend(shape,text){shape('text',{x:190,y:94,'text-anchor':'middle','font-size':10,fill:'#52695a'},'竖线固定 · 标号为一指参考，非琴品');shape('text',{x:190,y:106,'text-anchor':'middle','font-size':9,fill:'#6d7a6f'},text);}
export function drawHandframe(c,state){
 const shape=canvas();
 [...strings].reverse().forEach((st,i)=>{
  const active=c&&!c.rest&&c.name===st.name,y=stringRow(shape,st,i,active);
  if(!active)return;
  if(c.finger>0)for(let f=1;f<=4;f++){
   if(f===c.finger)continue;const x=fingerX(c.start+f-1);
   shape('circle',{cx:x,cy:y,r:8,fill:'#fff',stroke:'#688572','stroke-dasharray':'3 2','stroke-width':1.5});
   shape('text',{x,y:y+4,'text-anchor':'middle',fill:'#466951','font-size':12},String(f));
  }
  stop(shape,c,y);
 });
 const prior=state&&priorHandFrame(state.index,state.path);
 legend(shape,c?.finger===0?'空弦不按弦 · '+(prior?'前一手位参考：'+prior.pos:'空弦不决定手位'):'实心=按指 · 虚线圆=其他指 · 理论弦长，非个人手型');
}
export function drawChordHandframe(option){
 const shape=canvas();
 [...strings].reverse().forEach((st,i)=>{const c=option.stops.find(c=>c.name===st.name),y=stringRow(shape,st,i,!!c);if(c)stop(shape,c,y);});
 legend(shape,'各实心点为按指 · 0为空弦 · 保守候选，非专业验收');
}
