const children=(n,t)=>(n.children||[]).filter(x=>x.name===t),one=(n,t)=>children(n,t)[0],val=(n,t)=>one(n,t)?.text?.trim()||'';
export function decompose(root){
 if(root.name==='opus')throw Error('首个谱文件是 opus 曲集，暂不支持。请导出单首 score-partwise MusicXML。');
 if(root.name==='score-timewise')throw Error('首个谱文件是 score-timewise，暂不支持。请导出 score-partwise MusicXML。');
 if(root.name!=='score-partwise'||children(root,'part').length!==1)throw Error('请导入单独大提琴声部的 score-partwise MusicXML。');
 const rows=[],measures=children(children(root,'part')[0],'measure');let div=0,absolute=0;
 if(!measures.length||measures.length>2000)throw Error('小节数量无效或过大。');
 for(const [mi,m] of measures.entries()) {let cursor=0,extent=0,anchor=null,index=0;
 for(const n of m.children||[]){if(n.name==='attributes'&&val(n,'divisions'))div=Number(val(n,'divisions'));
 if(n.name==='backup'||n.name==='forward'){const d=Number(val(n,'duration'))/div;if(!Number.isFinite(d)||d<0)throw Error('无效时值');cursor+=(n.name==='backup'?-d:d);if(cursor< -1e-8)throw Error('声部时间越过小节起点');extent=Math.max(extent,cursor);anchor=null;}
 if(n.name!=='note')continue;
 const grace=!!one(n,'grace'),cue=!!one(n,'cue'),chord=!!one(n,'chord'),rest=!!one(n,'rest');
 const duration=grace?null:Number(val(n,'duration'))/div;if(!grace&&(!val(n,'duration')||!Number.isFinite(duration)||duration<=0))throw Error('缺少有效时值，不猜测');
 if(chord&&!anchor)throw Error('和弦缺少起始音');const onset=chord?anchor.onset:cursor;
 const p=one(n,'pitch'),step=val(p||{},'step'),alter=Number(val(p||{},'alter')||0),oct=Number(val(p||{},'octave'));let midi=null,name='休止';
 if(!rest){if(!p||!val(p,'octave')||!Object.hasOwn({C:0,D:2,E:4,F:5,G:7,A:9,B:11},step)||!Number.isInteger(alter)||Math.abs(alter)>2||!Number.isInteger(oct))throw Error('无效音高或不支持的微分音');midi=(oct+1)*12+{C:0,D:2,E:4,F:5,G:7,A:9,B:11}[step]+alter;if(midi<0||midi>127)throw Error('音高越界');name=step+({'-2':'bb','-1':'b',0:'',1:'#',2:'##'}[alter])+oct;}
 const notation=one(n,'notations');const row={id:`${mi+1}:${index++}`,measureIndex:mi+1,measure:m.attrs?.number||String(mi+1),voice:val(n,'voice')||'1',staff:val(n,'staff')||'1',pitch:name,midi,onsetQuarter:absolute+onset,offsetQuarter:onset,durationQuarter:duration,role:cue?'提示音':grace?'装饰音':rest?'休止':'主奏',chord,ties:children(n,'tie').map(t=>t.attrs?.type),slurs:children(notation||{},'slur').map(t=>({...t.attrs})),sourceVerified:false};rows.push(row);
 if(!chord)anchor={onset};if(!grace&&!chord)cursor+=duration||0;extent=Math.max(extent,onset+(duration||0));
 }absolute+=extent;}
 if(rows.length>20000)throw Error('音符过多，请分声部导入');return {schema:'cello-score-decomposition/1',measureCount:measures.length,rows,warnings:['这是书写顺序，不展开反复；装饰音时值为空，不擅自分配。','提示音单独标记，不当作大提琴主奏；音高为XML编码，特殊奏法实响需另核对。']};
}
export function toCSV(rows){const keys=['id','measureIndex','measure','voice','staff','pitch','midi','onsetQuarter','offsetQuarter','durationQuarter','role','chord','source'];const q=v=>{let s=String(v??'');if(/^[=+@\t\r\n]/.test(s)||(/^-/ .test(s)&&!Number.isFinite(Number(s))))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};return '\uFEFF'+[keys,...rows.map(r=>keys.map(k=>r[k]))].map(a=>a.map(q).join(',')).join('\r\n');}
