export function createReader({document,OpenSheetMusicDisplay,fetch,crypto}){
 const $=id=>document.getElementById(id),o=new OpenSheetMusicDisplay($('score'),{backend:'svg',autoResize:false});let rows=[],selected=null,measure=0,token=0,queue=Promise.resolve();
 const digest=async s=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(x=>x.toString(16).padStart(2,'0')).join('');
 function draw(){if(!selected)return;o.EngravingRules.MinMeasureToDrawIndex=measure;o.EngravingRules.MaxMeasureToDrawIndex=measure;o.render();$('position').textContent=` ${measure+1}/${selected.range[1]-selected.range[0]+1} · 原源${selected.range[0]+measure} `;$('first').disabled=$('prev').disabled=measure===0;$('last').disabled=$('next').disabled=measure===selected.range[1]-selected.range[0];const w=selected.words.filter(x=>x.source===selected.range[0]+measure);$('originalWords').textContent=w.length?'本小节原文字（非原位补充）：\n'+w.map(x=>x.text).join('\n'):'本小节无 words 文字；谱内符号仍以渲染为准。';}
 function clearView(){selected=null;measure=0;$('score').replaceChildren();$('position').textContent='';$('originalWords').textContent='';for(const id of ['first','prev','next','last'])$(id).disabled=true;}
 function fail(e,current){if(current!==token)return false;clearView();$('status').textContent=e.message;return true;}
 async function select(index){
  const current=++token;clearView();$('status').textContent='加载原谱…';
  try{
   const row=rows[index];if(!row)throw Error('无效曲目');
   const r=await fetch(row.file);if(current!==token)return{stale:true};if(!r.ok)throw Error('原谱读取失败');
   const xml=await r.text();if(current!==token)return{stale:true};const hash=await digest(xml);if(current!==token)return{stale:true};if(hash!==row.sha256)throw Error('谱源校验失败，停止显示');
   queue=queue.catch(()=>{}).then(async()=>{if(current===token)await o.load(xml);});await queue;if(current!==token)return{stale:true};
   if(o.Sheet.SourceMeasures.length!==row.range[1]-row.range[0]+1)throw Error('小节数不符');
   selected=row;measure=0;$('movement').value=String(index);draw();$('status').textContent='仅阅谱 · 禁音、禁指法；书写音与实音未定';return{ok:true};
  }catch(e){return fail(e,current)?{ok:false,error:e.message}:{stale:true};}
 }
 $('first').onclick=()=>{if(selected){try{measure=0;draw();}catch(e){fail(e,token);}}};$('last').onclick=()=>{if(selected){try{measure=selected.range[1]-selected.range[0];draw();}catch(e){fail(e,token);}}};
 $('prev').onclick=()=>{if(selected&&measure>0){try{measure--;draw();}catch(e){fail(e,token);}}};$('next').onclick=()=>{if(selected&&measure<selected.range[1]-selected.range[0]){try{measure++;draw();}catch(e){fail(e,token);}}};$('movement').onchange=()=>select(Number($('movement').value));
 clearView();
 return{async start(){const r=await fetch('manifest.json');rows=await r.json();for(const [i,row]of rows.entries()){const op=document.createElement('option');op.value=i;op.textContent=row.name;$('movement').append(op);}await select(0);},select,draw,get state(){return{selected:selected?.name,measure,token};},resize(){if(selected){try{draw();}catch(e){fail(e,token);}}}};
}
if(typeof window!=='undefined'&&window.document&&window.opensheetmusicdisplay){const reader=createReader({document:window.document,OpenSheetMusicDisplay:window.opensheetmusicdisplay.OpenSheetMusicDisplay,fetch:window.fetch.bind(window),crypto:window.crypto});reader.start().catch(e=>{window.document.getElementById('status').textContent=e.message;});window.addEventListener('resize',()=>reader.resize());}
